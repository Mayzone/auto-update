--Add this file to "PAYDAY 2\mods\hook" folder and hook to { "hook_id" : "lib/tweak_data/tweakdata", "script_path" : "AddThisIfYouWantCarsOnAllMaps.lua"}
--add truste bank, mex maps
if Network:is_server() then
	if Global.load_level then
		local packages = {
			--falcogini
			"levels/narratives/bain/cage/world/world",
			--forklift, muscle, turrets, 
			"levels/narratives/vlad/shout/world/world",
			"levels/narratives/vlad/jolly/world/world",
			"levels/narratives/pbr/jerry/world/world",
			--bikes, turrets
			"levels/narratives/elephant/born/world/world"
		}

		for key, value in pairs(packages) do
			if not PackageManager:package_exists(value) then
				goto continue
			end
			if PackageManager:loaded(value) then
				goto continue
			end
			PackageManager:load(value)
			::continue::
		end

		--[[local function load_package2(name)
			if not PackageManager:loaded(name) then
				PackageManager:load(name)
			end
		end
		local function check_packages()
			local filename = "mods/hook/content/"..Global.level_data.level_id.." - packages.txt"
			local file = io.open(filename,"w")
			for _,level in pairs(tweak_data.levels) do
				local package = level.package
				if package then
					if not file then file = io.open(filename,"a") end
					if file then 
						file:write(package, "\n")
					end
					load_package2(package)
				end
			end
			file:close()
		end
		check_packages()--]]
		--[[
		--if not PackageManager:loaded("levels/narratives/pbr/jerry/world/world") then
		--	PackageManager:load("levels/narratives/pbr/jerry/world/world")
		--end
		if not PackageManager:loaded("levels/instances/unique/born/born_truck/world/world") then
			PackageManager:load("levels/instances/unique/born/born_truck/world/world")
		end
		if not PackageManager:loaded("levels/narratives/dentist/mus/world") then
			PackageManager:load("levels/narratives/dentist/mus/world")
		end
		if not PackageManager:loaded("levels/narratives/dentist/mus/world/world") then
			PackageManager:load("levels/narratives/dentist/mus/world/world")
		end
		if not PackageManager:loaded("levels/narratives/pbr/berry/world") then
			PackageManager:load("levels/narratives/pbr/berry/world")
		end
		if not PackageManager:loaded("levels/narratives/pbr/berry/world/world") then
			PackageManager:load("levels/narratives/pbr/berry/world/world")
		end
		if not PackageManager:loaded("levels/narratives/pbr/jerry/world") then
			PackageManager:load("levels/narratives/pbr/jerry/world")
		end
		if not PackageManager:loaded("levels/narratives/pbr/jerry/world/world") then
			PackageManager:load("levels/narratives/pbr/jerry/world/world")
		end
		if not PackageManager:loaded("levels/narratives/bain/nail/world") then
			PackageManager:load("levels/narratives/bain/nail/world")
		end
		if not PackageManager:loaded("levels/narratives/bain/nail/world/world") then
			PackageManager:load("levels/narratives/bain/nail/world/world")
		end
		if not PackageManager:loaded("levels/narratives/vlad/peta/stage1/world") then
			PackageManager:load("levels/narratives/vlad/peta/stage1/world")
		end
		if not PackageManager:loaded("levels/narratives/vlad/peta/stage1/world/world") then
			PackageManager:load("levels/narratives/vlad/peta/stage1/world/world")
		end
		if not PackageManager:loaded("levels/narratives/vlad/peta/stage2/world") then
			PackageManager:load("levels/narratives/vlad/peta/stage2/world")
		end
		if not PackageManager:loaded("levels/narratives/vlad/peta/stage2/world/world") then
			PackageManager:load("levels/narratives/vlad/peta/stage2/world/world")
		end
		if not PackageManager:loaded("levels/narratives/continental/spa/world") then
			PackageManager:load("levels/narratives/continental/spa/world")
		end
		if not PackageManager:loaded("levels/narratives/continental/spa/world/world") then
			PackageManager:load("levels/narratives/continental/spa/world/world")
		end
		if not PackageManager:loaded("levels/narratives/continental/fish/world") then
			PackageManager:load("levels/narratives/continental/fish/world")
		end
		if not PackageManager:loaded("levels/narratives/continental/fish/world/world") then
			PackageManager:load("levels/narratives/continental/fish/world/world")
		end
		if not PackageManager:loaded("levels/narratives/classics/dah/world") then
			PackageManager:load("levels/narratives/classics/dah/world")
		end
		if not PackageManager:loaded("levels/narratives/classics/dah/world/world") then
			PackageManager:load("levels/narratives/classics/dah/world/world")
		end--]]
	end
end
--[[
if not PackageManager:loaded("levels/narratives/bain/roberts/editor_only/editor_only") then
	PackageManager:load("levels/narratives/bain/roberts/editor_only/editor_only")
if not PackageManager:loaded("levels/instances/unique/are_loot_shoot/world/world") then
	PackageManager:load("levels/narratives/bain/roberts/editor_only/editor_only")
if not PackageManager:loaded("levels/narratives/bain/big/editor_only/editor_only") then
	PackageManager:load("levels/narratives/bain/roberts/editor_only/editor_only")
if not PackageManager:loaded("levels/instances/unique/dark/train_numbers/world/world") then
	PackageManager:load("levels/narratives/bain/roberts/editor_only/editor_only")
if not PackageManager:loaded("levels/instances/unique/pbr/pbr_flare/world/world") then
	PackageManager:load("levels/narratives/bain/roberts/editor_only/editor_only")
if not PackageManager:loaded("levels/narratives/vlad/peta/stage2/collision/collision") then
	PackageManager:load("levels/narratives/vlad/peta/stage2/collision/collision")
if not PackageManager:loaded("levels/narratives/elephant/born/collision/collision") then
	PackageManager:load("levels/narratives/elephant/born/collision/collision")
		

		if not PackageManager:loaded("levels/narratives/dentist/cas") then
			PackageManager:load("levels/narratives/dentist/cas")
		end
		if not PackageManager:loaded("levels/narratives/dentist/mia/stage1") then
			PackageManager:load("levels/narratives/dentist/mia/stage1")
		end
		if not PackageManager:loaded("levels/narratives/dentist/mia/stage2") then
			PackageManager:load("levels/narratives/dentist/mia/stage2")
		end
		if not PackageManager:loaded("levels/narratives/dentist/hox/stage_1") then
			PackageManager:load("levels/narratives/dentist/hox/stage_1")
		end
		if not PackageManager:loaded("levels/arratives/dentist/hox/stage_2") then
			PackageManager:load("levels/arratives/dentist/hox/stage_2")
		end
		PackageManager:load( "packages/narr_family" )
		PackageManager:load("levels/narratives/bain/diamond_store/world")
		PackageManager:load("levels/narratives/bain/diamond_store/world/world")
		PackageManager:load("packages/safehouse")
		PackageManager:load("levels/narratives/safehouse/world")
		PackageManager:load("levels/narratives/safehouse/world/world")
		PackageManager:load("levels/narratives/safehouse/safehouse_worldmesh/safehouse_worldmesh")
		PackageManager:load("packages/narr_roberts")
		PackageManager:load("levels/narratives/bain/roberts/world")
		PackageManager:load("levels/narratives/bain/roberts/world/world")
		PackageManager:load("packages/vlad_nightclub")
		PackageManager:load("levels/narratives/vlad/nightclub/world")
		PackageManager:load("levels/narratives/vlad/nightclub/world/world")
		PackageManager:load("levels/narratives/vlad/nightclub/nightclub_interior/nightclub_interior")
		PackageManager:load("levels/narratives/vlad/nightclub/pc_only/pc_only")
		PackageManager:load("packages/vlad_mallcrasher")
		PackageManager:load("levels/narratives/vlad/mallcrasher/world")
		PackageManager:load("levels/narratives/vlad/mallcrasher/world/world")
		PackageManager:load("levels/narratives/vlad/mallcrasher/ed3_world/ed3_world")
		PackageManager:load("packages/vlad_four_stores")
		PackageManager:load("levels/narratives/vlad/four_stores/world")
		PackageManager:load("levels/narratives/vlad/four_stores/world/world")
		PackageManager:load("packages/ukrainian_job")
		PackageManager:load("levels/narratives/vlad/ukrainian_job/world")
		PackageManager:load("levels/narratives/vlad/ukrainian_job/world/world")
		PackageManager:load("packages/narr_framing_1")
		PackageManager:load("levels/narratives/e_framing_frame/stage_1/world")
		PackageManager:load("levels/narratives/e_framing_frame/stage_1/world/world")
		PackageManager:load("packages/narr_framing_2")
		PackageManager:load("levels/narratives/e_framing_frame/stage_2/world")
		PackageManager:load("levels/narratives/e_framing_frame/stage_2/world/world")
		PackageManager:load("packages/narr_framing_3")
		PackageManager:load("levels/narratives/e_framing_frame/stage_3/world")
		PackageManager:load("levels/narratives/e_framing_frame/stage_3/world/world")
		PackageManager:load("packages/narr_jungle1")
		PackageManager:load("levels/narratives/e_welcome_to_the_jungle/stage_1/world")
		PackageManager:load("levels/narratives/e_welcome_to_the_jungle/stage_1/world/world")
		PackageManager:load("packages/narr_jungle2")
		PackageManager:load("levels/narratives/e_welcome_to_the_jungle/stage_2/world")
		PackageManager:load("levels/narratives/e_welcome_to_the_jungle/stage_2/world/world")
		PackageManager:load("packages/narr_alex1")
		PackageManager:load("levels/narratives/h_alex_must_die/stage_1/world")
		PackageManager:load("levels/narratives/h_alex_must_die/stage_1/world/world")
		PackageManager:load("packages/narr_alex2")
		PackageManager:load("levels/narratives/h_alex_must_die/stage_2/world")
		PackageManager:load("levels/narratives/h_alex_must_die/stage_2/world/world")
		PackageManager:load("packages/narr_alex3")
		PackageManager:load("levels/narratives/h_alex_must_die/stage_3/world")
		PackageManager:load("levels/narratives/h_alex_must_die/stage_3/world/world")
		PackageManager:load("packages/narr_watchdogs1")
		PackageManager:load("levels/narratives/h_watchdogs/stage_1/world")
		PackageManager:load("levels/narratives/h_watchdogs/stage_1/world/world")
		PackageManager:load("packages/narr_watchdogs2")
		PackageManager:load("levels/narratives/h_watchdogs/stage_2/world")
		PackageManager:load("levels/narratives/h_watchdogs/stage_2/world/world")
		PackageManager:load("packages/narr_firestarter1")
		PackageManager:load("levels/narratives/h_firestarter/stage_1/world")
		PackageManager:load("levels/narratives/h_firestarter/stage_1/world/world")
		PackageManager:load("packages/narr_firestarter2")
		PackageManager:load("levels/narratives/h_firestarter/stage_2/world")
		PackageManager:load("levels/narratives/h_firestarter/stage_2/world/world")
		PackageManager:load("packages/narr_firestarter3")
		PackageManager:load("levels/narratives/h_firestarter/stage_3/world")
		PackageManager:load("levels/narratives/h_firestarter/stage_3/world/world")
		PackageManager:load("packages/narr_arm_for")
		PackageManager:load("levels/narratives/armadillo/arm_for/world")
		PackageManager:load("levels/narratives/armadillo/arm_for/world/world")
		PackageManager:load("packages/narr_arm_cro")
		PackageManager:load("levels/narratives/armadillo/arm_cro/world")
		PackageManager:load("levels/narratives/armadillo/arm_cro/world/world")
		PackageManager:load("packages/narr_arm_par")
		PackageManager:load("levels/narratives/armadillo/arm_par/world")
		PackageManager:load("levels/narratives/armadillo/arm_par/world/world")
		PackageManager:load("packages/narr_arm_fac")
		PackageManager:load("levels/narratives/armadillo/arm_fac/world")
		PackageManager:load("levels/narratives/armadillo/arm_fac/world/world")
		PackageManager:load("packages/narr_arm_hcm")
		PackageManager:load("levels/narratives/armadillo/arm_hcm/world")
		PackageManager:load("levels/narratives/armadillo/arm_hcm/world/world")
		PackageManager:load("packages/narr_arm_und")
		PackageManager:load("levels/narratives/armadillo/arm_und/world")
		PackageManager:load("levels/narratives/armadillo/arm_und/world/world")
		PackageManager:load("packages/escape_overpass")
		PackageManager:load("levels/narratives/escapes/escape_overpass/world")
		PackageManager:load("levels/narratives/escapes/escape_overpass/world/world")
		PackageManager:load("packages/escape_street")
		PackageManager:load("levels/narratives/escapes/escape_street/world")
		PackageManager:load("levels/narratives/escapes/escape_street/world/world")
		PackageManager:load("packages/escape_cafe")
		PackageManager:load("levels/narratives/escapes/escape_cafe/world")
		PackageManager:load("levels/narratives/escapes/escape_cafe/world/world")
		PackageManager:load("packages/escape_cafe")
		PackageManager:load("levels/narratives/escapes/escape_cafe_day/world")
		PackageManager:load("levels/narratives/escapes/escape_cafe_day/world/world")
		PackageManager:load("packages/escape_garage")
		PackageManager:load("levels/narratives/escapes/escape_garage/world")
		PackageManager:load("levels/narratives/escapes/escape_garage/world/world")
		PackageManager:load("packages/escape_park")
		PackageManager:load("levels/narratives/escapes/escape_park/world")
		PackageManager:load("levels/narratives/escapes/escape_park/world/world")
		PackageManager:load("packages/escape_park")
		PackageManager:load("levels/narratives/escapes/escape_park_day/world/world")
		PackageManager:load("levels/narratives/escapes/escape_park_day/world")--]]
