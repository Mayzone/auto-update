CommandManager:vis("test")







