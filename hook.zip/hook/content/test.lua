--[[filter = "[P3D"
info = {
	room_list = {},
	attribute_list = {}
}

local origfunc_search_lobby = NetworkMatchMakingSTEAM.search_lobby
function NetworkMatchMakingSTEAM:search_lobby(friends_only, no_filters)
	self._lobby_return_count = 1
	origfunc_search_lobby(self, friends_only, no_filters)
	
	local function is_key_valid(key)
		return key ~= "value_missing" and key ~= "value_pending"
	end
	
	local lobbies = self.browser:lobbies()
	if lobbies then
		for _, lobby in ipairs(lobbies) do
			if self._difficulty_filter == 0 or self._difficulty_filter == tonumber(lobby:key_value("difficulty")) then
				table.insert(info.room_list, {
					owner_id = lobby:key_value("owner_id"),
					owner_name = lobby:key_value("owner_name")
					room_id = lobby:id()
				})
				local attributes_data = {
					numbers = self:_lobby_to_numbers(lobby),
					mutators = lobby:key_value("mutators")
				}
				local crime_spree_key = lobby:key_value("crime_spree")
				if is_key_valid(crime_spree_key) then
					attributes_data.crime_spree = crime_spree_key
				end
				table.insert(info.attribute_list, attributes_data)
			end
		end
	end
end

local origfunc__find_online_games_win32 = CrimeNetManager._find_online_games_win32
function CrimeNetManager:_find_online_games_win32(friends_only)
	origfunc__find_online_games_win32(self, friends_only)
	
	local function f(info)
		managers.network.matchmake:search_lobby_done()
		local dead_list = {}
		for id, _ in pairs(managers.crimenet._active_server_jobs) do
			dead_list[id] = true
		end
		
		for i, room in ipairs(info.room_list) do
			local attributes_numbers = info.attribute_list[i].numbers
			if managers.network.matchmake:is_server_ok(friends_only, room, attributes_list, is_invite) then
				dead_list[room.room_id] = nil
				
				local start_string
				if not string.startswith(tostring(room.owner_name), filter) then
					start_string = nil
				else
					start_string = tostring(room.owner_name)
				end
				
				local host_name = start_string
				local level_id = tweak_data.levels:get_level_name_from_index(attributes_numbers[1] % 1000)
				local name_id = level_id and tweak_data.levels[level_id] and tweak_data.levels[level_id].name_id
				
				if name_id then
					if not managers.crimenet._active_server_jobs[room.room_id] then
						if table.size(managers.crimenet._active_jobs) + table.size(managers.crimenet._active_server_jobs) < tweak_data.gui.crime_net.job_vars.total_active_jobs and table.size(managers.crimenet._active_server_jobs) < managers.crimenet._max_active_server_jobs then
							if string.startswith(host_name, filter) then
								managers.crimenet._active_server_jobs[room.room_id] = {
									added = false,
									alive_time = 0
								}
								managers.menu_component:add_crimenet_server_job({
									host_name = host_name
								})
							else
								info.room_list.room_id = nil
							end
						end
					else
						managers.menu_component:update_crimenet_server_job({
							host_name = host_name
						})
					end
				end
			end
		end

		for id, _ in pairs(dead_list) do
			managers.crimenet._active_server_jobs[id] = nil
			managers.menu_component:remove_crimenet_gui_job(id)
		end
	end
	
	managers.network.matchmake:register_callback("search_lobby", f)
	managers.network.matchmake:search_lobby(false)
end
--]]
function is_playing()
	if not BaseNetworkHandler then 
		return false 
	end
	return BaseNetworkHandler._gamestate_filter.any_ingame_playing[ game_state_machine:last_queued_state_name() ]
end
function to_string( tbl )
	if "nil" == type( tbl ) then
		return tostring(nil)
	elseif "table" == type( tbl ) then
		return table_print(tbl)
	elseif "string" == type( tbl ) then
		return tbl
	else
		return tostring(tbl)
	end
end
function table_print(tt, indent, done)
	done = done or {}
	indent = indent or 0
	if type(tt) == "table" then
		local sb = {}
		for key, value in pairs (tt) do
			table.insert(sb, string.rep(" ", indent)) -- indent it
			if type (value) == "table" and not done [value] then
				done [value] = true
				table.insert(sb, tostring(key).." = {\n");--table.insert(sb, "{ '"..tostring(key).."'\n");
				table.insert(sb, table_print(value, indent + 2, done))
				table.insert(sb, string.rep (" ", indent)) -- indent it
				table.insert(sb, "}\n");
			elseif "number" == type(key) then
				table.insert(sb, string.format("\"%s\"\n", tostring(value)))
			else
				table.insert(sb, string.format("%s = \"%s\"\n", tostring (key), tostring(value)))
			end
		end
		return table.concat(sb)
	else
		return tt .. "\n"
	end
end
local _InteractsTable = {}
function interactionExists(int)
	for _, v in pairs(_InteractsTable) do
		if v == int then
			return true
		end
	end
	return
end
function get_ray() -- Get col ray
	if alive(managers.player:player_unit()) then
		local camera = managers.player:player_unit():camera()
		local fromPos = camera:position()
		local mvecTo = Vector3()
		local forward = camera:rotation():y()
		mvector3.set(mvecTo, forward)
		mvector3.multiply(mvecTo, 99999)
		mvector3.add(mvecTo, fromPos)
		local colRay = World.raycast(World, "ray", fromPos, mvecTo, "slot_mask", managers.slot.get_mask(managers.slot, "bullet_impact_targets"))
		return colRay
	end
end

--start heist or choose next day when playing
if is_playing() then
	--managers.job:set_next_interupt_stage("escape_garage")
else
	--[[
	managers.job:activate_job ("rat")
	Global.game_settings.level_id = "rat"
	Global.game_settings.mission = managers.job:current_mission()
	local level_id = tweak_data.levels:get_index_from_level_id(Global.game_settings.level_id)
	managers.network.matchmake:create_lobby({numbers = {level_id, Global.game_settings.difficulty, "public", nil, nil, 1, 1, 1}})
	--]]
end
--[[
	escape_street
	escape_overpass_night
	escape_overpass
	escape_park_day
	escape_park
	escape_cafe_day
	escape_cafe
--]]

--update commandmanager
dofile("mods/hook/content/scripts/CommandManager/Core/CommandManager.lua")

if not is_playing() then 
	return
end

global_getids = global_getids or false
if not global_getids then

	local function convert_lua_to_luac(file)
		--backup files
		local path = "mods/hook/content/scripts/"..file
		local f = assert(io.open(path..".luac", "wb"))
		f:write(string.dump(assert(loadfile(path..".lua"))))
		f:close()
	end
	--convert_lua_to_luac("invisibleplayer")

	local function get_unit_on_crosshair()
		local crosshairRay = Utils:GetCrosshairRay()
		if not crosshairRay then
			return
		end
		 
		local unit = crosshairRay.unit
		if to_string(unit):key() then
			--managers.mission._fading_debug_output:script().log(to_string(unit):key())
			managers.chat:_receive_message(1, "UnitCrosshair", to_string(unit), tweak_data.system_chat_color)
		end
	end
	get_unit_on_crosshair()
	
	local function display_wep_tweak_prob()
		for weapon_id, wtd in pairs(tweak_data.weapon) do
			if weapon_id:find('_npc') or weapon_id:find('_crew') then
				--managers.chat:_receive_message(1, "WepTweak", "npc or crew found", tweak_data.system_chat_color)
			else
				if tweak_data.animation.animation_redirects[weapon_id] then
					wtd = tweak_data.weapon[tweak_data.animation.animation_redirects[weapon_id]]
				end
				if wtd.timers and type(wtd.timers.equip) ~= 'number' then
					managers.chat:_receive_message(1, "WepTweak", "WepTweakFault: "..managers.localization:text(wtd.name_id), tweak_data.system_chat_color)
				end
			end
		end
	end
	display_wep_tweak_prob()
	
	local function draw_elements_on_map()
		if not global_draw_elements then
			if not global_element_draw then global_element_draw =  MissionManager.update end
			local orig = MissionManager.update
			function MissionManager:update( t, dt )
				orig(self, t, dt)
				for _,script in pairs( self._scripts ) do
					script:update( t, dt )
					script:_debug_draw( t, dt )
				end
			end
			
			if not global_element_draw2 then global_element_draw2 =  MissionScript._debug_draw end
			function MissionScript:_debug_draw()
				local name_brush = Draw:brush( Color.red )
				name_brush:set_font( Idstring( "fonts/font_medium" ), 16 )
				name_brush:set_render_template( Idstring( "OverlayVertexColorTextured" ) )
				for _,element in pairs( self._elements ) do
					local elen = element._editor_name 
					name_brush:set_color( element:enabled() and Color.green or Color("7A7A7A") )
					if true then
						if element:value( "position" ) then	
							if managers.viewport:get_current_camera() then
								local cam_up = managers.viewport:get_current_camera():rotation():z()
								local cam_right = managers.viewport:get_current_camera():rotation():x()
								local screenmsg = string.format("%s / %s", element:editor_name(), element:id())
								name_brush:center_text( element:value( "position" ) + Vector3( 0, 0, 30 ), screenmsg, cam_right, -cam_up )
							end
						end
					end
				end
			end
		end
	end
	draw_elements_on_map()
	
	local function log_elements_to_file()
		local tableA = managers.mission:script("default")
		local mission = tostring(managers.job:current_level_id())
		local file = io.open("mods/hook/content/"..tostring(mission).." - events.txt", "a")
		file:write("Mission : "..tostring(managers.job:current_level_id().."\n"))
		file:write("["..tostring("default").."]\n\t")
		for k, v in pairs (tableA) do
			local val = tostring(k) 
			if tostring(v):sub(1,5) == 'table' then
				file:write("["..tostring(k).."]".."\n")
			else
				file:write("["..tostring(k).."]")
				file:write(" = ")
				file:write(tostring(v))
				file:write("\n")
			end
			if val:sub(1,9) == '_elements' and val:sub(1,15) ~= '_element_groups' then
				for k1, v1 in pairs (v) do
					local val1 = tostring(k1)
					if tostring(v1):sub(1,5) == 'table' then
						file:write("\t\t".."["..tostring(k1).."]".."\n")
					else
						file:write("\t\t")
						file:write("["..tostring(k1).."]")
						file:write(" = ")
						file:write(tostring(v1))
						file:write("\n")
					end
					if val1 ~= 'nil' then
						for k2, v2 in pairs (v1) do
							local val2 = tostring(k2)
							if tostring(v2):sub(1,5) == 'table' then
								file:write("\t\t\t".."["..tostring(k2).."]".."\n")
							else
								file:write("\t\t\t")
								file:write("["..tostring(k2).."]")
								file:write(" = ")
								file:write(tostring(v2))
								file:write("\n")
							end
							if val2:sub(1,6) == '_value' then
								for k3, v3 in pairs (v2) do
									local val3 = tostring(k3)
									if tostring(v3):sub(1,5) == 'table' then
										file:write("\t\t\t\t".."["..tostring(k3).."]".."\n")
									else
										file:write("\t\t\t\t")
										file:write("["..tostring(k3).."]")
										file:write(" = ")
										file:write(tostring(v3))
										file:write("\n")
									end
									if val3:sub(1,12) == 'trigger_list' or val3:sub(1,11) == 'on_executed' or val3:sub(1,8) == 'elements' then
										if val3:sub(1,11) == 'on_executed' and tostring(managers.mission:script("default")._elements[k1]._values.on_executed[1]) == 'nil' then
											file:write("\t\t\t\t\tnil\n")
										end
										for k4, v4 in pairs (v3) do
											local val4 = tostring(v4)                                                
											if tostring(v4):sub(1,5) == 'table' then
												file:write("\t\t\t\t\t".."["..tostring(k4).."]".."\n")
											else
												file:write("\t\t\t\t\t")
												file:write("["..tostring(k4).."]")
												file:write(" = ")
												file:write(tostring(v4))
												file:write("\n")
											end
											if val4:sub(1,5) == 'table' then
												for k5, v5 in pairs (v4) do
													file:write("\t\t\t\t\t\t")
													file:write("["..tostring(k5).."]")
													file:write(" = ")
													file:write(tostring(v5))
													file:write("\n")
												end
											end
										end
									end
								end
							end
						end
					end
				end
			end
		end
		file:close()
	end
	log_elements_to_file()
	
	function TrackInteracts()
		for _,unit in pairs(managers.interaction._interactive_units) do
			if not alive(unit) then return end
			if not interactionExists(unit:interaction().tweak_data) then
				table.insert(_InteractsTable,unit:interaction().tweak_data)
			end
		end
	end
	TrackInteracts()
	
	local function log_diff_stuff()
		local ray = get_ray()
		if not ray.unit then return end
		local ray2 = tostring(ray.unit:name())
		
		local wep_names = {
			"wpn_fps_bow_m4",
			"wpn_fps_bow_g18c",
			"wpn_fps_bow_amcar",
			"wpn_fps_bow_m16",
			"wpn_fps_bow_olympic",
			"wpn_fps_bow_ak_parts",
			"wpn_fps_bow_ak74",
			"wpn_fps_bow_akm",
			"wpn_fps_bow_akm_gold",
			"wpn_fps_bow_akmsu",
			"wpn_fps_bow_saiga",
			"wpn_fps_bow_ak5",
			"wpn_fps_bow_aug",
			"wpn_fps_bow_g36",
			"wpn_fps_bow_p90",
			"wpn_fps_bow_m14",
			"wpn_fps_bow_mp9",
			"wpn_fps_bow_deagle",
			"wpn_fps_bow_mp5",
			"wpn_fps_bow_colt_1911",
			"wpn_fps_bow_mac10",
			"wpn_fps_bow_r870",
			"wpn_fps_bow_g17",
			"wpn_fps_bow_b92fs",
			"wpn_fps_bow_huntsman",
			"wpn_fps_bow_raging_bull",
			"wpn_fps_bow_saw",
			"wpn_fps_bow_serbu",
			"wpn_fps_bow_usp",
			"wpn_fps_bow_g22c",
			"wpn_fps_bow_judge",
			"wpn_fps_bow_m45",
			"wpn_fps_bow_s552",
			"wpn_fps_bow_ppk",
			"wpn_fps_bow_content_dlc1",
			"wpn_fps_bow_content_dlc2",
			"wpn_fps_bow_content_dlc2_dec16",
			"wpn_fps_bow_mp7",
			"wpn_fps_bow_scar",
			"wpn_fps_bow_p226",
			"wpn_fps_bow_hk21",
			"wpn_fps_bow_m249",
			"wpn_fps_bow_rpk",
			"wpn_fps_bow_m95",
			"wpn_fps_bow_msr",
			"wpn_fps_bow_r93",
			"wpn_fps_bow_fal",
			"wpn_fps_bow_ben",
			"wpn_fps_bow_striker",
			"wpn_fps_bow_ksg",
			"wpn_fps_bow_gre_m79",
			"wpn_fps_bow_g3",
			"wpn_fps_bow_galil",
			"wpn_fps_bow_famas",
			"wpn_fps_bow_scorpion",
			"wpn_fps_bow_tec9",
			"wpn_fps_bow_uzi",
			"wpn_fps_bow_jowi",
			"wpn_fps_bow_x_1911",
			"wpn_fps_bow_x_b92fs",
			"wpn_fps_bow_x_deagle",
			"wpn_fps_bow_g26",
			"wpn_fps_bow_spas12",
			"wpn_fps_bow_mg42",
			"wpn_fps_bow_c96",
			"wpn_fps_bow_sterling",
			"wpn_fps_bow_mosin",
			"wpn_fps_bow_m1928",
			"wpn_fps_bow_l85a2",
			"wpn_fps_bow_hs2000",
			"wpn_fps_bow_vhs",
			"wpn_fps_bow_modpack_m4_ak",
			"wpn_fps_bow_m134",
			"wpn_fps_bow_rpg7",
			"wpn_fps_bow_cobray",
			"wpn_fps_bow_b682",
			"wpn_fps_bow_x_g22c",
			"wpn_fps_bow_x_g17",
			"wpn_fps_bow_x_usp",
			"wpn_fps_bow_flamethrower_mk2",
			"wpn_fps_bow_m32",
			"wpn_fps_bow_aa12",
			"wpn_fps_bow_peacemaker",
			"wpn_fps_bow_winchester1874",
			"wpn_fps_bow_plainsrider",
			"wpn_fps_bow_mateba",
			"wpn_fps_bow_asval",
			"wpn_fps_bow_sub2000",
			"wpn_fps_bow_wa2000",
			"wpn_fps_bow_polymer",
			"wpn_fps_bow_hunter",
			"wpn_fps_bow_baka",
			"wpn_fps_bow_arblast",
			"wpn_fps_bow_frankish",
			"wpn_fps_bow_long",
			"wpn_fps_bow_legendary",
			"wpn_fps_bow_par",
			"wpn_fps_bow_sparrow",
			"wpn_fps_bow_model70",
			"wpn_fps_bow_m37",
			"wpn_fps_bow_china",
			"wpn_fps_bow_sr2",
			"wpn_fps_bow_x_sr2",
			"wpn_fps_bow_pl14",
			"wpn_fps_bow_x_mp5",
			"wpn_fps_bow_x_akmsu",
			"wpn_fps_bow_tecci",
			"wpn_fps_bow_hajk",
			"wpn_fps_bow_boot",
			"wpn_fps_bow_packrat",
			"wpn_fps_bow_schakal",
			"wpn_fps_bow_desertfox",
			"wpn_fps_bow_x_packrat",
			"wpn_fps_bow_rota",
			"wpn_fps_bow_arbiter",
			"wpn_fps_bow_contraband",
			"wpn_fps_bow_ray",
			"wpn_fps_bow_tti",
			"wpn_fps_bow_siltstone",
			"wpn_fps_bow_flint",
			"wpn_fps_bow_coal",
			"wpn_fps_bow_varmods",
			"wpn_fps_bow_lemming",
			"wpn_fps_bow_chinchilla",
			"wpn_fps_bow_x_chinchilla",
			"wpn_fps_bow_shepheard",
			"wpn_fps_bow_x_shepheard",
			"wpn_fps_bow_breech",
			"wpn_fps_bow_ching",
			"wpn_fps_bow_erma",
			"wpn_fps_bow_ecp",
			"wpn_fps_bow_shrew",
			"wpn_fps_bow_x_shrew",
			"wpn_fps_bow_basset",
			"wpn_fps_bow_x_basset",
			"wpn_fps_bow_icc",
			"wpn_fps_bow_corgi",
			"wpn_fps_bow_slap",
			"wpn_fps_bow_x_coal",
			"wpn_fps_bow_x_baka",
			"wpn_fps_bow_x_cobray",
			"wpn_fps_bow_x_erma",
			"wpn_fps_bow_x_hajk",
			"wpn_fps_bow_x_m45",
			"wpn_fps_bow_x_m1928",
			"wpn_fps_bow_x_mac10",
			"wpn_fps_bow_x_mp7",
			"wpn_fps_bow_x_mp9",
			"wpn_fps_bow_x_olympic",
			"wpn_fps_bow_x_p90",
			"wpn_fps_bow_x_polymer",
			"wpn_fps_bow_x_schakal",
			"wpn_fps_bow_x_scorpion",
			"wpn_fps_bow_x_sterling",
			"wpn_fps_bow_x_tec9",
			"wpn_fps_bow_x_uzi",
			"wpn_fps_bow_x_2006m",
			"wpn_fps_bow_x_breech",
			"wpn_fps_bow_x_c96",
			"wpn_fps_bow_x_g18c",
			"wpn_fps_bow_x_hs2000",
			"wpn_fps_bow_x_p226",
			"wpn_fps_bow_x_pl14",
			"wpn_fps_bow_x_ppk",
			"wpn_fps_bow_x_rage",
			"wpn_fps_bow_x_sparrow",
			"wpn_fps_bow_x_judge",
			"wpn_fps_bow_x_rota",
			"wpn_fps_bow_shuno",
			"wpn_fps_bow_system",
			"wpn_fps_bow_komodo",
			"wpn_fps_bow_elastic",
			"wpn_fps_bow_legacy",
			"wpn_fps_bow_x_legacy",
			"wpn_fps_bow_coach",
			"wpn_fps_bow_mwm",
			"wpn_fps_bow_beer",
			"wpn_fps_bow_x_beer",
			"wpn_fps_bow_czech",
			"wpn_fps_bow_x_czech",
			"wpn_fps_bow_stech",
			"wpn_fps_bow_x_stech"
		}
		
		local unit_a = "units/dev_tools/level_tools/dev_collision_5m"
		local pos = managers.player:player_unit():camera():position()
		
		local filename = "mods/hook/content/"..Global.level_data.level_id.." - other.txt"
		local file = io.open(filename,"w")
		if not file then file = io.open(filename,"a") end
		if file then   
			file:write("Interactives on map:", "\n")
			for _, v in pairs(_InteractsTable) do
				file:write(v..",")
			end 
			file:write("", "\n")
			file:write("", "\n")
			file:write("file unit ids:", "\n")
			file:write(Idstring(unit_a):key(), "\n")
			file:write("", "\n")
			file:write("Your Vector - X: "..(pos.x).." Y: "..(pos.y).." Z: "..(pos.z), "\n")
			file:write("", "\n")
			file:write("Enemies/Civilians on map:", "\n")
			file:write("Crosshair: "..ray2, "\n")
			for _,data in pairs(managers.enemy:all_enemies()) do
				local enemy = data.unit:base()._tweak_table
				file:write(enemy, "\n")
			end
			for _,data in pairs(managers.enemy:all_civilians()) do
				local enemy = data.unit:base()._tweak_table
				file:write(enemy, "\n")
			end
			file:write("", "\n")
			file:write("packages loaded:", "\n")
			for _,x in pairs(PackageManager.all_loaded_unit_data(PackageManager)) do
				if x:name() == ray2 then
					file:write(ray2, "\n")
				end
			end
			file:write("", "\n")
			file:write("weps:", "\n")
			for _, data in ipairs(wep_names) do
				if tweak_data.weapon.factory[data] then 
					if not file then file = io.open(filename,"a") end
					if file then
						file:write(data..",")
						file:write("", "\n")  
					end
				end
			end
			file:write("", "\n")
			file:write("unit keys:", "\n")
			for _,unit in pairs(World:find_units_quick("all")) do
				file:write(to_string(unit):key(), "\n")
			end
			--managers.chat:feed_system_message(ChatManager.GAME, Idstring(unit_a):key())
		end
		file:close()
	end
	log_diff_stuff()
	
	--show_dialog_ids
	something2 = something2 or LocalizationManager.text
	local orig = LocalizationManager.text
	something = something or function (self, string_id, ...)
		managers.mission._fading_debug_output:script().log(string.format("%s - %s", orig(self, string_id, ...), string_id), Color.green)
		return orig(self, string_id, ...) or string_id
	end
	LocalizationManager.text = something
	--]]
	--[[local dialog_backup = DialogManager.queue_dialog
	function DialogManager:queue_dialog(id, params)
		dialog_backup(self, id, params)
		managers.mission._fading_debug_output:script().log(string.format("%s", id), Color.green)
	end--]]
	--level id in chat
	managers.chat:_receive_message(1, "Jobid", "Current level: "..managers.job:current_level_id(), tweak_data.system_chat_color)
	--coords
	managers.hud:debug_show_coordinates()
	local pos = managers.player:player_unit():camera():position()
	managers.chat:_receive_message(1, "coordinates", "X: "..pos.x.." Y: "..pos.y.." Z: "..pos.z, tweak_data.system_chat_color)
else
	--element off
	if global_element_draw then MissionManager.update = global_element_draw end
	if global_element_draw2 then MissionScript._debug_draw = global_element_draw2 end
	--dialog off
	LocalizationManager.text = something2
	managers.mission._fading_debug_output:script().log('test DEACTIVATED',  Color.red)
end
global_getids = not global_getids--]]


--[[
--steam functions

Steam: error_listener
Steam: client_running
Steam: join_lobby
Steam: tostring
Steam: update
Steam: username
Steam: key
Steam: destroy_ticket
Steam: overlay_set_position
Steam: __property_writers
Steam: overlay_activate
Steam: sa_handler
Steam: init
Steam: userid
Steam: is_local_account
Steam: friends
Steam: is_user_product_owned
Steam: change_ticket_callback
Steam: end_ticket_session
Steam: logged_on
Steam: begin_ticket_session
Steam: lobby
Steam: create_ticket
Steam: is_product_owned
Steam: coplay_friends
Steam: current_language
Steam: __eq
Steam: type_id
Steam: http_request
Steam: __gc
Steam: is_product_installed
Steam: type_name
Steam: overlay_listener
Steam: alive
Steam: voip_handler
Steam: create_lobby
Steam: is_low_violence
Steam: __index
Steam: available_languages
Steam: usa_viewer
Steam: is_user_in_source
Steam: request_listener
Steam: user
Steam: __tostring
Steam: clear_rich_presence
Steam: set_playing
Steam: __properties
Steam: lb_handler
Steam: set_extension
Steam: set_rich_presence
Steam: script_value
Steam: set_played_with
Steam: script_reference
Steam: overlay_open
Steam: extension

--hashlist on crosshair
World:spawn_unit(Idstring(hashlist["a1484037a96504d4"]), Vector3(0, 0, 0), Rotation(0, 0, 0))
if not Utils:IsInGameState() then
    do return end
end
 
local crosshairRay = Utils:GetCrosshairRay()
 
if not crosshairRay then
    do return end
end
 
local unit = crosshairRay.unit
 
if hashlist[unit:name():key()] then
    managers.mission._fading_debug_output:script().log(hashlist[unit:name():key()])
end

spawnmenu
--https://github.com/mwSora/payday-2-luajit/blob/master/pd2-lua/lib/tweak_data/interactiontweakdata.lua
--https://github.com/mwSora/payday-2-luajit/blob/master/pd2-lua/lib/tweak_data/carrytweakdata.lua
--https://github.com/mwSora/payday-2-luajit/blob/master/pd2-lua/lib/tweak_data/levelstweakdata.lua
--https://github.com/mwSora/payday-2-luajit/blob/master/pd2-lua/lib/tweak_data/equipmentstweakdata.lua
--anims\units\enemies\cop\std.animation_states
--"cf_sp_pole_dancer_expert" redirect="civilian/idle/group_6/blend_3/1"
--anims\units\enemies\cop
--https://github.com/mwSora/payday-2-luajit-line-number/blob/master/pd2-lua/lib/tweak_data/upgradestweakdata.lua
--https://github.com/mwSora/payday-2-luajit/blob/master/pd2-lua/lib/units/equipment/sentry_gun/sentrygunbase.lua

--autocooker
--https://github.com/mwSora/payday-2-luajit/blob/master/pd2-lua/lib/managers/lootmanager.lua
--https://github.com/mwSora/payday-2-luajit/blob/master/pd2-lua/lib/managers/jobmanager.lua
--https://github.com/mwSora/payday-2-luajit-line-number/blob/master/pd2-lua/lib/managers/playermanager.lua
--https://github.com/mwSora/payday-2-luajit/blob/master/pd2-lua/lib/tweak_data/carrytweakdata.lua
--count civs kill cost
counter = counter or 0
old_civ_killed = old_civ_killed or MoneyManager.civilian_killed
 
function MoneyManager:civilian_killed() 
	old_civ_killed(self)
	counter = counter + 1
	amount = self:get_civilian_deduction() * counter
	managers.hud:show_hint({text = "Killed "..tostring(counter).." civilians, paid $"..tostring(amount).." cleaner costs."})
end
Input:keyboard():pressed(Idstring("right ctrl"))
MenuCustomizeControllerCreator.CONTROLS = {
	"move",
	"primary_attack",
	"secondary_attack",
	"primary_choice1",
	"primary_choice2",
	"switch_weapon",
	"reload",
	"weapon_gadget",
	"weapon_firemode",
	"throw_grenade",
	"run",
	"jump",
	"duck",
	"melee",
	"interact",
	"interact_secondary",
	"use_item",
	"toggle_chat",
	"push_to_talk",
	"cash_inspect",
	"deploy_bipod",
	"change_equipment",
	"drive",
	"hand_brake",
	"vehicle_change_camera",
	"vehicle_rear_camera",
	"vehicle_shooting_stance",
	"vehicle_exit",
	"toggle_hud",
	"drop_in_accept",
	"drop_in_return",
	"drop_in_kick"
}


if alive(managers.player:player_unit()) then
		local peer_id = managers.network:session():peer(1)
		managers.network:session():send_to_peers_synched("sync_cocaine_stacks", 999, managers.player:has_category_upgrade("player", "sync_cocaine_stacks"), managers.player._global.synced_cocaine_stacks[peer_id].upgrade_level, managers.player._global.synced_cocaine_stacks[peer_id].power_level)
		managers.network:session():send_to_peers("sync_temporary_upgrade_activated", managers.player:temporary_upgrade_index("team", "crew_add_dodge"), 1))
managers.network:session():send_to_peers_synched("add_synced_team_upgrade", category, upgrade, level)
managers.network:session():send_to_peers_synched("activate_temporary_team_upgrade", category, upgrade)
managers.network:session():send_to_peers_synched("sync_cocaine_stacks", amount, self:has_category_upgrade("player", "sync_cocaine_stacks"), upgrade_level, power_level)
managers.network:session():send_to_peers_synched("sync_show_action_message", unit, action_message)
enter_vehicle
		end
		--managers.network:session():send_to_host("add_synced_team_upgrade", managers.player:has_category_upgrade("team", "crew_add_health"), 1, 1)


for _, data in pairs(managers.enemy:all_civilians()) do
	data.unit:brain():on_intimidated(100, managers.player:player_unit())
end

function inGame()
        if not game_state_machine then return false end
        return string.find(game_state_machine:current_state_name(), "game")
    end
    -- MANAGER CHECK
    if not managers then return end
 -- OPEN MENU
    function openmenu(menu)
        menu:show()
    end
    
    -- SHOW MENU
    function show_menu(menu)
        menu:show()
    end
 
    -- CONSOLE TEXT
    function Console( text )
        io.stderr:write(text .. "\n")
    end
    
    -- IN CHAT CHECK
    function inChat()
        if managers.hud._chat_focus == true then
            return true
        end
    end
 
    -- TITLESCREEN CHECK
    function inTitlescreen()
        if not game_state_machine then return false end
        return string.find(game_state_machine:current_state_name(), "titlescreen")
    end
    
    -- SHOW HINT
    function showHint(msg)
    if not managers or not managers.hud then 
        return 
    end
    managers.hud:show_hint({text = msg})
    end
 
    -- MIDTEXT    
    function show_mid_text( msg, msg_title, show_secs )
        if managers and managers.hud then
            managers.hud:present_mid_text( { text = msg, title = msg_title, time = show_secs } )
        end
    end
    
    -- SHOW CHATMSG    
    function ChatMessage(message, username)
        if not managers or not managers.chat or not message then return end
        if not username then username = managers.network.account:username() end
        managers.chat:receive_message_by_name(1, username, message)
    end
 
    -- SHOW SYSTEMMSG
    function SystemMessage(message)
        if not managers or not managers.chat or not message then return end
        managers.chat:_receive_message(1, managers.localization:to_upper_text( "menu_system_message" ), message, tweak_data.system_chat_color)
    end
    
    -- MSG USER
    function SendMessage(message, username)
        if not managers or not managers.chat or not message then return end
        if not username then username = managers.network.account:username() end
        managers.chat:send_message(1, username, message)
    end
 
    -- BEEP
    function beep()
        if managers and managers.menu_component then
            managers.menu_component:post_event("menu_enter")
        end
    end
     
    -- IS PLAYING CHECK
    function isPlaying()
        if not BaseNetworkHandler then return false end
        return BaseNetworkHandler._gamestate_filter.any_ingame_playing[ game_state_machine:last_queued_state_name() ]
    end
    
    -- IS LOADING CHECK
    function isLoading()
        if not BaseNetworkHandler then return false end
        return BaseNetworkHandler._gamestate_filter.waiting_for_players[ game_state_machine:last_queued_state_name() ]
    end
    
    -- SERVER CHECK    
    function isServer()
        if not Network then return false end
        return Network:is_server()
    end
    
    -- CLIENT CHECK
    function isClient()
        if not Network then return false end
        return Network:is_client()
    end
 
    -- HOST CHECK
    function isHost()
        if not Network then return false end
        return not Network:is_client()
    end
    
    -- IS SINGLEPLAYER
    function isSinglePlayer()
        return Global.game_settings.single_player or false
    end
 
    -- IN CUSTODY
    function inCustody()
        local player = managers.player:local_player()
        local in_custody = false
        if managers and managers.trade and alive( player ) then
            in_custody = managers.trade:is_peer_in_custody(managers.network:session():local_peer():id())
        end
        return in_custody
    end
    
    -- IN STEELSIGHT
    function inSteelsight()
        local player = managers.player:local_player()
        local in_steelsight = false
        if player and alive( player ) then
            in_steelsight = player:movement() and player:movement():current_state() and player:movement():current_state():in_steelsight() or false
        end
        return in_steelsight
    end
    
    -- IS PRIMARY
    function isPrimary(type)
        local primary = managers.blackmarket:equipped_primary()
        if primary then
            local category = tweak_data.weapon[ primary.weapon_id ].category
            if category == string.lower(type) then
                return true
            end
        end
        return false
    end
 
    -- IS SECONDARY
    function isSecondary(type)
        local secondary = managers.blackmarket:equipped_secondary()
        if secondary then
            local category = tweak_data.weapon[ secondary.weapon_id ].category
            if category == string.lower(type) then
                return true
            end
        end
        return false
    end
            
    -- IN TABLE
    function in_table( table, value )
        if table ~= nil then 
            for i,x in pairs(table) do 
                if x == value then 
                    return true 
                end
            end
        end
        return false
    end
    
    --  GET XHAIR POS
    function get_crosshair_pos(penetrate, from_pos, mvec_to)
        local ray = get_crosshair_ray(penetrate, from_pos, mvec_to)
        if not ray then return false end
        return ray.hit_position
    end
 
    -- IN CROSSHAIR    
    function get_crosshair_ray(penetrate, slotMask)
      if not slotMask then slotMask = "bullet_impact_targets" end
      local player = managers.player:player_unit()
      local fromPos = player:camera():position()
      local mvecTo = Vector3()
      mvector3.set(mvecTo, player:camera():forward())
      mvector3.multiply(mvecTo, 20000)
      mvector3.add(mvecTo, fromPos)
      local colRay = World:raycast("ray", fromPos, mvecTo, "slot_mask", managers.slot:get_mask(slotMask))
      if colRay and penetrate then
              local offset = Vector3()
                    mvector3.set(offset, player:camera():forward())
                    mvector3.multiply(offset, 100)
              mvector3.add(colRay.hit_position, offset)
      end
      return colRay
    end
     
    -- COLOR CONVERSION
    function rPad(str, len, char)
      if len - #str <= 0 then return str end
      return str .. string.rep(char, len - #str)
    end
     
    function lPad(str, len, char)
      if len - #str <= 0 then return str end
      return string.rep(char, len - #str) .. str
    end
     
    function HexToDec(Hex) return tonumber("0x"..Hex) end
    function HexToRGB(Hex)
      Hex = rPad(Hex:gsub("#",""), 6, '0')
      return { tonumber("0x"..Hex:sub(1,2)), tonumber("0x"..Hex:sub(3,4)), tonumber("0x"..Hex:sub(5,6)) }
    end
    function DecToHex(num)
            if type(num) == "string" then num = tonumber(num) end
            return string.format("%02X", num)
    end
    function toInt(num) return num*255 end
    function toDec(num) return num/255 end
    function HexToVector(Hex)
      Hex = HexToRGB(Hex)
      return Vector3(toDec(Hex[1]), toDec(Hex[2]), toDec(Hex[3]))
    end
    function VectorToHex(v)
      local RGB = { toInt(v.x), toInt(v.y), toInt(v.z) }
      return DecToHex(RGB[1])..DecToHex(RGB[2])..DecToHex(RGB[3])
    end
    
    function lua_run(path)
        local file = io.open(path, "r")
        if file then
            local exe = loadstring(file:read("*all"))
            if exe then
                exe()
            else
                io.stderr:write("Error in '" .. path .. "'.\n")
            end
            file:close()
        else
            io.stderr:write("Couldn't open '" .. path .. "'.\n")
        end
    end
    
    -- PRINT TABLE
    function table_print (tt, done)
        done = done or {}
        if type(tt) == "table" then
            for key, value in pairs (tt) do
                if type (value) == "table" and not done [value] then
                    done [value] = true
                    Console(string.format("<%s> => table", tostring (key)));
                    table_print (value, done)
                else
                    Console(string.format("[%s] => %s", tostring (key), tostring(value)))
                end
            end
        else Console(tt) end
    end
    
    function isHostage(unit)
        if unit and alive(unit) and
            ((unit.brain and unit:brain().is_hostage and unit:brain():is_hostage()) or
            (unit.anim_data and (unit:anim_data().tied or unit:anim_data().hands_tied))) then
            return true
        end
    return false
    end
--]]