local app = debug.getmetatable(Application)
if app then
    rawset(app, "production_build", function() 
        return false
    end)

    rawset(app, "debug_enabled", function() 
        return false
    end)

    rawset(app, "error", function() end)

    print = function() end	
    cat_print = function() end					 
    reload_and_compile = function() end		
    out = function() end						
    watch = function() end						
    cat_debug = function() end					
    cat_error = function() end					
    cat_stack_dump = function() end			
    cat_print_inspect = function() end			
    cat_debug_inspect = function() end			
    catprint_save = function() end				
    catprint_load = function() end
    print_console_result = function() end
    trace_ref = function() end
    trace_ref_add_destroy_all = function() end
    debug_pause = function() end
    debug_pause_unit = function() end
    compile_and_reload = function() end
    error = function() end
end