if not BetterDelayedCalls then return end
BetterDelayedCalls:Add("global_persist", 0.01, function() --skin unlocker cant handle higher number
	function in_game()
		if not game_state_machine then return false end
		return string.find(game_state_machine:current_state_name(), "game")
	end

	function is_playing()
		if not BaseNetworkHandler then 
			return false 
		end
		return BaseNetworkHandler._gamestate_filter.any_ingame_playing[ game_state_machine:last_queued_state_name() ]
	end
	
	function in_main_menu() -- checks if you are in the main menu or not.
		if game_state_machine:current_state_name() == "menu_main" then
			return true
		else
			return false
		end
	end
	
	--anticheat
	if GrenadeBase then function GrenadeBase.check_time_cheat() return true end end--Removes grenade's launcher silly delay. Crazy firerate enabled again (though it will work only on host side)
	if ProjectileBase then function ProjectileBase.check_time_cheat() return true end end
	function PlayerManager.verify_carry() return true end --Sometimes it blocks host from spawning bag, so it lobotomied
	function PlayerManager.verify_equipment() return true end
	function PlayerManager.verify_grenade() return true end
	function PlayerManager.register_grenade() return true end
	function PlayerManager.register_carry() return true end
	function NetworkPeer.begin_ticket_session() return true end
	function NetworkPeer.on_verify_ticket() end
	function NetworkPeer.end_ticket_session() end
	function NetworkPeer.change_ticket_callback() end
	function NetworkPeer.verify_job() end --Who cares own peer dlc heist or no
	function NetworkPeer.verify_character() end --Doesn't forces people to pay for Female character
	function NetworkPeer.verify_bag() return true end --crashes players on pickup spawned bags?
	function NetworkPeer.verify_outfit() end --Who cares own peer some outfit or no, saves a little of cpu aswell
	function NetworkPeer._verify_outfit_data() end
	function NetworkPeer._verify_cheated_outfit() end
	function NetworkPeer._verify_content() return true end
	function NetworkPeer.tradable_verify_outfit() end
	function NetworkPeer.on_verify_tradable_outfit() end
	
	if is_playing() then
	
		-- No movement penalty, change to a larger value than 1 for an increase in speed
		PlayerManager.body_armor_movement_penalty = function(self) return 1 end

		if managers.job:current_level_id() == "kosugi" then
			--truck secure
			managers.mission._scripts["default"]._elements[102972]:on_executed(managers.player:player_unit())
			managers.mission._scripts["default"]._elements[103464]:on_executed(managers.player:player_unit())
		end
		--trade jailed
		--managers.trade:update_auto_assault_ai_trade(dt, true)
		
		--open dupsters that cant be opened
		local dumpsters = { 	
			["1cbee76c179b5192"] = true, --units/pd2_dlc_brb/props/brb_prop_alley_trash_container/brb_prop_alley_trash_container
			["cfe6b1dca77ba461"] = true, --units/payday2/props/str_prop_alley_trash_container/str_prop_alley_trash_container
			["421a4ea84848010c"] = true,  --units/world/street/trash_container/trash_container
		}
		for i,unit in pairs(World:find_units_quick("all", 1)) do
			if unit and unit:name() and dumpsters[unit:name():key()] then 
				unit:interaction():set_active(true)
			end
		end
		
		if (toggleUpdateMarks == true) then
			PlayerManager.xpTexts = {}

			function round2(num, idp)
				return string.format("BONUS EXP: %." .. (idp or 0) .. "f%%   -   BASE EXP: ", num)
			end
			Hooks:Add("GameSetupUpdate", "GameSetupUpdate_id", function(t, dt)
				--xray
				if not _gameUpdateLastMark or t - _gameUpdateLastMark > 1 then
					_gameUpdateLastMark = t
					xray_manager:markEnemies()
				end
				--hud
				if PlayerManager.posPanel then
					local text = ""
					if managers.groupai and managers.groupai:state() then 
						text = round2(managers.groupai:state()._difficulty_value or 0,2)
						PlayerManager.posText:set_color(managers.groupai:state()._hunt_mode and Color(1,0,0) or managers.groupai:state()._enemy_weapons_hot and Color(255,215,0) or Color("CD7F32"))
					else
						text = round2(0,2)
						PlayerManager.posText:set_color(Color(0,1,1))
					end
					if managers.experience and managers.experience._global and managers.experience._global.mission_xp_current then
						text = text .. " " .. tostring(Application:digest_value(managers.experience._global.mission_xp_current, false)) or "None"
						
						for xpTime, xpText in pairs(PlayerManager.xpTexts) do
							if t < xpTime + 20 then
								text = text .. ", " .. xpText
							else
								table.remove(PlayerManager.xpTexts, xpTime)
							end
						end
					else
						text = text .. " 0"
					end
					PlayerManager.posText:set_text(text)
				else
					if managers.hud then
						local hud = managers.hud:script(PlayerBase.PLAYER_INFO_HUD_FULLSCREEN_PD2)
						PlayerManager.posPanel = hud.panel:panel({name = "positionpanel"})
						PlayerManager.posText = PlayerManager.posPanel:text({
							name = "textname",
							text = "texttext",
							font = tweak_data.hud.medium_font,
							font_size = tweak_data.hud.name_label_font_size,
							color = Color.green,
							align = "center",
							vertical = "top",
							layer = 1,
							w = 1300,
							h = 24
						})
					end
				end
			end)
			core:import("CoreMissionScriptElement")
			Hooks:Add("ElementExperienceOnExecuted", "ElementExperienceOnExecuted_id", function(instigator)
			--function ElementExperience.on_executed(self, instigator)
				if not self._values.enabled then
					return
				end
				local text = self._editor_name .. ": " .. self._values.amount
				local curTime = TimerManager:game():time()
				if PlayerManager.xpTexts[curTime] then 
					PlayerManager.xpTexts[curTime] = PlayerManager.xpTexts[curTime] .. ", " .. text
				else
					PlayerManager.xpTexts[curTime] = text
				end
				managers.experience:mission_xp_award(self._values.amount)
				ElementExperience.super.on_executed(self, instigator)
			end)
		end
	end

	if in_game() or is_playing() then
		return
	end

	--no job penalty and heat
	if in_main_menu() and Global then
		function JobManager:on_buy_job( job_id, difficulty_id ) return end
		for k,v in pairs(Global.job_manager.heat) do 
			managers.job:set_job_heat(k, 500) 
		end
	end

	--update spoofname
	function update_spoof_name()
		local name = CommandManager.config.fake_name
		if not managers.network:session() then
			return
		end
		managers.network:session():local_peer():set_name(name)
		for _, peer in pairs(managers.network:session():peers()) do
			peer:send("request_player_name_reply", name)
		end
	end
	update_spoof_name()

	--unlock skins
	local i = 1
	for id, data in pairs(tweak_data.blackmarket.weapon_skins) do
		while managers.blackmarket._global.inventory_tradable[i] ~= nil do
			i = i + 1
		end
		if not managers.blackmarket:have_inventory_tradable_item("weapon_skins", id) then
			managers.blackmarket:tradable_add_item(i, "weapon_skins", id, "mint", true, 1)
		end
	end
	function BlackMarketManager:tradable_update() end
	function GuiTweakData:tradable_inventory_sort_func(index)
		return nil
	end
end, true)