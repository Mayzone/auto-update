local orig = NetworkMatchMakingSTEAM.join_server
function NetworkMatchMakingSTEAM.join_server(self, room_id, skip_showing_dialog, quickplay)
	CommandManager["config"]["reconnect_id"] = room_id
	CommandManager:Save()
	orig(self, room_id, skip_showing_dialog, quickplay)
end