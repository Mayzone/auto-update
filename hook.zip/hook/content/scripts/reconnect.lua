if RequiredScript == "lib/network/matchmaking/networkmatchmakingsteam" then
	local orig = NetworkMatchMakingSTEAM.join_server
	function NetworkMatchMakingSTEAM.join_server(self, room_id, ...)
		if room_id then
			CommandManager["config"]["reconnect_id"] = room_id
			CommandManager:Save()
		end
		orig(self, room_id, ...)
	end
elseif RequiredScript == "lib/network/matchmaking/networkmatchmakingepic" then
	local orig = NetworkMatchMakingEPIC.join_server
	function NetworkMatchMakingEPIC.join_server(self, room_id, ...)
		if room_id then
			CommandManager["config"]["reconnect_id"] = room_id
			CommandManager:Save()
		end
		orig(self, room_id, ...)
	end
end