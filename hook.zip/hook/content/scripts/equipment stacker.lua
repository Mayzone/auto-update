if CommandManager.config["trainer_carry_specials_buffs"] then
	local class_name = "special_equipment_stacker"
 
	rawset(_G, class_name, {
		max_amount = 4,
		amount_to_pickup = 1,							-- Host only
		can_stack_very_special_equipment = true,		-- Set to true to be able to stack most items or false for keycards e.g
		use_whitelist = false,
		whitelist = {
			["bank_manager_key"] = {enable = true, amount = 2}
		}
	})
	 
	local c = _G[class_name]
	 
	function c:check_has_special_equipment_block_name(name)
		if name and self.can_stack_very_special_equipment then
			local t = tweak_data.interaction
			for k, v in pairs(t) do
				if type(k) == "string" and type(t[k]) == "table" and t[k].special_equipment_block ~= nil then
					if (type(t[k].special_equipment_block) == "string" and t[k].special_equipment_block == name or type(t[k].special_equipment_block) == "table" and t[k].special_equipment_block[name] ~= nil) then
						return true
					end
				end
			end
		end
	end
	
	function c:set_max_amount(equipment, amount)
		equipment.max_quantity = amount or c.max_amount
		equipment.quantity = c.amount_to_pickup
		
		if Network:is_server() then
			equipment.quantity = c.amount_to_pickup
		end
	end
	
	function PlayerManager:has_special_equipment(name, b)
		if not b and c:check_has_special_equipment_block_name(name) then
			return nil
		end
		return self._equipment.specials[name]
	end
	 
	Hooks:PreHook(BaseInteractionExt, "can_interact", class_name.."2", function(self, player)
		if self._tweak_data.special_equipment_block and c:check_has_special_equipment_block_name(self._tweak_data.special_equipment_block) then
			return true
		end
	 
		if not managers.player:has_special_equipment(self._tweak_data.special_equipment, true) then
			return false
		end
		
		if not managers.player:has_special_equipment(self._tweak_data.special_equipment) and c:check_has_special_equipment_block_name(self._tweak_data.special_equipment) then
			return true
		end
	end)
	 
	Hooks:PostHook(BaseInteractionExt, "selected", class_name.."3", function(self, player, locator, hand_id)
		if managers.player:has_special_equipment(self._tweak_data.special_equipment, true) and c:check_has_special_equipment_block_name(self._tweak_data.special_equipment) then
			self._hand_id = hand_id
			self._is_selected = true
			local string_macros = {}
	 
			self:_add_string_macros(string_macros)
	 
			local text_id = self._tweak_data.text_id or alive(self._unit) and self._unit:base().interaction_text_id and self._unit:base():interaction_text_id()
			local text = managers.localization:text(text_id, string_macros)
			local icon = self._tweak_data.icon
				
			if self._tweak_data.contour_preset or self._tweak_data.contour_preset_selected then
				if not self._selected_contour_id and self._tweak_data.contour_preset_selected and self._tweak_data.contour_preset ~= self._tweak_data.contour_preset_selected then
					self._selected_contour_id = self._unit:contour():add(self._tweak_data.contour_preset_selected)
				end
			else
				self:set_contour("selected_color")
			end
	 
			managers.hud:show_interact({
				text = text,
				icon = icon
			})
			return true
		end
	end)
	
	Hooks:PreHook(PlayerManager, "add_special", class_name.."4", function(self, params)
		local name = params.equipment or params.name
		local equipment = name and tweak_data.equipments.specials[name]
		if equipment and (not equipment.max_quantity or equipment.max_quantity < c.max_amount or not equipment.quantity or equipment.quantity <= 0) then
			if c.use_whitelist and c.whitelist[name] and c.whitelist[name].enable or not c.use_whitelist then
				c:set_max_amount(equipment, c.whitelist[name].amount)
			end
		end
	end)
end