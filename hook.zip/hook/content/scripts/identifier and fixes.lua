--mod match identifier 2-43
function NetworkPeer:set_ip_verified(state)
	self._ip_verified = state
	self:_chk_flush_msg_queues()

	if state then
		local user = Steam:user(self:ip())
		if user and user:rich_presence("hook_mod_identifier1712") == "1" then
			managers.chat:feed_system_message(ChatManager.GAME, string.format("%s Also got 'Hook' mod installed!", self:name()))
		end
	end
end

function NetworkAccountSTEAM:_set_presences()
	Steam:set_rich_presence("level", managers.experience:current_level())
	Steam:set_rich_presence("hook_mod_identifier1712", 1)

	if MenuCallbackHandler:is_modded_client() then
		Steam:set_rich_presence("is_modded", 1)
	else
		Steam:set_rich_presence("is_modded", 0)
	end
end

local _orig = BaseNetworkSession.on_load_complete
function BaseNetworkSession:on_load_complete(simulation)
	_orig(self, simulation)
	if not simulation then
		for peer_id, peer in pairs(self._peers) do
			if peer:ip_verified() then
				DelayedCalls:Add("player_"..peer._user_id, 5, function()
					if managers and managers.chat and alive(peer:unit()) and peer then
						local peer = managers.network:session():peer(1)
						local user = Steam:user(peer:ip())
						if user and user:rich_presence("hook_mod_identifier1712") == "1" then
							managers.chat:feed_system_message(ChatManager.GAME, string.format("Mayzone's hook detected from %s", peer:name() ) )
						end
					end
				end)
			end
		end
	end
end

--fixes lib/managers/gameplaycentralmanager.lua"]:634: attempt to call method 'flashlight_state_changed' (a nil value)
function GamePlayCentralManager:set_flashlights_on(flashlights_on)
	if self._flashlights_on == flashlights_on then
		return
	end

	self._flashlights_on = flashlights_on
	local weapons = World:find_units_quick("all", 13)

	for _, weapon in ipairs(weapons) do
		if weapon:base().flashlight_state_changed then
			weapon:base():flashlight_state_changed()
		end
	end
end

--fixes "lib/units/beings/player/states/playerdriving.lua"]:38: attempt to index local 'enter_data' (a nil value)
--try enter vehicle when civ mode
function PlayerDriving:enter(state_data, enter_data)
	PlayerDriving.super.enter(self, state_data, enter_data)
	for _, ai in pairs(managers.groupai:state():all_AI_criminals()) do
		if ai.unit:movement() and ai.unit:movement()._should_stay then
			ai.unit:movement():set_should_stay(false)
		end
	end

	if enter_data then
		self._was_unarmed = enter_data.was_unarmed
	else
		self._was_unarmed = false
		managers.chat:feed_system_message(ChatManager.GAME, "State: Standard")
	end
end

--lib/units/beings/player/playerdamage.lua"]:1839: attempt to perform arithmetic on field '_downed_paused_counter' (a nil value)
function PlayerDamage:pause_downed_timer(timer, peer_id)
    if not self._downed_paused_counter or self._downed_paused_counter == nil then
        self._downed_paused_counter = 0
    end
    self._downed_paused_counter = self._downed_paused_counter + 1

    self:set_peer_paused_counter(peer_id, "downed")

    if self._downed_paused_counter == 1 then
        managers.hud:pd_pause_timer()
        managers.hud:pd_start_progress(0, timer or tweak_data.interaction.revive.timer, "debug_interact_being_revived", "interaction_help")
    end

    if Network:is_server() then
        managers.network:session():send_to_peers("pause_downed_timer", self._unit)
    end
end--]]

--[string "lib/units/beings/player/playerdamage.lua"]:1839: attempt to perform arithmetic on field '_downed_paused_counter' (a nil value)
local origfunc_start_revive_player = UnitNetworkHandler.start_revive_player
function UnitNetworkHandler:start_revive_player(timer, sender, ...)
	if timer and not (timer == nil) then
		origfunc_start_revive_player(self, timer, sender, ...)
	end
end

--[string "lib/network/handlers/unitnetworkhandler.lua"]:3503: attempt to index local 'unit' (a nil value)
local origfunc_sync_drill_upgrades = UnitNetworkHandler.sync_drill_upgrades
function UnitNetworkHandler:sync_drill_upgrades(unit, autorepair_level_1, autorepair_level_2, drill_speed_level, silent, reduced_alert, ...)
	if not unit then
		return
	end
	origfunc_sync_drill_upgrades(self, unit, autorepair_level_1, autorepair_level_2, drill_speed_level, silent, reduced_alert, ...)
end

--[string "lib/managers/hintmanager.lua"]:85: attempt to index a nil value
--crash when hint table doesn't contain a hint
local orig_hint_func = UnitNetworkHandler.sync_show_hint
function UnitNetworkHandler:sync_show_hint(id, sender)
	if Global.hint_manager.hints[id] then
		orig_hint_func(self, id, sender)
	else
		local peer = self._verify_sender(sender)
		if not peer then
			managers.chat:_receive_message(1, "anti_hint_crash2", "Player not found, someone tried to hint crash you...", tweak_data.system_chat_color)
			return
		end
		managers.chat:feed_system_message(ChatManager.GAME, string.format("%s tried to crash you. %s crashed or kicked and added to ban list...", peer:name(), peer:name()))
		Steam:overlay_activate("url", string.format("https://pd2stash.com/pd2stats/stats.php?profiles=%s", peer._user_id))
		local identifier = "cheater_banned_" .. tostring(peer:id())
		managers.ban_list:ban(identifier, peer:name())
		managers.network:session():send_to_peer(peer, "sync_show_hint", tostring(Idstring("123")))

		if Network:is_server() then
			managers.network:session():send_to_peers("kick_peer", peer:id(), 6)
			managers.network:session():on_peer_kicked(peer, peer:id(), 6)
		end
	end
end

--[string "lib/network/handlers/unitnetworkhandler.lua"]:2920: attempt to perform arithmetic on a nil value
--convert enemy
function UnitNetworkHandler:mark_minion(unit, minion_owner_peer_id, convert_enemies_health_multiplier_level, passive_convert_enemies_health_multiplier_level, sender)
	if not self._verify_gamestate(self._gamestate_filter.any_ingame) or not self._verify_character_and_sender(unit, sender) then
		return
	end
	
	local health_multiplier = 1 * 0.55
	unit:character_damage():convert_to_criminal(health_multiplier)
	unit:contour():add("friendly", false)
	tweak_data.contour.character.friendly_color = tweak_data.peer_vector_colors[minion_owner_peer_id]
	managers.groupai:state():sync_converted_enemy(unit, minion_owner_peer_id)
	
	if minion_owner_peer_id == managers.network:session():local_peer():id() then
		managers.player:count_up_player_minions()
	end
end

--[string "lib/network/handlers/unitnetworkhandler.lua"]:264: attempt to call method 'sync_action_change_pose' (a nil value)
local origfunc_action_change_pose = UnitNetworkHandler.action_change_pose
function UnitNetworkHandler:action_change_pose(unit, pose_code, pos, ...)
    -- Unit must exist and be alive, unit must have a movement environment and must have a variable named sync_action_change_pose.
	-- pose_code and pos must be non-null values
    if (unit and alive(unit)) and (unit:movement() and unit:movement().sync_action_change_pose and pose_code and pos) then
		origfunc_action_change_pose(self, unit, pose_code, pos, ...)
    end
end--]]

--fixes other network functions
local origfunc_sync_unit_converted = UnitNetworkHandler.sync_unit_converted
function UnitNetworkHandler:sync_unit_converted(unit, ...)
	if alive(unit) and unit:brain() then
		return origfunc_sync_unit_converted(self, unit, ...)
	end
end

local origfunc_sync_tear_gas_grenade_properties = UnitNetworkHandler.sync_tear_gas_grenade_properties
function UnitNetworkHandler:sync_tear_gas_grenade_properties(grenade, ...)
	if grenade and grenade:base() then
		return origfunc_sync_tear_gas_grenade_properties(self, grenade, ...)
	end
end

local origfunc_sync_enter_vehicle_host = UnitNetworkHandler.sync_enter_vehicle_host
function UnitNetworkHandler:sync_enter_vehicle_host(vehicle, seat_name, peer_id, player, ...)
	if seat_name and peer_id and player then
		origfunc_sync_enter_vehicle_host(self, vehicle, seat_name, peer_id, player, ...)
	end
end

local orig_names = {
	'sync_sentrygun_dynamic',
	'sentrygun_ammo',
	'sentrygun_sync_armor_piercing',
	'sync_fire_mode_interaction',
	'sentrygun_health',
	'turret_idle_state',
	'turret_update_shield_smoke_level',
	'turret_repair',
	'turret_complete_repairing',
	'turret_repair_shield'
}

local origs = {}
for k,v in pairs(orig_names) do
	if UnitNetworkHandler[v] then
		origs[v] = UnitNetworkHandler[v]
		
		UnitNetworkHandler[v] = function(this, unit, ...)
			if unit then
				origs[v](this, unit, ...)
			end
		end
	end
end