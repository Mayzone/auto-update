if rawget(_G, "CommandManager") then
	if not CommandManager:in_chat() then
		rawset(_G, "CommandManager", nil)
	end
end

if not rawget(_G, "CommandManager") then
	rawset(_G, "CommandManager", {
		config = {},
		history = {},
		modules = {},
		path = "mods/hook/content/scripts/CommandManager/%s",
		path2 = "mods/hookloc/%s",
		command_prefixes = {"/", "!", "|", "\\"},
	})

	function CommandManager:LoadConfig()
		local file = JSON:jsonFile(string.format(self.path2, "config.json"))
		local data = JSON:decode(file)

		for _, v in pairs(data) do
			if type(v) == "table" then
				self.config = v
			end
		end
	end

	function CommandManager:Save()
		local file = io.open(string.format(self.path2, "config.json"), "w")
		local data = {
			["config"] = self.config
		}

		if file then
			local contents = JSON:encode_pretty(data)
			file:write( contents )
			io.close( file )
		else
			return
		end
	end

	function CommandManager:Addon(paths)
		if type(paths) == "table" then
			for _, path in pairs(paths) do
				dofile(string.format(self.path, path))
			end
			return
		end

		dofile(string.format(self.path, paths))
	end

	function CommandManager:Module(module_name)
		self.modules[module_name] = true
	end

	function CommandManager:prefixes(str)
		for _, prefix in pairs(self.command_prefixes) do
			if string.sub(str, 1, 1) == prefix then
				return true
			end
		end
	end

	function CommandManager:init()
		self:Addon({ "core/Commands.lua", "CustomCommands.lua", "Addons/JSON.lua", "Addons/Globals.lua" })
		self:Module("base")

		if self.modules["JSON"] then
			self:LoadConfig()
		end
	end

	CommandManager:init()
end