--returning string or C:Save() will save config
local C = CommandManager

C:add_command("rev", nil, nil, nil, function(args)
	local msg
	local text = ""
	for _,data in pairs(args) do
		text = string.format("%s¤%s", text, data)
		local msgfillter = string.gsub(text, "¤", " ")
		local msgfillter2 = string.sub(msgfillter, 2, string.len(msgfillter))
		msg = msgfillter2
	end
	if msg then
		local revs = string.reverse(msg)
		managers.chat:send_message(ChatManager.GAME, 1, revs)
	end
end)

C:add_command("sound", nil, nil, "playing", function(args)
	if not tonumber(args[1]) or tonumber(args[1]) and (tonumber(args[1]) < 1 or tonumber(args[1]) > 4) then
		return string.format("Argument 1 player id not valid: %s", args[1])
	end
	local id = tonumber(args[1]) or 1
	managers.player:player_unit():sound():play("cloaker_detect_mono", nil, true)
	local peer = managers.network:session():peer(id)
	local send, network
	if alive(peer:unit()) then
		network = peer:unit():network()
		send = network.send
	end
	if peer and send and network then
		send(network, "unit_sound_play", "cloaker_detect_mono", nil)
	end
end)

C:add_command("auto", nil, nil, nil, function(args)
	if not C.config.autosecure.enabled then
		C.config.autosecure.enabled = true
		C:Addon("Addons/autosecure.lua")
		return string.format("Auto Secure - ACTIVATED")
	else
		C.config.autosecure.enabled = false
		BetterDelayedCalls:Remove("auto_secure")
		return string.format("Auto Secure - DEACTIVATED")
	end
end)

C:add_command("automsg", nil, nil, nil, function(args)
	local arg = args[1]
	local arg2 = args[2]
	if not C.config.automsg.enabled and (args[1] == nil) then 
		C.config.automsg.enabled = true
		return string.format("Auto Message - ACTIVATED")
	elseif C.config.automsg.enabled and (args[1] == nil) then
		C.config.automsg.enabled = false
		return string.format("Auto Message - DEACTIVATED")
	end
	
	for _, data in pairs(args) do
		if not (data == "client" or data == "host" or data == "ref") and not arg2 then
			return string.format("Argument 1: %s is wrong. Example: automsg client/host", args[1])
		end
	end
	
	local msg
	local text = ""
	
	if (arg == "client") then
		if arg2 then
			for key, data in pairs(args) do
				if (key ~= 1) then
					text = string.format("%s¤%s", text, data)
					local msgfillter = string.gsub(text, "¤", " ")
					local msgfillter2 = string.sub(msgfillter, 2, string.len(msgfillter))
					if data == "reset" then
						C.config.automsg.clientmsg = "reset"
						msg = "default"
					else
						C.config.automsg.clientmsg = msgfillter2
						msg = msgfillter2
					end
				end
			end
			return string.format("Auto Message For Client Set '%s'", msg)
		else
			if not C.config.automsg.client then
				C.config.automsg.client = true
				return string.format("Auto Message For Client - ACTIVATED")
			else
				C.config.automsg.client = false
				CommandManager.config.automsg.checks.host_msg_recived = false
				CommandManager.config.automsg.checks.safe_msg_recived = false
				return string.format("Auto Message For Client - DEACTIVATED")
			end
		end
	end
	
	if (arg == "host") then
		if arg2 then
			for key, data in pairs(args) do
				if (key ~= 1) then
					text = string.format("%s¤%s", text, data)
					local msgfillter = string.gsub(text, "¤", " ")
					local msgfillter2 = string.sub(msgfillter, 2, string.len(msgfillter))
					if data == "reset" then
						C.config.automsg.hostmsg = "--- Welcome to the lobby ---"
						msg = "--- Welcome to the lobby ---"
					else
						C.config.automsg.hostmsg = msgfillter2
						msg = msgfillter2
					end
				end
			end
			return string.format("Auto Message For Host Set '%s'", msg)
		else		
			if not C.config.automsg.host then
				C.config.automsg.host = true
				return string.format("Auto Message For Host - ACTIVATED")
			else
				C.config.automsg.host = false
				return string.format("Auto Message For Host - DEACTIVATED")
			end
		end
	end
	
	if (arg == "ref") then
		CommandManager.config.automsg.checks.host_msg_recived = false
		CommandManager.config.automsg.checks.safe_msg_recived = false
		return string.format("Auto Message Refreshed")
	end
end)

C:add_command("autothrow", nil, nil, "playing", function(args)
	--hit_body:extension().damage:damage_damage(user_unit, normal, hit_body:position(), dir, damage)
	--[[function ray_pos()
		local unit = managers.player:player_unit()
		if (alive(unit)) then
			local from
			local to
			local m_head_rot
			m_head_rot = unit:movement():m_head_rot()
			from = unit:movement():m_head_pos()
			to = unit:movement():m_head_pos() + m_head_rot:y() * 99999

			local ray = World.raycast(World, "ray", from, to, "slot_mask", managers.slot:get_mask("trip_mine_placeables"), "ignore_unit", {})
			if (ray) then
				return ray.position, Rotation( m_head_rot:yaw(), 0, 0 )
			end
		end
	end
	managers.network:session():send_to_host("request_throw_projectile", "frag", Vector3(ray_pos().x, ray_pos().y, ray_pos().z), nil)
	--]]
end)

C:add_command("cook", nil, nil, nil, function(args)
	dofile("mods/hook/content/scripts/autocooker.lua")
end)

C:add_command("event", nil, nil, "playing", function(args)
	local id = tonumber(args[1])
	local times = tonumber(args[2]) or 1
	if (args[1] == nil) then
		return string.format("Argument 1: %s is wrong. Example: event id/name 2", args[1])
	end
	if id then
		for i=1, times do
			C:trigger_mission_element(id)
		end
		return string.format("Executed %s %s times", id, times)
	else
		for i=1, times do
			for _, script in pairs(managers.mission:scripts()) do
				for id, element in pairs(script:elements()) do
					if (element._editor_name == args[1]) or (element._editor_name:lower() == args[1]) then
						C:trigger_mission_element(element._id)
						return string.format("Executed %s with id %d %s times", element._editor_name, element._id, times)
					end
				end
			end
		end
	end
end)

C:add_command("killloop", nil, nil, "playing", function(args)
	local arg = tonumber(args[1])
	local msg
	if arg then
		C.config.killloop.speed = arg
		msg = string.format("Kill Speed - %s", arg)
	else
		global_kill_loop = global_kill_loop or false
		if not global_kill_loop then
			C:Addon("Addons/killloop.lua")
			msg = string.format("Kill Loop - ACTIVATED")
		else
			BetterDelayedCalls:Remove("kill_loop")
			msg = string.format("Kill Loop - DEACTIVATED")
		end
		global_kill_loop = not global_kill_loop
	end
	if msg then
		return msg
	end
end)

C:add_command("i", nil, nil, "playing", function(args)
	local data = args[1] or "?"
	local times = tonumber(args[2]) or 1
	local list = ""
	if data == "?" then
		for _, interaction in pairs(C:TrackInteracts()) do
			list = list..", "..interaction
		end
		return list
	else
		for i=1, times do
			C:interact(data)
		end
		return string.format("%d interaction(s) with the name '%s' were made", times, data)
	end
end)

C:add_command("shadowraid", nil, nil, "playing", function(args)
	C:trigger_mission_element(102972)
	-- C:trigger_mission_element(103464)
	return string.format("Event: Secure in trucks")
end)

C:add_command("cookoff", nil, nil, "playing", function(args)
	C:trigger_mission_element(102060)
	return string.format("Event: Zipline")
end)

C:add_command("noclip", nil, nil, "playing", function(args)
	local arg = tonumber(args[1])
	if arg then
		C.config.noclip.speed = arg
		return string.format("NoClip Speed - %s", arg)
	else
		if not C.config.noclip.enabled and not global_toggle_noclip then
			C:Addon("Addons/noclip.lua")
			C.config.noclip.enabled = true
			return string.format("NoClip - ACTIVATED")
		else
			if global_toggle_noclip then
				global_toggle_noclip = not global_toggle_noclip
			end
			C.config.noclip.enabled = false
			DelayedCalls:Add( "fall_dmg_off", 10, function()
				if global_fall_dmg then PlayerDamage.damage_fall = global_fall_dmg end
			end)
			BetterDelayedCalls:Remove("no_clip_loop")
			return string.format("NoClip - DEACTIVATED")
		end
	end
end)

C:add_command("pm", nil, nil, nil, function(args)
	local peers = C:get_peers(args[1])
	if peers then
		for _, peer in pairs(peers) do
			local text = ""
			for i, msg in pairs(args) do 
				if i ~= 1 then
					text = string.format("%s %s", text, msg)
				end
			end

			C:Send_Message(peer, string.format("[PRIVATE]: %s", text))
			return string.format("Private Message sent to %s.", managers.network:session():peer(peer):name())
		end
	end
end)

C:add_command("l", nil, nil, nil, function(args)
	C:process_input(C.history[1], peer_id)
end)

C:add_command("r", nil, nil, nil, function(args)
	if C.peer_to_reply then
		local text = ""
		for i, msg in pairs(args) do 
			text = string.format("%s %s", text, msg)
		end

		C:Send_Message(C.peer_to_reply:id(), string.format("[PRIVATE]: %s", text))
		return string.format("Private Message sent to %s.", C.peer_to_reply:name())
	end
end)

C:add_command("respawn", nil, nil, "playing", function(args)
	IngameWaitingForRespawnState:request_player_spawn()
end)

C:add_command("spawns", "host", nil, "playing", function(args)
	local elem_names = {}
	local arg = args[1] or "sniper" or "cop" or "dozer" or "thug" or "shield" or "swat" or "tazer" or "captain" or "cloaker" or "a"
	if (arg == "sniper") then
		table.insert(elem_names, "sniper")
	elseif (arg == "cop") then
		table.insert(elem_names, "cop")
	elseif (arg == "dozer") then
		table.insert(elem_names, "dozer")
	elseif (arg == "thug") then
		table.insert(elem_names, "gangster")
		table.insert(elem_names, "thug")
	elseif (arg == "shield") then
		table.insert(elem_names, "shield")
	elseif (arg == "swat") then
		table.insert(elem_names, "swat")
		table.insert(elem_names, "ai_spawn_")
	elseif (arg == "tazer") then
		table.insert(elem_names, "tazer")
	elseif (arg == "phalanx") then
		table.insert(elem_names, "captain")
	elseif (arg == "cloaker") then
		table.insert(elem_names, "cloaker")
	elseif (arg == "all") then
		elem_names = {"ai_spawn_", "cop", "cloaker", "dozer", "gangster", "shield", "sniper", "swat", "tazer", "thug", "phalanx"}
	end
	for _, data in pairs(managers.mission._scripts) do
		for _, element in pairs(data:elements()) do
			if element and element._values and element._values.enabled then
				for _, name in pairs(elem_names) do
					if string.startswith(element._editor_name, name) then
						element._values.enabled = false
						return string.format("Spawn: %s DEACTIVATED", name)
					end
				end
			end
		end
	end
end)

C:add_command("state", nil, nil, "playing", function(args)
	if not tonumber(args[1]) or tonumber(args[1]) and (tonumber(args[1]) < 1 or tonumber(args[1]) > 4) then
		return string.format("Argument 1 player id not valid: %s", args[1])
	end
	local ids = managers.network:session():peer(tonumber(args[1])) or managers.network:session():peer(1)
	if ids then
		for _, id in pairs(ids) do
			local arg
			local peer = managers.network:session():peer(id)
			if peer and alive(peer:unit()) and peer:id() ~= lpeer_id then
				if (args[2] == "kill") then
					arg = "incapacitated"
				elseif (args[2] == "cuff") then
					arg = "arrested"
				elseif (args[2] == "tase") then
					arg = "tased"
				elseif (args[2] == "standard") then
					arg = "standard"
				else
					arg = args[2] or "standard"
				end
				if arg then
					peer:unit():network():send("sync_player_movement_state", arg, 0, peer:unit():id())
					return string.format("%s", string.format("%s's state has been changed to %s", peer:name(), arg))
				end
			end
		end
	end
end)

C:add_command("cheatn", nil, nil, "playing", function(args)
	if not tonumber(args[1]) or tonumber(args[1]) and (tonumber(args[1]) < 1 or tonumber(args[1]) > 4) then
		return string.format("Argument 1 player id not valid: %s. Example: cheatn 2 noob 120 120 120", args[1])
	end
	local id = tonumber(args[1]) or 1
	local peer = managers.network:session():peer(id)
	if peer then
		--tweak_data.screen_colors.pro_color
		--tweak_data.screen_colors.crime_spree_risk
		local tag = args[2] or "cheater"
		local _color
		local string_msg
		
		if (args[3] and args[4] and args[5]) then
			local r, g, b = tonumber(args[3])/255, tonumber(args[4])/255, tonumber(args[5])/255
			_color = Color(r, g, b)
			string_msg = string.format("Name Saved: %s %s %s %s %s", peer:name(), args[2], args[3], args[4], args[5])
		else
			_color = tweak_data.screen_colors.crime_spree_risk
			string_msg = string.format("Name Saved: %s %s", peer:name(), tag)
		end

		local name_label = managers.hud:_name_label_by_peer_id(id)
		if name_label and _color and string_msg then
			name_label.panel:child("cheater"):set_visible(true)
			name_label.panel:child("cheater"):set_text(tag:upper())
			name_label.panel:child("cheater"):set_color(_color)
			return string_msg
		end
	end
end)

C:add_command("leveln", nil, nil, nil, function(args)
	if not tonumber(args[1]) or tonumber(args[1]) and (tonumber(args[1]) < 1 or tonumber(args[1]) > 4) then
		return string.format("Argument 1 player id not valid: %s", args[1])
	end
	if not tonumber(args[2]) or tonumber(args[2]) and (tonumber(args[2]) < 1 or tonumber(args[2]) > 100) then
		return string.format("Argument 2 player level not valid: %s", args[2])
	end
	local id = tonumber(args[1]) or 1
	local peer = managers.network:session():peer(id)
	if peer then
		peer:set_level(tonumber(args[2]))
	end
	managers.network:session():send_to_peers_synched("sync_level_up", tonumber(args[1]), tonumber(args[2]))
	return string.format("Level Saved: %s %s", peer:name(), args[2])
end)

C:add_command("steamn", nil, nil, nil, function(args)
	local id = tonumber(args[1])
	local peer = managers.network:session():peer(id)
	local arg
	for i = 1,4 do
		if id and not (id < 1) and not (id > 4) and (id == i) and peer then
			arg = peer:name()
			break
		else
			arg = args
		end
	end
	
	local name = ""
	if (type(arg) == "string" and arg == peer:name()) then
		C.config.fake_name = arg
	elseif (args[1] == nil) then
		C.config.fake_name = ""
	else
		for i, msg in pairs(arg) do
			if (msg == "reset") then
				C.config.fake_name = Steam:username()
			elseif (msg == "ref") then
				if C:is_playing() then
					managers.player:force_drop_carry()
					managers.statistics:downed({death = true})
					IngameFatalState.on_local_player_dead()
					game_state_machine:change_state_by_name("ingame_waiting_for_respawn")
					managers.player:local_player():character_damage():set_invulnerable(true)
					managers.player:local_player():character_damage():set_health(0)
					managers.player:local_player():base():_unregister()
					managers.player:local_player():base():set_slot(managers.player:local_player(), 0)
					DelayedCalls:Add("respawn_for_update_name", 0.7, function()
						IngameWaitingForRespawnState.request_player_spawn()
					end)
				end
			else
				name = string.format("%s¤%s", name, msg)
				local msgfillter = string.gsub(name, "¤", " ")
				local msgfillter2 = string.sub(msgfillter, 2, string.len(msgfillter))
				C.config.fake_name = msgfillter2
			end
		end
	end
	C:Save()
	update_spoof_name()
	return string.format("Name Saved: %s", C.config.fake_name)
end)

C:add_command("tase", nil, nil, "playing", function(args)
	local peer = managers.network:session():peer(tonumber(args[1]))
	if peer and alive(peer:unit()) and peer:id() ~= lpeer_id then
		unit = peer:unit()
		if peer.inf_tase == nil then -- only create loop one time (saves cpu).
			peer.inf_tase = true
			for i = 1, 100 do
				managers.enemy:add_delayed_clbk("_"..i, function()
					if peer.inf_tase then
						unit:network():send("sync_player_movement_state", "standard", 0, unit:id())
						unit:network():send("sync_player_movement_state", "tased", 0, unit:id())
					end
				end, Application:time() + (9 * i))
			end
		else
			peer.inf_tase = true
		end
	end
end)
	
C:add_command("stoptase", nil, nil, "playing", function(args)
	local peer_id = tonumber(args[1])
	local peer = managers.network:session():peer(peer_id)
	if not peer_id then
		managers.player:set_player_state("standard")
		return string.format("Tase stopped for you")
	elseif peer and alive(peer:unit()) and peer.inf_tase then
		peer.inf_tase = false
		return string.format("Tase stopped for %s", peer:name())
	elseif not peer or not alive(peer:unit()) then
		return string.format("Player not found")
	end
end)

C:add_command("so", nil, nil, nil, function(args)
	if peer_id == lpeer_id then
		local peerid = tonumber(args[1])
		local peer = managers.network and managers.network:session():peer(peerid)
		if peer then
			if args[2] == "p" then
				Steam:overlay_activate("url", string.format("http://steamcommunity.com/profiles/%s/", peer._user_id))
			else
				Steam:overlay_activate("url", string.format("https://pd2stash.com/pd2stats/stats.php?profiles=%s", peer._user_id))
			end
		end
	end
end)

C:add_command("list", nil, nil, nil, function(args)
	local peerid = managers.network:session():peer(tonumber(args[1]))
	local list = ""

	if not peerid or peerid and (peerid < 1 or peerid > 4) then
		local tab = {}

		for x = 1, 4 do
			if managers.network:session():peer(x) then
				if managers.network:session():peer(x):id() then
					table.insert(tab, x)
				end
			end
		end
		for _, id in pairs(tab) do
			local peer = managers.network:session():peer(id)
			list = string.format("%s\n(%s) %s\n", list, peer:id(), peer:name())
		end
	end
	return string.format("Player List:%s", list)
end)

C:add_command("timer", nil, nil, "playing", function(args)
	local newvalue = tonumber(args[1]) or 300
	for _,unit in pairs(World:find_units_quick("all", 1)) do
		local timer = unit:base() and unit:timer_gui() and unit:timer_gui()._current_timer
		if timer and math.floor(timer) ~= -1 then
			unit:timer_gui():_start(newvalue)

			if managers.network:session() then
				managers.network:session():send_to_peers_synched("start_timer_gui", unit:timer_gui()._unit, newvalue)
			end
			
			if not unit:timer_gui()._jammed then
				unit:timer_gui():set_jammed(true)
			end
		end
	end
	return string.format("Time set: %ssec", newvalue)
end)

C:add_command("afk", nil, nil, nil, function(args)
	local toggle_afk = true

	function release_announcement()
		BetterDelayedCalls:Remove("afk_long_persist")
		BetterDelayedCalls:Remove("afk_long_persist2")
		if not alive(managers.player:player_unit()) then
			if orig_func_md then PlayerStandard._determine_move_direction = orig_func_md end
			IngameWaitingForRespawnState.request_player_spawn()
			if global_invisible_toggle then
				dofile("mods/hook/content/scripts/invisibleplayer.lua")
			end
		end
		managers.chat:send_message(ChatManager.GAME, 1, "has come back and is no longer AFK.")
	end
	
	global_afk_toggle = global_afk_toggle or false
	if not global_afk_toggle then
		if C:is_playing() then
			if (managers.player:current_state() == "standard") and alive(managers.player:player_unit()) then
				managers.chat:send_message(ChatManager.GAME, 1, "has gone AFK. He will not be a targeted by enemies while gone.")
				if not global_invisible_toggle then
					dofile("mods/hook/content/scripts/invisibleplayer.lua")
				end
				if not orig_func_md then orig_func_md = PlayerStandard._determine_move_direction end
				function PlayerStandard:_determine_move_direction(...)
					orig_func_md(self, ...)
					if self._move_dir or self._normal_move_dir
					or (self._controller:get_input_bool("primary_attack")) 
					--or (self._controller:get_input_bool("secondary_attack")) 
					--or (self._controller:get_input_pressed("throw_grenade"))
					--or (self._controller:get_input_pressed("duck"))
					or (self._controller:get_input_pressed("reload")) 
					or (self._controller:get_input_pressed("switch_weapon")) 
					or (self._controller:get_input_pressed("jump")) 
					or (self._controller:get_input_pressed("interact")) 
					or (self._controller:get_input_pressed("use_item")) 
					or (self._controller:get_input_pressed("melee")) then
						if toggle_afk then
							if global_invisible_toggle then
								dofile("mods/hook/content/scripts/invisibleplayer.lua")
							end
							toggle_afk = false
							global_afk_toggle = not global_afk_toggle
							release_announcement()
						end
					end
				end
				BetterDelayedCalls:Add("afk_long_persist", 120, function() 
					managers.chat:send_message(ChatManager.GAME, 1, "has been AFK more then 2min. 8min left before going to jail.")
					BetterDelayedCalls:Add("afk_long_persist2", 480, function() 
						local player = managers.player:local_player()
						managers.player:force_drop_carry()
						managers.statistics:downed({death = true})
						IngameFatalState.on_local_player_dead()
						game_state_machine:change_state_by_name("ingame_waiting_for_respawn")
						player:character_damage():set_invulnerable(true)
						player:character_damage():set_health(0)
						player:base():_unregister()
						player:base():set_slot(player, 0)
						managers.chat:send_message(ChatManager.GAME, 1, "has been jailed for AFKing and will be released when back.")
					end, false)
				end, false)
			else
				global_afk_toggle = not global_afk_toggle
				managers.chat:_receive_message(1, "AFK", "Can only be used when masked.", tweak_data.system_chat_color)
			end
		else
			managers.chat:send_message(ChatManager.GAME, 1, "has gone AFK.")
		end
	else
		if C:is_playing() and turn_off_wlk and global_invisible_toggle then
			dofile("mods/hook/content/scripts/invisibleplayer.lua")
		end
		release_announcement()
	end
	global_afk_toggle = not global_afk_toggle
end)

C:add_command("im", nil, nil, nil, function(args)
	dofile("mods/hook/content/scripts/menus/mainmenu.lua")
end)
C:add_command("mm", nil, nil, nil, function(args)
	dofile("mods/hook/content/scripts/menus/missionmenu.lua")
end)
C:add_command("tm", nil, nil, nil, function(args)
	dofile("mods/hook/content/scripts/menus/teammainmenu.lua")
end)
C:add_command("sm", nil, nil, nil, function(args)
	dofile("mods/hook/content/scripts/menus/spawnmenu.lua")
end)
C:add_command("pgm", nil, nil, nil, function(args)
	dofile("mods/hook/content/scripts/menus/pregamemenu.lua")
end)
C:add_command("mgm", nil, nil, nil, function(args)
	dofile("mods/hook/content/scripts/menus/magicmenu.lua")
end)
C:add_command("gm", nil, nil, nil, function(args)
	dofile("mods/hook/content/scripts/menus/godmodemenu.lua")
end)
C:add_command("xray", nil, nil, nil, function(args)
	dofile("mods/hook/content/scripts/xray.lua")
end)
C:add_command("xrayteam", nil, nil, nil, function(args)
	dofile("mods/hook/content/scripts/xrayshare.lua")
end)
C:add_command("aimbot", nil, nil, nil, function(args)
	dofile("mods/hook/content/scripts/aimbot1.lua")
end)
C:add_command("aimbot2", nil, nil, nil, function(args)
	dofile("mods/hook/content/scripts/aimbot2.lua")
end)
C:add_command("win", nil, nil, nil, function(args)
	dofile("mods/hook/content/scripts/win.lua")
end)
C:add_command("lose", nil, nil, nil, function(args)
	dofile("mods/hook/content/scripts/lose.lua")
end)
C:add_command("ref", nil, nil, nil, function(args)
	dofile("mods/hook/content/scripts/refresh.lua")
end)
C:add_command("secureall", nil, nil, nil, function(args)
	dofile("mods/hook/content/scripts/secureall.lua")
end)
C:add_command("killall", nil, nil, nil, function(args)
	dofile("mods/hook/content/scripts/killall.lua")
end)
C:add_command("killbg", nil, nil, nil, function(args)
	dofile("mods/hook/content/scripts/killbaggrab.lua")
end)
C:add_command("killplayers", nil, nil, nil, function(args)
	dofile("mods/hook/content/scripts/killplayers.lua")
end)
C:add_command("ivw", nil, nil, nil, function(args)
	dofile("mods/hook/content/scripts/invisiblewalls.lua")
end)
C:add_command("carry", nil, nil, nil, function(args)
	dofile("mods/hook/content/scripts/carrystacker.lua")
end)
C:add_command("ce", nil, nil, nil, function(args)
	dofile("mods/hook/content/scripts/menus/correctenginemenu.lua")
end)
C:add_command("ca", nil, nil, nil, function(args)
	dofile("mods/hook/content/scripts/convertall.lua")
end)
C:add_command("randomlootspawn", nil, nil, nil, function(args)
	dofile("mods/hook/content/scripts/randomlootspawn.lua")
end)
C:add_command("wp", nil, nil, nil, function(args)
	dofile("mods/hook/content/scripts/waypoints2.lua")
end)
C:add_command("wp2", nil, nil, nil, function(args)
	dofile("mods/hook/content/scripts/waypoints.lua")
end)
C:add_command("spick", nil, nil, nil, function(args)
	dofile("mods/hook/content/scripts/mainmenu.lua")
end)
C:add_command("drill", nil, nil, nil, function(args)
	dofile("mods/hook/content/scripts/drill.lua")
end)
C:add_command("inv", nil, nil, nil, function(args)
	dofile("mods/hook/content/scripts/invisibleplayer.lua")
end)
C:add_command("ps", nil, nil, nil, function(args)
	dofile("mods/hook/content/scripts/pagersnitch.lua")
end)

C:add_command("test", nil, nil, nil, function(args)
	dofile("mods/hook/content/test.lua")
end)

C:add_command("h", nil, nil, nil, function(args)
	local index = tonumber(args[1]) or 1
	if index and (index >= 1) then
		local msg_table = {}
		if (index == 1) then
			managers.chat:feed_system_message(ChatManager.GAME, string.format("To use the commands you must apply either of these signs ( %s %s %s )", C.command_prefixes[1], C.command_prefixes[2], C.command_prefixes[3]))
			table.insert(msg_table, "Every command can have diffrent amount of arguments, arguments are not always needed. This will tag host as cheater example: !cheatn 1 hello 120 255 0")
			table.insert(msg_table, "Use !list to display every player id in the lobby")
			table.insert(msg_table, "More commands: !h 2")
		elseif (index > 5) then
			table.insert(msg_table, string.format("Page: %d", index))
			table.insert(msg_table, string.format("Invalid page selected, must be 1 to 5", index))
		elseif (index == 2) then
			table.insert(msg_table, string.format("Page: %d/5 - General", index))
			table.insert(msg_table, string.format("!h, !list, !pm <2> <msg>, !r, !so <2/2 p>, !automsg <client/host/ref> <any message>, !state <2> <tase/kill/cuff/standard>, !steamn <anything/2/reset/ref> !cheatn <2> <msg> <r g b>, !leveln <2> <level> !sound <2>, !rev <reverse everything you say>"))
		elseif (index == 3) then
			table.insert(msg_table, string.format("Page: %d/5 - Quick", index))
			table.insert(msg_table, string.format("!killloop <1>, !respawn, !spawns <cop/swat/sniper/dozer/thug/shield/tazer/captain/cloaker/all>, !noclip <1>, !ps, !inv, !xray, !xrayteam, !aimbot, !aimbot2, !win, !lose, !ref, !timer, !drill, !auto, !cook, !event, !i <?/cut_fence> <amount>, !killall, !killbg, !killplayers, !ivw, !carry, !ce, !ca, !rls, !wp, !wp2, !sammo, !randomlootspawn"))
		elseif (index == 4) then
			table.insert(msg_table, string.format("Page: %d/5 - Menus", index))
			table.insert(msg_table, string.format("!mm, !tm, !sm, !pgm, !mgm, !gm, !im"))
		elseif (index == 5) then
			table.insert(msg_table, string.format("Page: %d/5 - Heist", index))
			table.insert(msg_table, string.format("!shadowraid"))
		end
		for _,data in pairs(msg_table) do
			local msgfilter = string.gsub(data, "!", C.command_prefixes[1])
			managers.chat:feed_system_message(ChatManager.GAME, string.format(msgfilter))
		end
	end
end)

C:Module("Commands")