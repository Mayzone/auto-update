local orig_GPCM = GamePlayCentralManager.start_heist_timer
function GamePlayCentralManager.start_heist_timer(self)
	orig_GPCM(self)
	dofile(CommandManager.config.afk.path.."Addons/afktimer.lua")
	if CommandManager.config.automsg.checks.host_msg_recived then
		CommandManager.config.automsg.checks.host_msg_recived = false
	end
	if CommandManager.config.automsg.checks.safe_msg_recived then
		CommandManager.config.automsg.checks.safe_msg_recived = false
	end
	CommandManager:Save()
end