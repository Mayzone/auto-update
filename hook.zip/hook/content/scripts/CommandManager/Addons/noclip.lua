function CommandManager:update_position()
	local camera = managers.player:player_unit():camera()
	local camera_rot = camera:rotation()
	local move_dir = camera_rot:x() * self.config.noclip.axis_move.y + camera_rot:y() * self.config.noclip.axis_move.x + camera_rot:z() * self.config.noclip.axis_move.z
	local move_delta = move_dir * 10
	local pos_new = managers.player:player_unit():position() + move_delta

	managers.player:warp_to( pos_new, camera_rot, 1, Rotation(0, 0, 0) )
end

function CommandManager:noclip_update()
	local kb = Input:keyboard()
	local kb_down = kb.down
	local player = managers.player:player_unit()

	if not player or not alive(player) then
		return
	end
	
	self:update_position()
	
	if not self:in_chat() then
		self.config.noclip.axis_move.x = (kb_down( kb, Idstring("w") )     and self.config.noclip.speed) or (kb_down( kb, Idstring("s") )         and -self.config.noclip.speed) or 0
		self.config.noclip.axis_move.y = (kb_down( kb, Idstring("d") )     and self.config.noclip.speed) or (kb_down( kb, Idstring("a") )         and -self.config.noclip.speed) or 0
		self.config.noclip.axis_move.z = (kb_down( kb, Idstring("space") ) and self.config.noclip.speed) or (kb_down( kb, Idstring("left ctrl") ) and -self.config.noclip.speed) or 0
 	end
end

BetterDelayedCalls:Add("no_clip_loop", 0.01, function()
	if not CommandManager:is_playing() then return end
	--no fall dmg
	if not global_fall_dmg then global_fall_dmg = PlayerDamage.damage_fall end
	function PlayerDamage:damage_fall(data)
		return false
	end
	CommandManager:noclip_update()
end, true)

CommandManager:Module("noclip")