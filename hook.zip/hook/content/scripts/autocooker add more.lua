function is_playing()
	if not BaseNetworkHandler then 
		return false 
	end
	return BaseNetworkHandler._gamestate_filter.any_ingame_playing[ game_state_machine:last_queued_state_name() ]
end

if not is_playing() then
	return
end

id_level = managers.job:current_level_id()
if not (id_level == 'cane' or id_level == 'mex_cooking' or id_level == 'alex_1' or id_level == 'rat' or id_level == 'crojob2' or id_level == 'mia_1') then
	return
end

Color.gold = Color("FFD700")
if global_toggle_meth then
	bag_amount = bag_amount + 1
	managers.mission._fading_debug_output:script().log(tostring(bag_amount)..' More Meth - ACTIVATED',  Color.gold)
else
	managers.chat:feed_system_message(ChatManager.GAME, "Enable Autocooker First")
end