local identifier = "invisible_player_attention"
local class_name = string.format("G_%s", identifier)

if not rawget(_G, class_name) then
	rawset(_G, class_name, {toggle = true})
else
	_G[class_name].toggle = not _G[class_name].toggle
end

local c = Utils:IsInHeist() and _G[class_name]

local ran = pcall(managers.mission._fading_debug_output:script().log, string.format("%s %s", identifier, (c.toggle and " - ACTIVATED" or " - DEACTIVATED")), (c.toggle and Color.green or Color.red))
if c and ran then
	local function toggle_ai_state(state)
		for _, u_data in pairs(managers.enemy:all_enemies()) do
			if alive(u_data.unit) then
				u_data.unit:brain():set_active(state)
				u_data.unit:brain():set_attention_settings({peaceful = not state})
			end
		end
		
		for _, u_data in pairs(managers.enemy:all_civilians()) do
			if alive(u_data.unit) then
				u_data.unit:brain():set_active(state)
				u_data.unit:brain():set_attention_settings({peaceful = not state})
			end
		end
		
		for _, unit in pairs(SecurityCamera.cameras) do
			if unit:base()._last_detect_t ~= nil and not unit:base()._destroyed then
				unit:base():set_update_enabled(state)
			end
		end
	end
	
	if c.toggle then
		--pcall(toggle_ai_state, false)
	else
		--pcall(toggle_ai_state, true)
	end
	
	local function update_invisible_state(state)
		managers.player:player_unit():movement():set_attention_settings(state)
	end
	
	Hooks:PostHook(HUDManager, "update", class_name, function()
		if c.toggle then
			pcall(update_invisible_state, {"pl_civilian"})
		else
			Hooks:RemovePostHook(class_name)
			pcall(update_invisible_state, {"pl_mask_on_foe_combatant_whisper_mode_stand", "pl_mask_on_foe_combatant_whisper_mode_crouch"})
		end
	end)
end
