-- invisible player client/host
local function update_invisible_state(state)
	local player_unit = managers.player:player_unit()
	if alive(player_unit) and player_unit:movement() then
		player_unit:movement():set_attention_settings({state})
	end
end

--[[local orig = HUDManager.update
function HUDManager.update(self, t, dt)
	orig_func_update(self, t, dt)
	if global_invisible_toggle then
		update_invisible_state("pl_civilian")
	end
end--]]

global_invisible_toggle = global_invisible_toggle or false
if not global_invisible_toggle then
	BetterDelayedCalls:Add("invisible_persist", 0.2, function()
		update_invisible_state("pl_civilian")
	end, true)
	managers.mission._fading_debug_output:script().log('Invisible - ACTIVATED',  Color.green)
else
	update_invisible_state("pl_mask_on_foe_combatant_whisper_mode_stand")
	update_invisible_state("pl_mask_on_foe_combatant_whisper_mode_crouch")
	BetterDelayedCalls:Remove("invisible_persist")
	managers.mission._fading_debug_output:script().log('Invisible - DEACTIVATED',  Color.red)
end
global_invisible_toggle = not global_invisible_toggle