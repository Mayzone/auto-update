local identifier = "invisible_player_attention"
local class_name = string.format("G_%s", identifier)

if not rawget(_G, class_name) then
	rawset(_G, class_name, {toggle = true})
else
	_G[class_name].toggle = not _G[class_name].toggle
end

local c = Utils:IsInHeist() and _G[class_name]

local ran = pcall(managers.mission._fading_debug_output:script().log, string.format("%s %s", identifier, (c.toggle and " - ACTIVATED" or " - DEACTIVATED")), (c.toggle and Color.green or Color.red))
if c ~= nil and ran then
	local function update_invisible_state(state)
		managers.player:player_unit():movement():set_attention_settings(state)
	end

	Hooks:PostHook(HUDManager, "update", class_name, function()
		if c.toggle then
			pcall(update_invisible_state, {"pl_civilian"})
		else
			Hooks:RemovePostHook(class_name)
			pcall(update_invisible_state, {"pl_mask_on_foe_combatant_whisper_mode_stand", "pl_mask_on_foe_combatant_whisper_mode_crouch"})
		end
	end)
end
