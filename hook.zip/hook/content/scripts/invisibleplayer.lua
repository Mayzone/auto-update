-- invisible player client/host
function update_invisible_state(state)
	--if not invisible_client then invisible_client = PlayerStandard.update end
	local statetable = {
		"Standard",
		"Civilian",
		"MaskOff",
		"Clean",
		"BleedOut",
		"ParaChuting",
		"Incapacitated",
		"Carry",
		"Arrested",
	}
	if alive(managers.player:player_unit()) then
		for id,state_table in pairs(statetable) do
			Hooks:Add("Player"..state_table.."Update", "UpdateMovState"..id , function(t, dt)
				self:_upd_attention()
			end)
		end
		managers.player:player_unit():movement():set_attention_settings({state})
	end
end

global_invisible_toggle = global_invisible_toggle or false
if not global_invisible_toggle then
	BetterDelayedCalls:Add("invisible_persist", 0.2, function()
		update_invisible_state("pl_civilian")
	end, true)
	--[[if not orig then orig = HUDManager.update end
	local orig = HUDManager.update
	function HUDManager:update(t, dt)
		orig(self, t, dt)
		update_invisible_state("pl_civilian")
	end--]]
	managers.mission._fading_debug_output:script().log('Invisible - ACTIVATED',  Color.green)
else
	update_invisible_state("pl_mask_on_foe_combatant_whisper_mode_stand")
	--if orig then HUDManager.update = orig end
	BetterDelayedCalls:Remove("invisible_persist")
	managers.mission._fading_debug_output:script().log('Invisible - DEACTIVATED',  Color.red)
end
global_invisible_toggle = not global_invisible_toggle