local mod_name = "Mayzones_Aimbot"
local loaded = rawget(_G, mod_name)
local c = loaded or rawset(_G, mod_name, {
	draw_targets = true,									-- Outlines targets with arrow and box
	xray_targets = true,									-- See enemies thru walls
	freeze_accuracy = false,								-- When aimbot is active, freezes the accuracy until, aimbot is off.
	target_priority = 1,									-- Set to 1 to target closest, 2 for furthest and 3 for random
	always_headshot = true,									-- Or a random bodypart. If bow or flamethrower is used, it will be the hips unless aim_head_when_keybind_is_pressed is used
	replenish_ammo = false,							-- Replenish ammo when emety by cheating ammo, requires auto_reload true.
	auto_reload = true,										-- Set to true to reload weapon when emety.
	shoot_through_wall = false,								-- Set to true if you want to target enemies through walls
	shoot_through_shield = true,							-- Set to true to shoot through shields when using special ammo or not shoot shields.
	silent_shooting = false,
	inverted_look_direction = false,								-- For others you will aim opposite of what you are actually aiming at if true
	fov = 100,												-- 1-360. 135 recommended for whole screen as the fov is a cone from your camera and this is the cone width based on horizontal and vertical fov from moitor settings
	max_distance = 1500,										-- max distance, 0 for weapon range if possible or it's gona be 7000m

	spread_mul = 5,											-- adds bullet spread higher then 0
	fire_delay = 0.07,										-- Adds fire delay on top of weapons fire delay
	fire_delay_for_bows = false,								-- Set to false ot ignore fire_delay value
	custom_damage_by_unit = false,							-- Set to true to use defined damage by unit in table bellow or false, this has priority 1.
	custom_damage = false,									-- Custom damage in number format or false. Prioritizing custom_damage_by_unit first.
	damage_players = true,

	shoot_civilians = false,								-- Set to true to shoot civilians.
	shoot_turrets = true,									-- Set to true to shoot turrets, shoot_through_wall is requires.
	shoot_enemies = true,									-- Set to true to shoot enemies.
	shoot_players = false,									-- Set to true to shoot players.
	shoot_when_moving = true,								-- set to true to auto shoot when moving. 
	shoot_when_aiming = false,								-- set to true to auto shoot when aiming down sight.
	shoot_when_running = true,								-- set to true to auto shoot when running.
	shoot_when_crouching = true,							-- set to true to auto shoot when crouching.
	shoot_when_keybind_is_pressed = {},						-- set "left shift", "right shift", "left ctrl", "right ctrl", "left alt", "t", "g", "4" for mouse 4/number 4 and "mouse wheel up" e.g to auto shoot. {"left shift", "right shift"} e.g
	aim_head_when_keybind_is_pressed = "secondary_attack",					-- set "left shift", "right shift", "left ctrl", "right ctrl", "left alt", "t", "g", "4" for mouse 4/number 4 and "mouse wheel up" e.g to auto shoot.

	state_blacklist = {										-- Set to true to shoot in those states
		["standard"] 							= true,		-- masked
		["bleed_out"] 							= true,		-- on ground and able to shoot
		["bipod"] 								= true,		-- using lmg extension
		["driving"] 							= false,	-- driving
		["fatal"] 								= false,	-- on ground not able to shoot
		["jerry2"]								= false,	-- parachute
		["mask_off"]							= false,	-- mask off
		["tased"] 								= true,		-- when tased
		["incapacitated"] 						= false,	-- on ground not able to shoot
		["carry"] 								= true,		-- carrying bags
		["arrested"] 							= false,	-- cuffed
		["civilian"] 							= false,	-- mask off and can interact (start of golden grin casino heist)
		["clean"] 								= false		-- mask off and can't interact (start of panic room heist)
	},
	custom_damage_table = {
		["phalanx_minion"]						= 1000, 	-- Wintergoons
		["tank"]								= false
	},
	fire_delay_by_unit = {
		["tank_mini"]							= 0,		-- Minigundozer
		["tank_medic"]							= 0,		-- Medic Dozer
		["tank_hw"]								= 0,		-- Headless Titandozers
		["sentry_gun"]							= 0			-- enemy sentry
	},
	blocked_units = {										-- Set to true to block shooting those units
		["triad_boss"]							= true,		-- mountain master triad boss
		["triad_boss_no_armor"]					= true,		-- mountain master triad boss with no armor
		["phalanx_vip"]							= true		-- captain winter
	}
}) and _G[mod_name]

if not loaded then
	math.randomseed(os.time())
	local unit_colors = {}
	local player_sentries = {["@IDc71d763cd8d33588@"] = true, ["@IDb1f544e379409e6c@"] = true, ["@ID2cf4f276ce7ba6f5@"] = true, ["@ID07bd083cc5f2d3ba@"] = true}
	local special_weapons = {"flamethrower","bow"}
	local body_map = {
		"Hips","Spine","Spine1","Spine2","Neck","Head",
		"LeftShoulder","LeftArm","LeftForeArm","RightShoulder","RightArm","RightForeArm",
		"LeftUpLeg","LeftLeg","LeftFoot","RightUpLeg","RightLeg","RightFoot"
	}
	local controlls = {
		primary_attack = true, throw_grenade = true, reload = true,
		switch_weapon = true, switch_weapon = true, jump = true,
		interact = true, use_item = true, melee = true,
		duck = c.shoot_when_crouching, run = c.shoot_when_running, secondary_attack = c.shoot_when_aiming
	}

	function c:get_fire_delay(weap_base)
		local fireRateData = weap_base:recoil_wait() or (weap_base:fire_mode() == "single" and 0.6) or self.fire_delay
		local unitFireRate = self.fire_delay_by_unit[self.unit_base._tweak_table] or (self.unit_base.sentry_gun and self.fire_delay_by_unit["sentry_gun"])
		local minRate = (unitFireRate or self.fire_delay) + fireRateData
		local maxRate = (unitFireRate or self.fire_delay) + fireRateData / 3
		local randomDelay = math.random() * (maxRate - minRate) + minRate
	
		if not self.fire_delay_for_bows then
			minRate = 0
			maxRate = 0
		end

		return randomDelay, minRate, maxRate
	end

	function c:key_pressed(key)
		if (Input:keyboard():down(Idstring(key)) or Input:mouse():down(Idstring(key)) or self.controller and (self.controller:get_input_pressed(key) or self.controller:get_input_bool(key))) then
			return true
		end
	end

	function c:can_not_shoot()
		self.controller = self.player_unit and self.player_unit:base() and self.player_unit:base():controller()
		local isChatOpen = managers.hud and managers.hud._chat_focus == true
		local activeMenu = managers.menu._open_menus[#managers.menu._open_menus]
		local isPauseMenuOpen = activeMenu and activeMenu.name == "menu_pause"
		local isOverlayOpened = managers.network.account and managers.network.account._overlay_opened
		local isRestrictedState = not self.state_blacklist[managers.player._current_state]
		local isMoving = self.controller and mvector3.length(self.controller:get_input_axis("move")) > PlayerStandard.MOVEMENT_DEADZONE and not self.shoot_when_moving
	
		local isKeybindPressed = false 
		for _, v in pairs(self.shoot_when_keybind_is_pressed) do -- Check if any keybinds for shooting are pressed
			if self:key_pressed(v) then
				isKeybindPressed = true
				break
			end
		end
	
		local isControlPressed = false
		for k, v in pairs(controlls) do -- Check if any control keys are pressed that restrict shooting
			if v and (self.controller:get_input_pressed(k) or self.controller:get_input_bool(k)) then
				isControlPressed = true
				break
			end
		end
	
		return isRestrictedState or isChatOpen or isPauseMenuOpen or isOverlayOpened or isMoving or isKeybindPressed or isControlPressed
	end

	function c:aim_at_head(unit, player)
		if #self.aim_head_when_keybind_is_pressed > 0 and self:key_pressed(self.aim_head_when_keybind_is_pressed) then
			local player_camera, angle = player:camera(), Rotation:look_at(unit.dir, math.UP)
			-- Lock player angle on target
	        player_camera:set_rotation(angle)
			-- Lock weapon angle on target
			player_camera:camera_unit():base():set_rotation(angle)

			return true
		end
	end

	function c:hit_damage(base, dmg)
		return self.custom_damage_by_unit and self.custom_damage_table[base._tweak_table] and self.custom_damage_table[base._tweak_table] / 100 or self.custom_damage and self.custom_damage / 100 or dmg
	end

	function c:is_sentry_gun_active(unit)
		local movement = unit:movement()
		local turret_states = {active = true, rearming = true, activating = true}
		return type(movement) == "table" and turret_states[movement._state] ~= nil
	end

	function c:is_hostage(unit)
		if not alive(unit) then
			return 
		end

		for peer_id, peer in pairs(self.shoot_players and managers.network:session():peers() or {}) do
			local peer_unit = peer:unit()
			if alive(peer_unit) and peer_unit:key() == unit:key() then
				local peer_state = peer_unit:movement()._state
				return peer_state and not self.state_blacklist[peer_state]
			end
		end

		local brain = alive(unit) and unit.brain and unit:brain()
		local char_dmg = brain and unit:character_damage()
		local anim = unit.anim_data and unit:anim_data() or {} -- for hostage trade
		if self.blocked_units[unit:base()._tweak_table] or player_sentries[unit:name():t()] or char_dmg and (char_dmg._dead or char_dmg._invulnerable or char_dmg._immortal or char_dmg._god_mode) or brain and (brain.is_hostage and brain:is_hostage() or brain.is_hostile and not brain:is_hostile()) or anim and (anim.hands_tied or anim.tied) then
			return true
		end
	end

	function c:get_mask()
		local masks = {}
		masks[#masks + 1] = self.shoot_enemies and "enemies" or nil
		masks[#masks + 1] = self.shoot_civilians and "civilians" or nil
		masks[#masks + 1] = self.shoot_turrets and "sentry_gun" or nil
		masks[#masks + 1] = self.shoot_players and "criminals" or nil
		return managers.slot:get_mask(unpack(masks))
	end

	function c:calculateFov()
		local aspectRatio = RenderSettings.aspect_ratio or 1.77777777
		local fovRadians = math.rad(self.fov)
		local horizontalFov = 2 * math.atan(math.tan(fovRadians / 2) * aspectRatio)
		local verticalFov = 2 * math.atan(math.tan(fovRadians / 2) / aspectRatio)
		horizontalFov = math.min(horizontalFov, math.rad(360))
		verticalFov = math.min(verticalFov, math.rad(360))
	
		return math.max(horizontalFov, verticalFov) / 2
	end

	function c:get_target(player_unit, weap_base, tweak, special_wep)
		local count = {}
		local camera = player_unit:camera()
		local camera_position = camera:position()

		if self.shoot_through_wall then
			weap_base._bullet_slotmask = World:make_slot_mask(7, 11, 12, 14, 16, 17, 18, 21, 22, 25, 26, 33, 34, 35, 37) + (self.shoot_through_shield and 8 or 7)
			weap_base._can_shoot_through_shield = true
		elseif weap_base._bullet_class.id == "explosive" or weap_base._bullet_class.id == "flame" or weap_base._bullet_class.id == "instant" and table.contains(tweak.categories, "grenade_launcher") then
			weap_base._can_shoot_through_shield = true
		else
			weap_base._bullet_slotmask = weap_base._bullet_slotmask + World:make_slot_mask(37) -- shoots thru some glass
		end

		for _, unit in pairs(World:find_units("camera_cone", camera:camera_object(), Vector3(0, 0), self:calculateFov(), (self.max_distance > 0 and self.max_distance or special_wep and tweak.flame_max_range or tweak.damage_near or 7000), self:get_mask())) do
			local body = unit:get_object(Idstring(self.always_headshot and "Head" or special_wep and "Hips" or body_map[math.random(1, #body_map)])) or unit:get_object(Idstring("a_detect"))
			local aim_pos = body and body:position() or Vector3()
			local behind_wall = not self.shoot_through_wall and unit:raycast("ray", aim_pos, camera_position, "slot_mask", weap_base._bullet_slotmask, "thickness", 1, "thickness_mask", managers.slot:get_mask("world_geometry", "vehicles"))
			local behind_shield = unit:raycast("ray", aim_pos, camera_position, "slot_mask", managers.slot:get_mask("enemy_shield_check"))
			local is_shield_and_wall = behind_shield and unit:raycast("ray", aim_pos, camera_position, "slot_mask", managers.slot:get_mask("world_geometry", "vehicles"))
			local is_wall = behind_wall and not behind_shield and (not unit:in_slot(25, 26) or self:is_sentry_gun_active(unit))
			local is_shield = behind_shield and (not self.shoot_through_wall and not weap_base._can_shoot_through_shield or not self.shoot_through_shield or is_wall)
			local unit_id = unit:id()
			unit_colors[unit_id] = unit_colors[unit_id] or {r = math.random(), g = math.random(), b = math.random()}
			local colors = unit_colors[unit_id]

			count[#count + 1] = {dir = (aim_pos - camera_position):normalized(), target = unit, colors = colors, aim_pos = aim_pos, camera_position = camera_position}

			if self:is_hostage(unit) or is_shield or is_wall or is_shield_and_wall then
				count[#count] = nil
			elseif self.draw_targets then				
				Application:draw(unit, colors.r, colors.g, colors.b)

				if self.xray_targets and unit.contour and unit:contour() then
					if not unit:contour():has_id("mark_enemy") then
						unit:contour():add("mark_enemy", false, 20)
					end

					for _, material in ipairs(unit:contour()._materials or unit:get_objects_by_type(Idstring("material")) or {}) do
						material:set_variable(Idstring("contour_color"), Color(colors.r, colors.g, colors.b))
					end
				end
			end
		end

		return self.target_priority == 1 and count[1] or self.target_priority == 2 and count[#count] or self.target_priority == 3 and next(count) and count[math.random(1, #count)]
	end

	function c:press_fire(state, t)
		local input = state:_get_input(0, 0, false)
		input.btn_primary_attack_press = true
		input.btn_primary_attack_state = true
		state:_check_action_primary_attack(t, input)
	
		input = state:_get_input(0, 0, false)
		input.btn_primary_attack_release = true
		state:_check_action_primary_attack(t, input)
	end

	function c:can_shoot(weap_base, tweak, state, t, is_special_weapon)
		local low_ammo = weap_base:get_ammo_remaining_in_clip() <= 0
		local can_refresh = table.contains(tweak.categories, "revolver") or self.replenish_ammo
	
		if low_ammo and self.auto_reload then
			if can_refresh then
				weap_base:replenish()
			end

			if self.silent_shooting or is_special_weapon then
				self:press_fire(state, t)
			end
		end
	
		return low_ammo and self.auto_reload or not low_ammo
	end

	local last_fire_time = 0
	c.orig_enemy_update = EnemyManager.update
	function EnemyManager:update(t, dt)
		c.orig_enemy_update(self, t, dt)

		if not c.active then
			return
		end

		local state = managers.player:get_current_state()
		local equipped_unit = state and state._equipped_unit
		local weap_base = equipped_unit and equipped_unit:base()

		if not weap_base or weap_base:get_ammo_total() <= 0 then
			return
		end

		local tweak = weap_base:weapon_tweak_data()
		local special_wep = table.contains_any(tweak.categories, special_weapons)
		c.player_unit = managers.player:player_unit()
		c.unit = c:get_target(c.player_unit, weap_base, tweak, special_wep) or {}

		if not c.unit.dir then
			return
		end

		if c.draw_targets then
			Application:draw_cylinder(c.unit.camera_position, c.unit.aim_pos, c:calculateFov()/3, 201/255, 19/255, 6/255)
		end

		if c:aim_at_head(c.unit, c.player_unit) or c:can_not_shoot() then
			return
		end

		if special_wep and c.always_headshot then
			c.always_headshot = false
		end

		c.unit_base = c.unit.target and c.unit.target.base and c.unit.target:base() or {}
		local time_since_last_fire = t - last_fire_time
		local rng_delay, min_delay, max_delay = c:get_fire_delay(weap_base)

		if time_since_last_fire < (c.fire_delay_interval or max_delay) then
			return
		end

		local is_special_weapon = table.contains_any(tweak.categories, special_weapons)

		if c:can_shoot(weap_base, tweak, state, t, is_special_weapon) then
			local is_silent_shooting = is_special_weapon or c.silent_shooting
			local charging_weapon = weap_base:fire_on_release() and weap_base:charging()
			local cam_pos = c.player_unit:camera():position()
			local damage = c:hit_damage(c.unit_base, weap_base._current_stats.damage or 0)

			if c.shoot_players and c.damage_players and c.unit.target:in_slot(3) then
				local peer = managers.network:session():peer_by_unit(c.unit.target)

				if peer then
					local team_index = tweak_data.levels:get_team_index("converted_enemy")
					managers.network:session():send_to_peers("sync_unit_event_id_16", c.player_unit, "movement", team_index)
					managers.network:session():send_to_peers("sync_friendly_fire_damage", peer:id(), c.player_unit, managers.mutators:modify_value("HuskPlayerDamage:FriendlyFireDamage", damage), "bullet")
				end
			end

			if is_silent_shooting then
				if charging_weapon then
					local charge_max_t = math.max(weap_base:charge_max_t(), weap_base:reload_speed_multiplier())
					c.fire_delay_interval = charge_max_t
					weap_base:trigger_released(cam_pos, c.unit.dir, damage, nil, 0, 0, 0)
				else
					c.fire_delay_interval = rng_delay
					weap_base:trigger_held(cam_pos, c.unit.dir, damage, nil, 0, 0, 0)
				end

				managers.hud:set_ammo_amount(weap_base:selection_index(), weap_base:ammo_info())
			else
				c:press_fire(state, t)
				c.fire_delay_interval = rng_delay
			end

			last_fire_time = t
		end
	end

	c.orig_fire = NewRaycastWeaponBase.fire
	function NewRaycastWeaponBase:fire(from_pos, direction, dmg_mul, shoot_player, spread_mul, autohit_mul, suppr_mul, target_unit)
		if c.active and not c.silent_shooting and c.unit and c.unit.dir and not c:can_not_shoot() and self._setup.user_unit and (self._setup.user_unit == c.player_unit) then
			return c.orig_fire(self, from_pos, c.unit.dir, c:hit_damage(c.unit_base, dmg_mul), shoot_player, c.spread_mul, autohit_mul, suppr_mul, target_unit)
		end
		return c.orig_fire(self, from_pos, direction, dmg_mul, shoot_player, spread_mul, autohit_mul, suppr_mul, target_unit) 
	end

	c.orig_hit_accuracy = StatisticsManager.hit_accuracy
	function StatisticsManager:hit_accuracy(...)
		local acc = c.orig_hit_accuracy(self, ...)
		c.accuracy = c.accuracy or acc
		if not c.active then c.accuracy = acc end
		return c.freeze_accuracy and c.active and c.accuracy or acc
	end

	c.orig_session_hit_accuracy = StatisticsManager.session_hit_accuracy
	function StatisticsManager:session_hit_accuracy(...)
		local acc = c.orig_session_hit_accuracy(self, ...)
		c.session_accuracy = c.session_accuracy or acc
		if not c.active then c.session_accuracy = acc end
		return c.freeze_accuracy and c.active and c.session_accuracy or acc
	end

	local mvec1 = Vector3()
	c.orig_set_rotation = PlayerCamera.set_rotation
	function PlayerCamera:set_rotation(rot)
		if _G.IS_VR or not c.active or not c.inverted_look_direction then
			return c.orig_set_rotation(self, rot)
		end
		
		mrotation.y(rot, mvec1)
		mvector3.multiply(mvec1, 100000)
		mvector3.add(mvec1, self._m_cam_pos)
		self._camera_controller:set_target(mvec1)
		mrotation.z(rot, mvec1)
		self._camera_controller:set_default_up(mvec1)

		mrotation.set_yaw_pitch_roll(self._m_cam_rot, rot:yaw(), rot:pitch(), -rot:roll())
		mrotation.y(self._m_cam_rot, self._m_cam_fwd)
		mrotation.x(self._m_cam_rot, self._m_cam_right)

		local sync_yaw = (360 - rot:yaw()) % 360  -- Reverse and ensure within range [0, 360)
		sync_yaw = math.floor(255 * sync_yaw / 360)  -- Scale to [0, 255]
		local sync_pitch = (85 - rot:pitch()) % 360  -- Reverse and ensure within range [0, 360)
		sync_pitch = math.floor(127 * sync_pitch / 170)  -- Scale to [0, 127]

		if sync_yaw ~= self._sync_yaw or sync_pitch ~= self._sync_pitch then
			self._unit:network():send("set_look_dir", sync_yaw, sync_pitch)

			self._sync_yaw = sync_yaw
			self._sync_pitch = sync_pitch
		end
	end

	function c:set_projectile_speed()
		self.orig_projectile_speed = {}

		for _, projectile in pairs(tweak_data.blackmarket:get_projectiles_index() or {}) do
			if type(projectile) == "string" and type(tweak_data.projectiles[projectile]) == "table" and projectile:lower():match("arrow") then
				self.orig_projectile_speed[projectile] = self.orig_projectile_speed[projectile] or {}
				self.orig_projectile_speed[projectile]["launch_speed"] = tweak_data.projectiles[projectile].launch_speed
				tweak_data.projectiles[projectile].no_cheat_count = true
				tweak_data.projectiles[projectile].launch_speed = (tweak_data.projectiles[projectile].launch_speed or 2000) * 1.6
			end
		end
	end
	c:set_projectile_speed()

	function c:reload(unload, load)
		if unload then
            self.temp_orig_enemy_update = EnemyManager.update
            EnemyManager.update = self.orig_enemy_update
			
			self.temp_orig_fire = NewRaycastWeaponBase.fire
            NewRaycastWeaponBase.fire = self.orig_fire
			
			self.temp_orig_hit_accuracy = StatisticsManager.hit_accuracy
            StatisticsManager.hit_accuracy = self.orig_hit_accuracy
			
			self.temp_orig_session_hit_accuracy = StatisticsManager.session_hit_accuracy
            StatisticsManager.session_hit_accuracy = self.orig_session_hit_accuracy
			
			self.temp_orig_set_rotation = PlayerCamera.set_rotation
            PlayerCamera.set_rotation = self.orig_set_rotation

			for projectile in pairs(c.orig_projectile_speed) do
				tweak_data.projectiles[projectile]["launch_speed"] = self.orig_projectile_speed[projectile].launch_speed
			end
        end
        
        if load then
            EnemyManager.update = self.temp_orig_enemy_update
			NewRaycastWeaponBase.fire = self.temp_orig_fire
			StatisticsManager.hit_accuracy = self.temp_orig_hit_accuracy
			StatisticsManager.session_hit_accuracy = self.temp_orig_session_hit_accuracy
			PlayerCamera.set_rotation = self.temp_orig_set_rotation
			self:set_projectile_speed()
        end
	end

	function c:print_desc(toggle, title, text, desc)
		self.desc = title .. ": " .. desc

		if #text > 0 then
			managers.chat:_receive_message(1, title, text, (toggle and Color.green or Color.red))
		end

		self:open_aimbot_config()
	end

	function c:open_aimbot_config()
		local options = {
			{name = "Silent Shooting", value = self.silent_shooting, description = "Gunfire will not make noise when activated."},
			{name = "Draw Targets", value = self.draw_targets, description = "Toggle drawing outlines around targets."},
			{name = "Xray Targets", value = self.xray_targets, description = "Toggle x-ray vision to see targets through walls."},
			{name = "Always Headshot", value = self.always_headshot, description = "Always aim for the head."},
			{name = "Replenish Ammo", value = self.replenish_ammo, description = "Automatically replenish ammo when empty."},
			{name = "Auto Reload", value = self.auto_reload, description = "Automatically reload when out of ammo."},
			{name = "Freeze Accuracy", value = self.freeze_accuracy, description = "Freeze your weapons accuracy at a percentage."},
			{name = "Inverted Look Direction", value = self.inverted_look_direction, description = "Pitch and yaw is inverted so other players will not see where you look."},
			{name = "Shoot Through Wall", value = self.shoot_through_wall, description = "When not, your ammo is determining it."},
			{name = "Shoot Through Shield", value = self.shoot_through_shield, description = "When not, your ammo is determining it."},
			{name = "Shoot Civilians", value = self.shoot_civilians, description = "Toggle shooting civilians."},
			{name = "Shoot Turrets", value = self.shoot_turrets, description = "Toggle shooting enemy turrets."},
			{name = "Shoot Enemies", value = self.shoot_enemies, description = "Toggle shooting enemies."},
			{name = "Shoot Players", value = self.shoot_players, description = "Toggle shooting other players."},
			{name = "Shoot When Moving", value = self.shoot_when_moving, description = "Toggle shooting while moving."},
			{name = "Shoot When Aiming", value = self.shoot_when_aiming, description = "Toggle shooting while aiming down sight."},
			{name = "Shoot When Running", value = self.shoot_when_running, description = "Toggle shooting while running."},
			{name = "Shoot When Crouching", value = self.shoot_when_crouching, description = "Toggle shooting while crouching."},
			{name = "Fire Delay For Bows", value = self.fire_delay_for_bows, description = "When activated, will make bows use the same fire delay as regular weapons."},
			{name = "Custom Damage By Unit", value = self.custom_damage_by_unit, description = "Uses custom damage on spesific units, changed in lua file. This damage has priority 1."},
			{name = "Damage Players", value = self.damage_players, description = "Tries to damage player when shoot players is true."}
		}
	
		local options_menu = {
			title = "Aimbot Config",
			text = self.desc or "Select Option",
			button_list = {}
		}
	
		table.insert(options_menu.button_list, {
			text = "Toggle Aimbot - " .. tostring((self.active or false)),
			callback_func = function()
				self.active = not self.active
				self:print_desc(self.active, "Toggle Aimbot", (self.active and "Activated" or "Deactivated"), "Activate or deactivate the aimbot.")
				self:reload(true, true)
			end
		})
		table.insert(options_menu.button_list, {})

		for _, option in ipairs(options) do
			local text = option.name .. " - " .. tostring(option.value)
			table.insert(options_menu.button_list, {
				text = text,
				callback_func = function()
					option.value = not option.value
					self[option.name:lower():gsub(" ", "_")] = option.value
					self:print_desc(option.value, option.name, "", option.description)
				end
			})
		end

		table.insert(options_menu.button_list, {})
		table.insert(options_menu.button_list, {text = managers.localization:text("dialog_cancel"), cancel_button = true})
	
		managers.system_menu:show_buttons(options_menu)
	end
end
c:open_aimbot_config()