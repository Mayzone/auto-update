--auto aim shoot
rawset(_G, "aimbot", nil)
if not rawget(_G, "aimbot") then
	rawset(_G, "aimbot", {})

	aimbot.auto_aim_distance = 1500
	aimbot.instant_hit = true
	aimbot.aim_rotation = nil
	aimbot.turret_data = "@ID1326760"
	aimbot.pl_cam_pos = managers.player:player_unit():camera():position()
	
	function aimbot:get_safe_ray()
		aimbot.mvecTo = Vector3()
		mvector3.set(aimbot.mvecTo, managers.player:player_unit():camera():rotation():y())
		mvector3.multiply(aimbot.mvecTo, 999999)
		mvector3.add(aimbot.mvecTo, aimbot.pl_cam_pos)
		aimbot.enemy_table ={
			"sentry_gun",
			"enemies",
		}
		for _, enemies in pairs(aimbot.enemy_table) do
			aimbot.ray = World:raycast("ray", aimbot.pl_cam_pos, aimbot.mvecTo, "slot_mask", managers.slot:get_mask(enemies))
			aimbot.ray_unit = self.ray and self.ray.unit
			if self.ray_unit and alive(self.ray_unit) then
				aimbot.in_slot = self.ray_unit:in_slot(managers.slot:get_mask(enemies))
				if self.in_slot then
					return self.ray
				end
			end
		end
		return nil
	end

	function aimbot:hit_target()
		aimbot.equipped_unit_base = managers.player:player_unit():inventory():equipped_unit():base()
		aimbot.ammo = self.equipped_unit_base:ammo_info()
		self.equipped_unit_base:replenish()
		
		if self.ammo == 0 then
			return
		end
		
		if self.instant_hit then
			if not global_toggle_hit_backup then global_toggle_hit_backup = RaycastWeaponBase._get_current_damage end
			function RaycastWeaponBase:_get_current_damage(dmg_mul)
				return math.huge
			end
		end
		
		self.equipped_unit_base:trigger_held(aimbot.pl_cam_pos, managers.player:player_unit():camera():forward(), self.equipped_unit_base:damage_multiplier(), nil, 0, 0, 0)
		managers.rumble:play("weapon_fire")
		managers.player:player_unit():camera():play_shaker("fire_weapon_rot", 1)
		managers.player:player_unit():camera():play_shaker("fire_weapon_kick", 1, 1, 0.15)
		self.equipped_unit_base:tweak_data_anim_play("fire", 20)
		managers.hud:set_ammo_amount(self.equipped_unit_base:selection_index(), self.equipped_unit_base:ammo_info())
	end

	function aimbot:auto_shoot()
		for _,data in pairs(managers.enemy:all_enemies()) do
			aimbot.unit_as = data.unit
			if self.unit_as and not self.unit_as:brain():surrendered() and self:get_safe_ray() then
				self:hit_target()
				break
			end
		end
		
		for _, x in pairs(World:find_units_quick('all')) do
			aimbot.id = string.sub(x:name():t(), 1, 10)
			if self.id == self.turret_data then
				if x and self:get_safe_ray() then
					self:hit_target()
					break
				end
			end
		end
	end

	function aimbot:auto_aim()
		for _,data in pairs(managers.enemy:all_enemies()) do
			aimbot.unit_aa = data.unit
			if self.unit_aa and not (self.unit_aa:base()._tweak_table == "phalanx_vip") and not self.unit_aa:brain():surrendered() then
				aimbot.team_id = self.unit_aa:movement():team().id
				if self.team_id == "mobster1" or self.team_id == "law1" then
					aimbot.dist = mvector3.distance(managers.player:player_unit():position(), self.unit_aa:position())
					if self.dist < (self.auto_aim_distance) and self.unit_aa then
						aimbot.body = self.unit_aa:character_damage() and self.unit_aa:body(self.unit_aa:character_damage()._head_body_name)
						aimbot.head_pos = self.body and self.body:position()
						aimbot.target = self.head_pos or self.unit_aa:position()
						mvector3.subtract(self.target, aimbot.pl_cam_pos)
						self.aim_rotation = Rotation:look_at(self.target, math.UP)
						managers.player:player_unit():camera():set_rotation(self.aim_rotation)
						break
					end
				end
			end
		end
		--[[ aim at sentry
		for _, x in pairs(World:find_units_quick('all')) do
			aimbot.id = string.sub(x:name():t(), 1, 10)
			if self.id == self.turret_data then
				aimbot.dist = mvector3.distance(managers.player:player_unit():position(), x:position())
				if self.dist < (self.auto_aim_distance) and x then
					aimbot.body = x:damage()
					aimbot.vec3 = Vector3(0,0,145)
					aimbot.head_pos = self.body and x:position() + self.vec3
					aimbot.target = self.head_pos or x:position() + self.vec3
					mvector3.subtract(self.target, aimbot.pl_cam_pos)
					self.aim_rotation = Rotation:look_at(self.target, math.UP)
					managers.player:player_unit():camera():set_rotation(self.aim_rotation)
					break
				end
			end
		end--]]
	end

	function aimbot:start_aimbot()
		if not alive(managers.player:player_unit()) then
			return
		end
		
		for _,selection in pairs(managers.player:player_unit():inventory()._available_selections) do
			selection.unit:base().old_mask = selection.unit:base()._bullet_slotmask
			selection.unit:base()._bullet_slotmask = World:make_slot_mask(7, 11, 12, 14, 16, 17, 18, 21, 22, 25, 26, 33, 34, 35)
		end
		
		BetterDelayedCalls:Add("aimbot_aim_loop_id_1", 0.01, function()
			if not Input:mouse():down(Idstring("0"):id()) and not Input:mouse():down(Idstring("1"):id()) and not Input:mouse():down(Idstring("2"):id()) and not Input:mouse():down(Idstring("3"):id()) then
				self:auto_shoot()
				self:auto_aim()
			end
		end, true)
	end

	if not global_toggle_aimbot_backup then global_toggle_aimbot_backup = FPCameraPlayerBase._update_rot end
	function FPCameraPlayerBase._update_rot(self, ... )
		global_toggle_aimbot_backup(self, ...)
		if aimbot.aim_rotation then
			self._parent_unit:camera():set_rotation(aimbot.aim_rotation)
			self:set_rotation(aimbot.aim_rotation)
			aimbot.aim_rotation = nil
		end
		return
	end

	function aimbot:_toggle()
		_global_aimbot = _global_aimbot or false
		if not _global_aimbot then
			managers.mission._fading_debug_output:script().log('Aimbot (Aim/Shoot) - ACTIVATED', Color.green)
			self:start_aimbot()
		else
			BetterDelayedCalls:Remove("aimbot_aim_loop_id_1")
			if global_toggle_aimbot_backup then FPCameraPlayerBase._update_rot = global_toggle_aimbot_backup end
			if not godmodeextra then
				if global_toggle_hit_backup then RaycastWeaponBase._get_current_damage = global_toggle_hit_backup end
			end
			managers.mission._fading_debug_output:script().log('Aimbot (Aim/Shoot) - DEACTIVATED', Color.red)
		end
		_global_aimbot = not _global_aimbot
	end
	aimbot:_toggle()
else
	aimbot:_toggle()
end