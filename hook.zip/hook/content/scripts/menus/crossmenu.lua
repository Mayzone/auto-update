function is_playing()
	if not BaseNetworkHandler then 
		return false 
	end
	return BaseNetworkHandler._gamestate_filter.any_ingame_playing[ game_state_machine:last_queued_state_name() ]
end
if not is_playing() then 
	return
end
function get_ray(penetrate, slotMask) -- Get col ray
	if not slotMask then
		slotMask = "bullet_impact_targets"
	end
	local player = managers.player:player_unit()
	if (alive(player)) then
		local camera = player:camera()
		local fromPos = camera:position()
		local mvecTo = Vector3()
		local forward = camera:rotation():y()
		mvector3.set(mvecTo, forward)
		mvector3.multiply(mvecTo, 99999)
		mvector3.add(mvecTo, fromPos)
		local colRay = World.raycast(World, "ray", fromPos, mvecTo, "slot_mask", managers.slot.get_mask(managers.slot, slotMask))
		if colRay and penetrate then
			local offset = Vector3()
			mvector3.set(offset, forward)
			mvector3.multiply(offset, 100)
			mvector3.add(colRay.hit_position, offset)
		end
		return colRay
	end
end

local _activate_element = function( unit, name )
    if unit:damage() and unit:damage():has_sequence( name ) then
        unit:damage():run_sequence_simple( name ) 
		managers.network:session():send_to_peers_synched('run_mission_door_device_sequence', unit, name)
    end
	managers.mission._fading_debug_output:script().log(string.format("%s - ACTIVATED - %s", name, unit), Color.green)
end

local allelem = function()
	local ray = get_ray()
	if not ray or not ray.unit then
		return
	end
	local elem = ray.unit.damage and ray.unit:damage() and ray.unit:damage()._unit_element
	if not elem then
		return
	end
	local elements = elem._sequence_elements
	for id in pairs( elements ) do
		for i = 1, 2 do
			_activate_element(ray.unit, id)
		end
	end
end

crosshair_menu = function()
	local dialog_data = {    
		title = "Crosshair Menu",
	    text = "Select Option",
		button_list = {}
	}
	local ray = get_ray()
	if not ray or not ray.unit then
		return
	end
	local elem = ray.unit.damage and ray.unit:damage() and ray.unit:damage()._unit_element
	if not elem then
		return
	end
	local elements = elem._sequence_elements
	for id in pairs( elements ) do
		table.insert(dialog_data.button_list, {
			text = id,
			callback_func = function() _activate_element(ray.unit, id) end, 
		})
		table.sort( dialog_data.button_list, function(x,y) if x.text and y.text then return x.text < y.text end end )			
    end
	
	table.insert(dialog_data.button_list, {})
	table.insert(dialog_data.button_list, {text = "------------------------- Use Scroll Wheel ------------------------",})
	table.insert(dialog_data.button_list, {})
	table.insert(dialog_data.button_list, {
		text = "Activate All Crosshair Single Element",        
		callback_func = function () allelem() end,        
	})
	local no_button = {text = managers.localization:text("dialog_cancel"), cancel_button = true}     
	table.insert(dialog_data.button_list, no_button)
	managers.system_menu:show_buttons(dialog_data)
end     
crosshair_menu()

