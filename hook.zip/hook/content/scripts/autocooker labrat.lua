local function _spawn_bag(name, rain, zipline_unit)
	local player = managers.player:player_unit()
	if not alive(player) then return end
	player:sound():play("Play_bag_generic_throw", nil, false)
	local forward = player:camera():forward()
	local throw_force = managers.player:upgrade_level("carry", "throw_distance_multiplier", 0)
	local carry_data = tweak_data.carry[name]
	local rotation = Rotation(player:camera():rotation():yaw(), 0, 0)
	local position = player:camera():position()
	if Network:is_server() then
		managers.player:server_drop_carry(name, carry_data.multiplier, carry_data.dye_initiated, carry_data.has_dye_pack, carry_data.dye_value_multiplier, position, rotation, forward, throw_force, zipline_unit, managers.network:session():local_peer())
		managers.mission._fading_debug_output:script().log('Droped', Color.green)
	else
		managers.network:session():send_to_host("server_drop_carry", name, carry_data.multiplier, carry_data.dye_initiated, carry_data.has_dye_pack, carry_data.dye_value_multiplier, position, rotation, forward, throw_force, zipline_unit)
		managers.mission._fading_debug_output:script().log(string.format("dropped c"), Color.green)
	end
end