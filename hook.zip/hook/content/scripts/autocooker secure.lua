function is_playing()
	if not BaseNetworkHandler then 
		return false 
	end
	return BaseNetworkHandler._gamestate_filter.any_ingame_playing[ game_state_machine:last_queued_state_name() ]
end

if not is_playing() then
	return
end

id_level = managers.job:current_level_id()
if not (id_level == 'cane' or id_level == 'mex_cooking' or id_level == 'alex_1' or id_level == 'rat' or id_level == 'crojob2' or id_level == 'mia_1') then
	return
end

if global_toggle_meth then
	global_toggle_secure_meth = global_toggle_secure_meth or false
	if not global_toggle_secure_meth then
		secure_bagged = secure_bagged + 1
		managers.mission._fading_debug_output:script().log(tostring'Secure Meth - ACTIVATED',  Color.green)
	else
		secure_bagged = secure_bagged - 1
		managers.mission._fading_debug_output:script().log(tostring'Secure Meth - DEACTIVATED',  Color.red)
	end
	global_toggle_secure_meth = not global_toggle_secure_meth
else
	managers.chat:_receive_message(1, "COOKER - SECURE", "Enable Autocooker First", tweak_data.system_chat_color)
end