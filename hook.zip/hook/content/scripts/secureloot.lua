function is_playing() -- Is playing check
	return BaseNetworkHandler._gamestate_filter.any_ingame_playing[ game_state_machine.last_queued_state_name(game_state_machine) ]
end
if is_playing() then
	local amount = 50
	local name = "meth"
	function secure(name)
		managers.loot:secure( name, managers.money:get_bag_value( name ), true )
	end
	for i=1,amount do
		secure(name)
	end
	managers.mission._fading_debug_output:script().log(string.format("Secure %s %s ACTIVATED", amount, name),  Color.green)
end