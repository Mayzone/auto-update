local orig_setup_job_heat = JobManager._setup_job_heat
function JobManager:_setup_job_heat(...)
	if CommandManager.config["trainer_job_heat"] then
		local heat = {}

		for _, v in pairs(tweak_data.narrative:get_jobs_index()) do
			heat[v] = 100
		end

		Global.job_manager.heat = heat
	else
		orig_setup_job_heat(self, ...)
	end
end