local mod_name = "Anti_telemetry"
local loaded = rawget(_G, mod_name)

if loaded then
    return
end

local c = loaded or rawset(_G, mod_name, {telemetry = {}}) and _G[mod_name]

for k, v in pairs(Telemetry or {}) do
    if type(v) == "function" and k ~= "init" then
        c.telemetry[k] = v
        Telemetry[k] = function(Telemetry, ...)
            if managers.user:get_setting("use_telemetry") then
                c.telemetry[k](Telemetry, ...)
            end
        end
    end
end