--update spoofname
local name
if CommandManager.config["first_load"] then
	name = CommandManager.config.real_name
	
	CommandManager.config.first_load = not CommandManager.config.first_load
	CommandManager.config.fake_name = name
	CommandManager:Save()
else
	name = CommandManager.config.fake_name
end

if not managers.network:session() then
	return
end

--managers.network:session():local_peer():set_name(name)
for _, peer in pairs(managers.network:session():peers()) do
	if peer:id() ~= managers.network:session():local_peer():id() then
		--peer:send("request_player_name_reply", name)
		--[[spoof level and rank
		local join_stinger_index = managers.infamy:selected_join_stinger_index()
		local character = managers.network:session():local_peer():character()
		local mask_set = "remove"
		peer:send("lobby_info", 1, 1, join_stinger_index, character, mask_set)--]]
	end
end

local SteamClass = getmetatable(Steam)
if SteamClass then
	local orig_username = SteamClass.username
	function SteamClass:username(userid, ...)
		if not userid or (userid == SteamClass.userid(Steam)) then
			return name
		end
		return orig_username(self, userid, ...)
	end
end