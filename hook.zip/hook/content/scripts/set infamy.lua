local function infamy(num)
	managers.experience:set_current_rank(num)
	managers.infamy:_set_points(num)
	managers.mission._fading_debug_output:script().log(string.format("%s", num), Color.green)
end

local current = managers.experience:current_rank() + 1
infamy(current)--]]

--[[local function lvl(num)
	managers.experience:_set_current_level(num)
	managers.experience:_set_next_level_data(num)
	managers.mission._fading_debug_output:script().log(string.format("%s", num), Color.green)
end

local current_lvl = managers.experience:current_level() - 99
lvl(current_lvl)--]]