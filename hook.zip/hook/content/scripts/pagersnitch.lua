if not rawget(_G, "pager_snitcher") then
	rawset(_G, "pager_snitcher", {})

	PlayerManager._boost_upgrade_value = {
		player = {
			melee_kill_snatch_pager_chance = 1
		}
	}

	local orig_ug = PlayerManager.upgrade_value
	function PlayerManager.upgrade_value(self, category, upgrade, default)
		local original_value = orig_ug(self, category, upgrade, default)
		local boost = PlayerManager._boost_upgrade_value
		if ((boost[category]) and (boost[category][upgrade])) then
			original_value = (original_value + boost[category][upgrade])
		end
		return original_value
	end
	
	function pager_snitcher:melee_on_proj(unit)
		unit:character_damage():damage_melee({
			damage = unit:character_damage()._HEALTH_INIT,
			attacker_unit = managers.player:player_unit(),
			attack_dir = Vector3(0,0,0),
			variant = "melee",
			name_id = 'cqc',
			col_ray = {position = unit:position(), body = unit:body("body")}
		})
		managers.network:session():send_to_peers_synched("remove_unit", unit)
	end
	
	function pager_snitcher:on_projectile(unit, attack_data)
		local pager_active = unit:unit_data().has_alarm_pager
		local damage = (attack_data.damage) * (CopDamage._marked_dmg_mul or 1)
		local alerted = unit:movement():cool() --choose pager when alert or not
		if (pager_active and (damage > 0) and (managers.groupai:state()._whisper_mode) --[[and alerted--]]) then
			unit:unit_data().has_alarm_pager = false --host only
			pager_snitcher:melee_on_proj(unit)
			return
		end
		pager_active = false
	end
	
	function pager_snitcher:_init()
		if not _GroupAIStateBase_pager then _GroupAIStateBase_pager = GroupAIStateBase.on_successful_alarm_pager_bluff end
		function GroupAIStateBase:on_successful_alarm_pager_bluff()
			_GroupAIStateBase_pager(self)
		end
		
		if not _CopDamage_damage_bullet then _CopDamage_damage_bullet = CopDamage.damage_bullet end
		function CopDamage:damage_bullet(attack_data)
			pager_snitcher:on_projectile(self._unit, attack_data)
			return _CopDamage_damage_bullet(self, attack_data)
		end
		
		if not _CopDamage_damage_fire then _CopDamage_damage_fire = CopDamage.damage_fire end
		function CopDamage:damage_fire(attack_data)
			pager_snitcher:on_projectile(self._unit, attack_data)
			return _CopDamage_damage_bullet(self, attack_data)
		end

		if not _CopDamage_damage_explosion then _CopDamage_damage_explosion = CopDamage.damage_explosion end
		function CopDamage:damage_explosion(attack_data)
			pager_snitcher:on_projectile(self._unit, attack_data)
			return _CopDamage_damage_explosion(self, attack_data)
		end
		
		if not damage_melee_original then damage_melee_original = CopDamage.damage_melee end
		function CopDamage.damage_melee(self, attack_data, ...)
			attack_data.damage = attack_data.damage * 100
			return damage_melee_original(self, attack_data, ...)
		end
	end
	
	function pager_snitcher:_toggle()
		self.toggle = not self.toggle
		if not self.toggle then
			if not global_killall_on then --for not spam msg when killloop is used
				managers.mission._fading_debug_output:script().log("No Pager - ACTIVATED", Color.green)
				managers.chat:feed_system_message(ChatManager.GAME, "Steal pager on melee and projectile client/host")
			end
			self:_init()
			PlayerManager:upgrade_value()
		else
			if not global_killall_on then
				managers.mission._fading_debug_output:script().log("No Pager - DEACTIVATED", Color.red)
			end
			if damage_melee_original then CopDamage.damage_melee = damage_melee_original end
			if _GroupAIStateBase_pager then GroupAIStateBase.on_successful_alarm_pager_bluff = _GroupAIStateBase_pager end
			if _CopDamage_damage_bullet then CopDamage.damage_bullet = _CopDamage_damage_bullet end
			if _CopDamage_damage_fire then CopDamage.damage_fire = _CopDamage_damage_fire end
			if _CopDamage_damage_explosion then CopDamage.damage_explosion = _CopDamage_damage_explosion end
		end
	end
	pager_snitcher:_toggle()
else
	pager_snitcher:_toggle()
end