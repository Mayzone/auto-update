if not rawget(_G, "pager_snitcher") then
	rawset(_G, "pager_snitcher", {})
	
	pager_snitcher.toggle = false
	PlayerManager._boost_upgrade_value = {}
	PlayerManager._boost_upgrade_value.player = {
		melee_kill_snatch_pager_chance = 1000
	}

	if not orig_ug then orig_ug = PlayerManager.upgrade_value end
	function PlayerManager.upgrade_value(self, category, upgrade, default)
		local original_value = orig_ug(self, category, upgrade, default)
		if not pager_snitcher.toggle then
			if PlayerManager._boost_upgrade_value[category] and PlayerManager._boost_upgrade_value[category][upgrade] then
				original_value = original_value + PlayerManager._boost_upgrade_value[category][upgrade]
			end
			return original_value
		else
			return original_value
		end
	end

	function pager_snitcher:_on_projectile()
		if not _GroupAIStateBase_pager then _GroupAIStateBase_pager = GroupAIStateBase.on_successful_alarm_pager_bluff end
		function GroupAIStateBase:on_successful_alarm_pager_bluff()
			_GroupAIStateBase_pager(self)
		end
		
		if not _CopDamage_damage_bullet then _CopDamage_damage_bullet = CopDamage.damage_bullet end
		function CopDamage:damage_bullet(attack_data)
			if not Network:is_server() then
				dofile("mods/hook/content/scripts/pageranswer.lua")
			end
			--pager
			local result = nil
			local damage = attack_data.damage
			local pager_active = self._unit:unit_data().has_alarm_pager
			damage = damage * (self._marked_dmg_mul or 1)
			--choose pager when alert or no
			--self._unit:movement():cool()
			if pager_active and damage > 0 then
				self._unit:unit_data().has_alarm_pager = false
			else
				pager_active = false
			end
			
			result = _CopDamage_damage_bullet(self, attack_data)
			return result
		end
		
		if not _CopDamage_damage_fire then _CopDamage_damage_fire = CopDamage.damage_fire end
		function CopDamage:damage_fire(attack_data)
			if not Network:is_server() then
				dofile("mods/hook/content/scripts/pageranswer.lua")
			end
			--pager
			local result = nil
			local damage = attack_data.damage
			local pager_active = self._unit:unit_data().has_alarm_pager
			damage = damage * (self._marked_dmg_mul or 1)
			if pager_active and damage > 0 then
				self._unit:unit_data().has_alarm_pager = false
			else
				pager_active = false
			end
			
			result = _CopDamage_damage_fire(self, attack_data)
			return result
		end

		if not _CopDamage_damage_explosion then _CopDamage_damage_explosion = CopDamage.damage_explosion end
		function CopDamage:damage_explosion(attack_data)
			if not Network:is_server() then
				dofile("mods/hook/content/scripts/pageranswer.lua")
			end
			local result = nil
			local damage = attack_data.damage
			local pager_active = self._unit:unit_data().has_alarm_pager
			damage = damage * (self._marked_dmg_mul or 1)
			if pager_active and damage > 0 then
				self._unit:unit_data().has_alarm_pager = false
			else
				pager_active = false
			end
			
			result = _CopDamage_damage_explosion(self, attack_data)
			return result
		end
	end
	
	function pager_snitcher:_toggle()
		self.toggle = not self.toggle
		if not self.toggle then
			managers.mission._fading_debug_output:script().log("No Pager - ACTIVATED", Color.green)
			managers.chat:feed_system_message(ChatManager.GAME, "Steal pager on melee (client)")
			managers.chat:feed_system_message(ChatManager.GAME, "Steal pager on projectile (host) and melee (client)")
			self:_on_projectile()
			PlayerManager:upgrade_value()
		else
			managers.mission._fading_debug_output:script().log("No Pager - DEACTIVATED", Color.red)
			if orig_ug then PlayerManager.upgrade_value = orig_ug end
			if _GroupAIStateBase_pager then GroupAIStateBase.on_successful_alarm_pager_bluff = _GroupAIStateBase_pager end
			if _CopDamage_damage_bullet then CopDamage.damage_bullet = _CopDamage_damage_bullet end
			if _CopDamage_damage_fire then CopDamage.damage_fire = _CopDamage_damage_fire end
			if _CopDamage_damage_explosion then CopDamage.damage_explosion = _CopDamage_damage_explosion end
		end
	end
	pager_snitcher:_toggle()
else
	pager_snitcher:_toggle()
end