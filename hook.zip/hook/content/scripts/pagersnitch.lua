local mod_name = "pager_snitcher"
local loaded = rawget(_G, mod_name)
local c = loaded or rawset(_G, mod_name, {alerted_pager = false, toggle_for_team = true, headshot_force_snitch = true, snitch_chance = 1}) and _G[mod_name]

c.active = not c.active

if not global_killall_on then 	--for not spam msg when kill loop is used
	managers.chat:_receive_message(1, "Snatcher", string.format("Player (client/host): %s", (c.active and "true" or "false")), (c.active and Color.green or Color.red))
	managers.chat:_receive_message(1, "Snatcher", string.format("Team (host): %s", (c.active and "true" or "false")), (c.active and Color.green or Color.red))
end

if not loaded then
	function c:check(unit, attack_data, brain)
		local char_dmg = unit:character_damage()
		--managers.mission._fading_debug_output:script().log(string.format("%s", (attack_data.attacker_unit and managers.network:session():peer_by_unit_key(attack_data.attacker_unit:key()):name() or "nil")), Color.green)
		if self.active and unit:unit_data().has_alarm_pager then
			if not self.toggle_for_team and attack_data.attacker_unit ~= managers.player:player_unit() then
				return
			end
			
			local stelf
			for key, obj in pairs(brain and brain._logic_data and brain._logic_data.detected_attention_objects or {}) do
				if math.max(0, obj.notice_progress) < 100 then
					stelf = true
				end
			end

			local is_cool = stelf or global_killall_on or not self.alerted_pager or unit:movement() and unit:movement():cool()
			local is_head = self.headshot_force_snitch and attack_data.col_ray.body and attack_data.col_ray.body == unit:body("head")

			if is_cool or is_head then
				self.snitch_chance = 1
				unit:unit_data().has_alarm_pager = false
				
				if attack_data.variant ~= "damage_melee" or attack_data.attacker_unit ~= managers.player:player_unit() then
					attack_data.attacker_unit = managers.player:player_unit()
					attack_data.variant = "melee"
					attack_data.name_id = 'cqc'
					char_dmg:damage_melee(attack_data)
				end
			elseif attack_data.variant == "melee" then
				self.snitch_chance = 0
			end
		end
	end
	
	local orig_pm_ug = PlayerManager.upgrade_value
	function PlayerManager:upgrade_value(category, upgrade, ...)
		local original_value = orig_pm_ug(self, category, upgrade, ...)
		if c.active and category == "player" and upgrade == "melee_kill_snatch_pager_chance" then
			original_value = (original_value + c.snitch_chance)
		end
		return original_value
	end
	
	-- host/client
	local dmg_types = {
		"damage_melee", "damage_bullet", "damage_fire",
		"damage_explosion", "damage_dot", "damage_simple"
	}
	c.orig_func_table = c.orig_func_table or {}
	for _, func_name in pairs(dmg_types) do
		c.orig_func_table[func_name] = CopDamage[func_name]
		CopDamage[func_name] = function(self, attack_data, ...)
			pcall(c.check, c, self._unit, attack_data)
			return c.orig_func_table[func_name](self, attack_data, ...)
		end
	end
	
	--host
	local orig_func_cop_brain = CopBrain.clbk_death
	function CopBrain:clbk_death(my_unit, damage_info, ...)
		if Network:is_server() then
			pcall(c.check, c, self._unit, damage_info, true, self)
		end
		orig_func_cop_brain(self, my_unit, damage_info, ...)
	end
end