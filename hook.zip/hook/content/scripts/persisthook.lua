function is_playing()
	if not BaseNetworkHandler then 
		return false 
	end
	return BaseNetworkHandler._gamestate_filter.any_ingame_playing[ game_state_machine:last_queued_state_name() ]
end

--dlc unlock
function WINDLCManager:_verify_dlcs()
	for dlc_name, dlc_data in pairs( Global.dlc_manager.all_dlc_data ) do
		dlc_name = { afile_id = "218620", no_install = true }
		dlc_data.verified = true
	end
end

-- Unlock Armor Skins
function BlackMarketManager:_remove_unowned_armor_skin()
	local armor_skins = {}
	Global.blackmarket_manager.armor_skins = armor_skins
	for id, skin in pairs(tweak_data.economy.armor_skins) do
		armor_skins[id] = {unlocked = true}
	end
	return false
end

--intimidate
if Network:is_server() then
	local surrender = CopLogicIdle._surrender
	local on_intimidated = CopLogicIdle.on_intimidated
	local global_toggle_intimidate_on = function( data, amount, aggressor_unit, ... )
		if aggressor_unit == managers.player:player_unit() then
			if (data.unit:base()._tweak_table == "phalanx_vip") or (data.unit:base()._tweak_table == "phalanx_minion") then
				return on_intimidated( data, amount, aggressor_unit, ...)
			end
			surrender( data, amount )
			return true
		else
			return on_intimidated( data, amount, aggressor_unit, ...)
		end
	end
	CopLogicIdle.on_intimidated = global_toggle_intimidate_on
	CopLogicAttack.on_intimidated = global_toggle_intimidate_on
	CopLogicArrest.on_intimidated = global_toggle_intimidate_on
	CopLogicSniper.on_intimidated = global_toggle_intimidate_on

	-- Shield logic
	CopBrain._logic_variants.shield.intimidated = CopLogicIntimidated
	local _do_tied = CopLogicIntimidated._do_tied
	local _chk_spawn_shield = CopInventory._chk_spawn_shield
	local on_intimidated = CopLogicIntimidated.on_intimidated
	function CopLogicIntimidated.on_intimidated( data, amount, aggressor_unit, ... ) 
		local unit = data.unit
		if unit:base()._tweak_table == "shield" then
			_do_tied( data, aggressor_unit )
			_chk_spawn_shield( unit:inventory(), nil )
		else
			on_intimidated( data, amount, aggressor_unit, ... )
		end
	end
end

-- Remove loot cap
tweak_data.money_manager.max_small_loot_value = 9999999999999999	
local LootManager_get_secured_bonus_bags_value = LootManager.get_secured_bonus_bags_value
function LootManager:get_secured_bonus_bags_value( level_id )
	local mandatory_bags_amount = self._global.mandatory_bags.amount or 0
	local value = 0
	for _,data in ipairs( self._global.secured ) do
		if not tweak_data.carry.small_loot[ data.carry_id ] then
			if mandatory_bags_amount > 0 and (self._global.mandatory_bags.carry_id == "none" or self._global.mandatory_bags.carry_id == data.carry_id) then
				mandatory_bags_amount = mandatory_bags_amount - 1
			end
			value = value + managers.money:get_bag_value( data.carry_id, data.multiplier )
	end	end
	return value
end

--dropin p
_networkgameLoadOriginal = _networkgameLoadOriginal or BaseNetworkSession.load
function BaseNetworkSession:load( ... )
	_networkgameLoadOriginal(self, ...)
	Application:set_pause( false )
end
_dropInOriginal = _dropInOriginal or BaseNetworkSession.on_drop_in_pause_request_received
function BaseNetworkSession:on_drop_in_pause_request_received( peer_id, ... )
	if state then
		if not managers.network:session():closing() then
			managers.hud:show_hint( { text = managers.localization:text( "dialog_dropin_title", { USER = string.upper( nickname ) } ) } )
		end
	elseif self._dropin_pause_info[ peer_id ] then
		managers.hud:show_hint( { text = "Player Joined" } ) 
	end
	_dropInOriginal(self, peer_id, ... )
	Application:set_pause( false )
	SoundDevice:set_rtpc( "ingame_sound", 1 )
end
function MenuManager:show_person_joining( ... ) end
 
--display cleaner cost
counter = counter or 0
old_civ_killed = old_civ_killed or MoneyManager.civilian_killed
function MoneyManager:civilian_killed() 
	old_civ_killed(self)
	counter = counter + 1
	amount = self:get_civilian_deduction() * counter
	managers.hud:show_hint({text = "Killed "..tostring(counter).." civilians, paid $"..tostring(amount).." cleaner costs."})
end
 
-- no civ penalty
--MoneyManager.get_civilian_deduction = function(self) return 0 end

--No flashbangs
function CoreEnvironmentControllerManager.set_flashbang() end

--stamina
function PlayerMovement:_change_stamina( value ) end
function PlayerMovement:is_stamina_drained() return false end
function PlayerStandard:_can_run_directional() return true end

-- Interact through walls
function ObjectInteractionManager._raycheck_ok() return true end

--bagcooldown
function PlayerManager:carry_blocked_by_cooldown() return false end

--Weapon reload speed
NewRaycastWeaponBase.reload_speed_multiplier = function(self) return 2 end

--remove bullet delay
function GamePlayCentralManager:play_impact_sound_and_effects( params )
	self:_play_bullet_hit(params)
end

--no modded lobby
function MenuCallbackHandler:is_modded_client()
	return false
end
function MenuCallbackHandler:is_not_modded_client()
	return true
end

--can interact with multiple cams
if Network:is_server() then
	function SecurityCameraInteractionExt:_interact_blocked(player)
		SecurityCamera.active_tape_loop_unit = false
	end
end

-- Carry mods (throwing distance, movement speed, jumping, running)
local car_arr = {'slightly_very_heavy', 'slightly_heavy', 'very_heavy', 'being', 'mega_heavy', 'heavy', 'medium', 'light', 'coke_light', 'cloaker_explosives'}
for i, name in ipairs(car_arr) do
	tweak_data.carry.types[name].throw_distance_multiplier = 1
	tweak_data.carry.types[name].move_speed_modifier = 1
	tweak_data.carry.types[name].jump_modifier = 1
	tweak_data.carry.types[name].can_run = true
end--]]

--deploy bipod anywhere
function WeaponLionGadget1:_is_deployable() 
	return not (self._is_npc or not self:_get_bipod_obj() or self:_is_in_blocked_deployable_state())
end
function NewRaycastWeaponBase:is_bipod_usable() return true end

local old_is_in = old_is_in or BaseInteractionExt._is_in_required_state
function BaseInteractionExt:_is_in_required_state(movement_state)
	return movement_state == "civilian" and true or old_is_in(self, movement_state)
end

--bleedout when cloaker
function PlayerMovement:on_SPOOCed(enemy_unit)
	r = managers.player:local_player():character_damage():set_invulnerable( false )
	r = managers.player:force_drop_carry()
	r = managers.statistics:downed( { death = true } )
	r = managers.player:local_player():character_damage().swansong
	r = managers.player:local_player():character_damage():set_health(0)
	r = IngameFatalState.on_local_player_dead()
	r = managers.player:set_player_state("bleed_out")
	return r
end--]]

--trade delay
function TradeManager:update_auto_assault_ai_trade(dt, is_trade_allowed)
	managers.trade:pause_trade(0)
	managers.trade.TRADE_DELAY = 0
	managers.trade._STOCKHOLM_SYNDROME_DELAY = 0 
	--tweak_data.player.damage.automatic_respawn_time = 0 --respawn you automatic
	return 0
end
function TradeManager:respawn_delay_by_name(character_name)
	--local crim_respawn = managers.trade:get_criminal_to_trade()
	--local peer_id = managers.criminals:character_peer_id_by_name(crim_respawn.id)
	--managers.network:session():spawn_member_by_id(peer_id, "clbk_respawn_criminal", true)
	--managers.network:session():send_to_host("set_trade_spawn", crim_respawn.id)
	--managers.network:session():send_to_host("set_trade_death", criminal_name, 0, 0)
	--stockholm syndrom
	--managers.network:session():send_to_host("set_auto_assault_ai_trade", character_name, 1)
	return 0
end

--free camera anywhere. works when interact too
function FPCameraPlayerBase:set_limits(spin, pitch) end

--dont take dmg when in vehicle
local old_check_dmg = PlayerDamage._chk_can_take_dmg
function PlayerDamage:_chk_can_take_dmg()
	return not managers.player:get_vehicle() and old_check_dmg(self)
end

--hostages always follow
local old_set_objective = CopBrain.set_objective
function CopBrain:set_objective(new_objective, params)
	if new_objective and new_objective.lose_track_dis then new_objective.lose_track_dis = 5000000 end
	old_set_objective(self, new_objective, params)
end

local damage_melee_original = CopDamage.damage_melee
function CopDamage.damage_melee(self, attack_data, ...)
	attack_data.damage = attack_data.damage * 1.4
	return damage_melee_original(self, attack_data, ...)
end

--fast zipline, host only
if Network:is_server() then
	function ZipLine:update(unit, t, dt)
		if not self._enabled then
			return
		end
		if self._usage_type == "bag" then
			self._speed = 3000
		else
			self._speed = 1000
		end
		self:_update_total_time()
		self:_update_sled(t, dt)
		self:_update_sounds(t, dt)
		if ZipLine.DEBUG then
			self:debug_draw(t, dt)
		end
	end
end

--anti slow time
local slowmo_reverse = true
local heist_lock = true
local bounce_lock = {0, 0, 0, 0}
local reset_bounce = function(id)
	bounce_lock[id] = 1
end

local start_time_effect = UnitNetworkHandler.start_timespeed_effect
function UnitNetworkHandler:start_timespeed_effect(effect_id, timer_name, affect_timer_names_str, speed, fade_in, sustain, fade_out, sender)
	if heist_lock and sustain <= 10 and Global.game_settings.level_id == 'mia_2' and (affect_timer_names_str == nil or affect_timer_names_str == "player;") then
		start_time_effect(self, effect_id, timer_name, affect_timer_names_str, speed, fade_in, sustain, fade_out, sender)
		heist_lock = false
		managers.chat:_receive_message(1, "anti_slow_time", "Slow Time Disabled", tweak_data.system_chat_color)
	else
		local peer = self._verify_sender(sender)
		if not peer then
			managers.chat:_receive_message(1, "anti_slow_time2", "Someone tried use slow time on you...", tweak_data.system_chat_color)
			return
		end
		local id = peer:id()
		local cur_bounce = bounce_lock[id]
		if slowmo_reverse then
			if cur_bounce < 4 then
				bounce_lock[id] = cur_bounce + 1
				peer:send('start_timespeed_effect', effect_id, timer_name, affect_timer_names_str, speed, fade_in, sustain, fade_out)
				DelayedCalls:Add( "bounce_lock_reset_", 10, function() reset_bounce(id) end)
			else
				reset_bounce(id)
			end
		end
		if cur_bounce == 0 then
			managers.chat:_receive_message(1, "anti_slow_time3", peer:name().." tried to use slowmotion on you...Revenge ACTIVATED", tweak_data.system_chat_color) 
		end
	end
end

local orig_exec = MissionScriptElement.on_executed
function MissionScriptElement:on_executed(...)
	orig_exec(self, ...)
	if not Network:is_server() then return end
	if managers.job:current_level_id() == "rat" then
		--top floor
		--managers.mission._scripts["default"]._elements[100329]._values.rotation = Rotation(-90, 0, -0)
		--managers.mission._scripts["default"]._elements[100329]._values.position = Vector3(1964.79, 700.00, 2100.00)
		--basement
		--managers.mission._scripts["default"]._elements[100332]._values.rotation = Rotation(-90, 0, -0)
		--managers.mission._scripts["default"]._elements[100332]._values.position = Vector3(1964.79, 700.00, 2100.00)
		--middle floor spawn roof
		managers.mission._scripts["default"]._elements[100330]._values.rotation = Rotation(-90, 0, -0)
		managers.mission._scripts["default"]._elements[100330]._values.position = Vector3(1964.79, 700.00, 2100.00)
		--enable basement lab
		managers.mission._scripts["default"]._elements[100486]._values.enabled = true
		--disable middle upper floors
		--managers.mission._scripts["default"]._elements[100483]._values.enabled = false
		--managers.mission._scripts["default"]._elements[100485]._values.enabled = false
	elseif managers.job:current_level_id() == "kosugi" then
		--enable spawn container all the time shadow raid
		managers.mission._scripts["default"]._elements[100303]._values.enabled = false
	end
end

local orig_upgrade_value_ = PlayerManager.upgrade_value
function PlayerManager:upgrade_value( category, upgrade, default ) 
	local r = orig_upgrade_value_(self, category, upgrade, default) 
	if category == "player" and upgrade == "convert_enemies" then
		return true
	elseif category == "player" and upgrade == "convert_enemies_max_minions" and Network:is_server() then
		return r + 1000
	elseif category == "player" and upgrade == "minion_master_speed_multiplier" and Network:is_server() then
		return r + 0.5
	elseif category == "player" and upgrade == "minion_master_health_multiplier" and Network:is_server() then
		return r + 1.2
	else 
		return r
	end
end

BetterDelayedCalls:Add("PERSISTSHOOK_truepersist", 0.1, function()
	function is_playing()
		if not BaseNetworkHandler then 
			return false 
		end
		return BaseNetworkHandler._gamestate_filter.any_ingame_playing[ game_state_machine:last_queued_state_name() ]
	end
	
	if is_playing() then
		-- No movement penalty, change to a larger value than 1 for an increase in speed
		PlayerManager.body_armor_movement_penalty = function(self) return 1 end
	
		if managers.job:current_level_id() == "rat" then
			--place zipline
			managers.mission._scripts["default"]._elements[102060]:on_executed(managers.player:player_unit())
		elseif managers.job:current_level_id() == "kosugi" then
			--truck secure
			managers.mission._scripts["default"]._elements[102972]:on_executed(managers.player:player_unit())
			managers.mission._scripts["default"]._elements[103464]:on_executed(managers.player:player_unit())
		end
		--trade jailed
		--managers.trade:update_auto_assault_ai_trade(dt, true)
		
		--open dupsters that cant be opened
		local dumpsters = { 	
			["1cbee76c179b5192"] = true, --units/pd2_dlc_brb/props/brb_prop_alley_trash_container/brb_prop_alley_trash_container
			["cfe6b1dca77ba461"] = true, --units/payday2/props/str_prop_alley_trash_container/str_prop_alley_trash_container
			["421a4ea84848010c"] = true,  --units/world/street/trash_container/trash_container
		}
		for i,unit in pairs(World:find_units_quick("all", 1)) do
			if unit and unit:name() and dumpsters[unit:name():key()] then 
				unit:interaction():set_active(true)
			end
		end
		
		--carry more specials
		if Network.is_server(Network) then
			local _hefty={
				bank_manager_key=2,
				lance_part=15,
				boards=15,
				planks=15,
				thermite_paste=15,
				saw_blade=15,
				c4_x3=15,
				c4_x10=15,
				blood_sample=15,
				blood_sample_verified=15,
				circle_cutter=15,
				mayan_gold_bar=15,
				cable_tie=5,
				gas=4
			}
			for name, quantity in pairs(_hefty) do
				tweak_data.equipments.specials[name].max_quantity=quantity
				tweak_data.equipments.specials[name].quantity=1
			end
		else
			local _hefty={
				bank_manager_key=1,
				lance_part=15,
				boards=15,
				planks=15,
				thermite_paste=15,
				saw_blade=15,
				c4_x3=15,
				c4_x10=15,
				blood_sample=15,
				blood_sample_verified=15,
				circle_cutter=15,
				mayan_gold_bar=15,
				cable_tie=5,
				gas=4
			}
			for name, quantity in pairs(_hefty) do
				tweak_data.equipments.specials[name].max_quantity=quantity
				tweak_data.equipments.specials[name].quantity=1
			end
		end
		
		-- Infinite Cable Ties
		if managers.player:can_pickup_equipment("cable_tie") then
			managers.player:add_special( { name = "cable_tie", silent = true, amount = 1 } )
		end
		
		if (toggleUpdateMarks == true) then
			PlayerManager.xpTexts = {}

			function round2(num, idp)
				return string.format("BONUS EXP: %." .. (idp or 0) .. "f%%   -   BASE EXP: ", num)
			end
			Hooks:Add("GameSetupUpdate", "GameSetupUpdate_id", function(t, dt)
				--xray
				if not _gameUpdateLastMark or t - _gameUpdateLastMark > 1 then
					_gameUpdateLastMark = t
					xray_manager:markEnemies()
				end
				--hud
				if PlayerManager.posPanel then
					local text = ""
					if managers.groupai and managers.groupai:state() then 
						text = round2(managers.groupai:state()._difficulty_value or 0,2)
						PlayerManager.posText:set_color(managers.groupai:state()._hunt_mode and Color(1,0,0) or managers.groupai:state()._enemy_weapons_hot and Color(255,215,0) or Color("CD7F32"))
					else
						text = round2(0,2)
						PlayerManager.posText:set_color(Color(0,1,1))
					end
					if managers.experience and managers.experience._global and managers.experience._global.mission_xp_current then
						text = text .. " " .. tostring(Application:digest_value(managers.experience._global.mission_xp_current, false)) or "None"
						
						for xpTime, xpText in pairs(PlayerManager.xpTexts) do
							if t < xpTime + 20 then
								text = text .. ", " .. xpText
							else
								table.remove(PlayerManager.xpTexts, xpTime)
							end
						end
					else
						text = text .. " 0"
					end
					PlayerManager.posText:set_text(text)
				else
					if managers.hud then
						local hud = managers.hud:script(PlayerBase.PLAYER_INFO_HUD_FULLSCREEN_PD2)
						PlayerManager.posPanel = hud.panel:panel({name = "positionpanel"})
						PlayerManager.posText = PlayerManager.posPanel:text({
							name = "textname",
							text = "texttext",
							font = tweak_data.hud.medium_font,
							font_size = tweak_data.hud.name_label_font_size,
							color = Color.green,
							align = "center",
							vertical = "top",
							layer = 1,
							w = 1300,
							h = 24
						})
					end
				end
			end)
			core:import("CoreMissionScriptElement")
			Hooks:Add("ElementExperienceOnExecuted", "ElementExperienceOnExecuted_id", function(instigator)
			--function ElementExperience.on_executed(self, instigator)
				if not self._values.enabled then
					return
				end
				local text = self._editor_name .. ": " .. self._values.amount
				local curTime = TimerManager:game():time()
				if PlayerManager.xpTexts[curTime] then 
					PlayerManager.xpTexts[curTime] = PlayerManager.xpTexts[curTime] .. ", " .. text
				else
					PlayerManager.xpTexts[curTime] = text
				end
				managers.experience:mission_xp_award(self._values.amount)
				ElementExperience.super.on_executed(self, instigator)
			end)
		end
	end

	--[[slot machine, run on bottom
	if Network.is_server(Network) then
		local level_id = managers.job:current_level_id()
		if (level_id == "kenaz" or level_id == "chill") then
			core:module("CoreElementLogicChance")
			core:import("CoreMissionScriptElement")
			ElementLogicChance = ElementLogicChance or class(CoreMissionScriptElement.MissionScriptElement)
			Hooks:PreHook(ElementLogicChance, "on_executed", "slot_machine_hook_id", function(self)
				if self._editor_name == "1_chance" and (Global.level_data.level_id == "kenaz" or Global.level_data.level_id == "chill") then
					self._chance = 999
				end
			end)
		end
	end--]]
end, true)