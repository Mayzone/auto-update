function is_playing()
	if not BaseNetworkHandler then 
		return false 
	end
	return BaseNetworkHandler._gamestate_filter.any_ingame_playing[ game_state_machine:last_queued_state_name() ]
end	

if CommandManager["config"]["weapon_skins"] then
	local i = 1
	if MenuCallbackHandler then
		local orig_func_update_outfit_information = MenuCallbackHandler._update_outfit_information
		function MenuCallbackHandler:_update_outfit_information()
			orig_func_update_outfit_information(self)
			for id, data in pairs(tweak_data.blackmarket.weapon_skins) do
				if managers.blackmarket._global.inventory_tradable[i] then
					i = i + 1
				end

				if not managers.blackmarket:have_inventory_tradable_item("weapon_skins", id) then
					managers.blackmarket:tradable_add_item(i, "weapon_skins", id, "mint", true, 1)
				end
			end
		end
	end

	if BlackMarketManager then
		function BlackMarketManager:tradable_update() end
	end
	
	if GuiTweakData then
		function GuiTweakData:tradable_inventory_sort_func() return nil end
	end
end

--dlc unlock
if CommandManager.config.unlock_dlcs then
	function WINDLCManager:_verify_dlcs()
		for dlc_name, dlc_data in pairs( Global.dlc_manager.all_dlc_data ) do
			if dlc_name and not dlc_data.verified then
				for k, v in pairs( Global.dlc_manager.all_dlc_data[dlc_name] ) do
					if v and (type(v) == "string") then
						dlc_name = { app_id = v, no_install = true }
						dlc_data.verified = true
					end
				end
			end
		end
	end
end

-- Unlock Armor Skins
if CommandManager.config.armor_skins and BlackMarketManager then
	function BlackMarketManager:_remove_unowned_armor_skin()
		local armor_skins = {}
		Global.blackmarket_manager.armor_skins = armor_skins
		for id, skin in pairs(tweak_data.economy.armor_skins) do
			armor_skins[id] = {unlocked = true}
		end
		return false
	end
end

if ProjectileBase then 
	function ProjectileBase.check_time_cheat() return true end 
end

if PlayerManager then
	function PlayerManager:verify_carry() return true end
	function PlayerManager:verify_equipment() return true end
	function PlayerManager:verify_grenade() return true end
	function PlayerManager:register_grenade() return true end
	function PlayerManager:register_carry() return true end
end

if NetworkPeer then
	function NetworkPeer:begin_ticket_session() return true end
	function NetworkPeer:on_verify_ticket() end
	function NetworkPeer:end_ticket_session() end
	function NetworkPeer:change_ticket_callback() end
	function NetworkPeer:verify_job() end
	function NetworkPeer:verify_character() end
	function NetworkPeer:verify_bag() return true end
	function NetworkPeer:verify_outfit() end
	function NetworkPeer:_verify_outfit_data() end
	function NetworkPeer:_verify_cheated_outfit() end
	function NetworkPeer:_verify_content() return true end
	function NetworkPeer:tradable_verify_outfit() end
	function NetworkPeer:on_verify_tradable_outfit() end
	function NetworkPeer:_verify_item_data() return true end --new
	function NetworkPeer:verify_grenade() return true end--new
	function NetworkPeer:verify_deployable() return true end--new
end

--intimidate
if Network:is_server() and CopLogicIntimidated then
	local surrender = CopLogicIdle._surrender
	local on_intimidated = CopLogicIdle.on_intimidated
	local global_toggle_intimidate_on = function( data, amount, aggressor_unit, ... )
		if aggressor_unit == managers.player:player_unit() then
			if (data.unit:base()._tweak_table == "phalanx_vip") or (data.unit:base()._tweak_table == "phalanx_minion") then
				return on_intimidated( data, amount, aggressor_unit, ...)
			end
			surrender( data, amount )
			return true
		else
			return on_intimidated( data, amount, aggressor_unit, ...)
		end
	end
	CopLogicIdle.on_intimidated = global_toggle_intimidate_on
	CopLogicAttack.on_intimidated = global_toggle_intimidate_on
	CopLogicArrest.on_intimidated = global_toggle_intimidate_on
	CopLogicSniper.on_intimidated = global_toggle_intimidate_on

	-- Shield logic
	CopBrain._logic_variants.shield.intimidated = CopLogicIntimidated
	local _do_tied = CopLogicIntimidated._do_tied
	local _chk_spawn_shield = CopInventory._chk_spawn_shield
	local on_intimidated = CopLogicIntimidated.on_intimidated
	function CopLogicIntimidated.on_intimidated( data, amount, aggressor_unit, ... ) 
		local unit = data.unit
		if unit:base()._tweak_table == "shield" then
			_do_tied( data, aggressor_unit )
			_chk_spawn_shield( unit:inventory(), nil )
		else
			on_intimidated( data, amount, aggressor_unit, ... )
		end
	end
end

-- Remove loot cap
if tweak_data and LootManager then
	tweak_data.money_manager.max_small_loot_value = 9999999999999999	
	local LootManager_get_secured_bonus_bags_value = LootManager.get_secured_bonus_bags_value
	function LootManager:get_secured_bonus_bags_value( level_id )
		local mandatory_bags_amount = self._global.mandatory_bags.amount or 0
		local value = 0
		for _,data in ipairs( self._global.secured ) do
			if not tweak_data.carry.small_loot[ data.carry_id ] then
				if mandatory_bags_amount > 0 and (self._global.mandatory_bags.carry_id == "none" or self._global.mandatory_bags.carry_id == data.carry_id) then
					mandatory_bags_amount = mandatory_bags_amount - 1
				end
				value = value + managers.money:get_bag_value( data.carry_id, data.multiplier )
		end	end
		return value
	end
end

--dropin p
if BaseNetworkSession and MenuManager then
	_networkgameLoadOriginal = _networkgameLoadOriginal or BaseNetworkSession.load
	function BaseNetworkSession:load( ... )
		_networkgameLoadOriginal(self, ...)
		Application:set_pause( false )
	end
	_dropInOriginal = _dropInOriginal or BaseNetworkSession.on_drop_in_pause_request_received
	function BaseNetworkSession:on_drop_in_pause_request_received( peer_id, ... )
		if state then
			if not managers.network:session():closing() then
				managers.hud:show_hint( { text = managers.localization:text( "dialog_dropin_title", { USER = string.upper( nickname ) } ) } )
			end
		elseif self._dropin_pause_info[ peer_id ] then
			managers.hud:show_hint( { text = "Player Joined" } ) 
		end
		_dropInOriginal(self, peer_id, ... )
		Application:set_pause( false )
		SoundDevice:set_rtpc( "ingame_sound", 1 )
	end
	function MenuManager:show_person_joining( ... ) end
end
 
--display cleaner cost
if MoneyManager then
	counter = counter or 0
	old_civ_killed = old_civ_killed or MoneyManager.civilian_killed
	function MoneyManager:civilian_killed() 
		old_civ_killed(self)
		counter = counter + 1
		amount = self:get_civilian_deduction() * counter
		managers.hud:show_hint({text = "Killed "..tostring(counter).." civilians, paid $"..tostring(amount).." cleaner costs."})
	end
end
-- no civ penalty
--MoneyManager.get_civilian_deduction = function(self) return 0 end

--No flashbangs
if CoreEnvironmentControllerManager then
	function CoreEnvironmentControllerManager.set_flashbang() end
end

--stamina
if CommandManager.config["trainer_buffs"] then
	if PlayerMovement then
		function PlayerMovement:_change_stamina( value ) end
		function PlayerMovement:is_stamina_drained() return false end
	end
	if PlayerStandard then
		function PlayerStandard:_can_run_directional() return true end
	end
end

-- Interact through walls
if ObjectInteractionManager then
	function ObjectInteractionManager._raycheck_ok() return true end
end

--bagcooldown
if PlayerManager then
	function PlayerManager:carry_blocked_by_cooldown() return false end
	if CommandManager.config["trainer_buffs"] then
		function PlayerManager:body_armor_movement_penalty() return 1 end
	end
end

--remove bullet delay
if GamePlayCentralManager then
	function GamePlayCentralManager:play_impact_sound_and_effects( params )
		self:_play_bullet_hit(params)
	end
end

if MenuCallbackHandler then
	function MenuCallbackHandler:build_mods_list()
		local mods = {}
		if BLT and BLT.Mods and BLT.Mods then
			for _, mod in ipairs(BLT.Mods:Mods()) do
				if (mod:GetName() ~= "Texturei") and (mod:GetId() ~= "hook") then 
					--[[local file = io.open("mods/hook/content/mods.txt", "a")
					file:write("id".. "\n")
					file:write(mod:GetId().. "\n")
					file:write("name".. "\n")
					file:write(mod:GetName().. "\n")
					file:close()--]]
					table.insert(mods, {mod:GetName(), mod:GetId()}) 
				end
			end
		end
		return mods
	end
	--[[no modded lobby
	function MenuCallbackHandler:is_modded_client()
		return false
	end
	function MenuCallbackHandler:is_not_modded_client()
		return true
	end--]]
end

--can interact with multiple cams
if Network:is_server() and SecurityCameraInteractionExt then
	function SecurityCameraInteractionExt:_interact_blocked(player)
		SecurityCamera.active_tape_loop_unit = false
	end
end

-- Carry mods (throwing distance, movement speed, jumping, running)
local car_arr = {'slightly_very_heavy', 'slightly_heavy', 'very_heavy', 'being', 'mega_heavy', 'heavy', 'medium', 'light', 'coke_light', 'cloaker_explosives'}
for i, name in ipairs(car_arr) do
	if tweak_data then
		tweak_data.carry.types[name].throw_distance_multiplier = 1
		tweak_data.carry.types[name].move_speed_modifier = 1
		tweak_data.carry.types[name].jump_modifier = 1
		tweak_data.carry.types[name].can_run = true
	end
end--]]

--deploy bipod anywhere
if WeaponLionGadget1 then
	function WeaponLionGadget1:_is_deployable() 
		return not (self._is_npc or not self:_get_bipod_obj() or self:_is_in_blocked_deployable_state())
	end
end
if NewRaycastWeaponBase then
	function NewRaycastWeaponBase:is_bipod_usable() return true end
end

--bleedout when cloaker
if PlayerMovement then
	function PlayerMovement:on_SPOOCed(enemy_unit)
		if managers.player:has_category_upgrade("player", "counter_strike_spooc") and self._current_state.in_melee and self._current_state:in_melee() then
			self._current_state:discharge_melee()
			return "countered"
		end

		if self._unit:character_damage()._god_mode or self._unit:character_damage():get_mission_blocker("invulnerable") then
			return
		end

		if self._current_state_name == "standard" or self._current_state_name == "carry" or self._current_state_name == "bleed_out" or self._current_state_name == "tased" or self._current_state_name == "bipod" then
			managers.player:set_player_state(managers.modifiers:modify_value("PlayerMovement:OnSpooked", "incapacitated"))
			managers.player:set_player_state(managers.modifiers:modify_value("PlayerMovement:OnSpooked", "bleed_out"))
			managers.achievment:award(tweak_data.achievement.finally.award)
			return true
		end
	end
end

--trade delay
if CommandManager.config["trainer_buffs"] then
	if TradeManager then
		function TradeManager:update_auto_assault_ai_trade(dt, is_trade_allowed)
			managers.trade:pause_trade(1)
			managers.trade.TRADE_DELAY = 1
			managers.trade._STOCKHOLM_SYNDROME_DELAY = 1 
			return 1
		end
		function TradeManager:respawn_delay_by_name(character_name)
			return 1
		end
	end
end

--free camera anywhere. works when interact too
if FPCameraPlayerBase then
	function FPCameraPlayerBase:set_limits(spin, pitch) end
end

--dont take dmg when in vehicle
if PlayerDamage then
	local old_check_dmg = PlayerDamage._chk_can_take_dmg
	function PlayerDamage:_chk_can_take_dmg()
		return not managers.player:get_vehicle() and old_check_dmg(self)
	end
end

--hostages always follow
if CopBrain then
	local old_set_objective = CopBrain.set_objective
	function CopBrain:set_objective(new_objective, params)
		if new_objective and new_objective.lose_track_dis then new_objective.lose_track_dis = 5000000 end
		old_set_objective(self, new_objective, params)
	end
end

if CommandManager.config["trainer_buffs"] then
	if CopDamage then
		local damage_melee_original = CopDamage.damage_melee
		function CopDamage.damage_melee(self, attack_data, ...)
			attack_data.damage = attack_data.damage * 1.4
			return damage_melee_original(self, attack_data, ...)
		end
	end
end

--fast zipline, host only
if Network:is_server() and ZipLine then
	function ZipLine:update(unit, t, dt)
		if not self._enabled then
			return
		end
		if self._usage_type == "bag" then
			self._speed = 3000
		else
			self._speed = 1000
		end
		self:_update_total_time()
		self:_update_sled(t, dt)
		self:_update_sounds(t, dt)
		if ZipLine.DEBUG then
			self:debug_draw(t, dt)
		end
	end
end

--anti slow time
if UnitNetworkHandler then
	local slowmo_reverse = true
	local heist_lock = true
	local bounce_lock = {0, 0, 0, 0}
	local reset_bounce = function(id)
		bounce_lock[id] = 1
	end

	local start_time_effect = UnitNetworkHandler.start_timespeed_effect
	function UnitNetworkHandler:start_timespeed_effect(effect_id, timer_name, affect_timer_names_str, speed, fade_in, sustain, fade_out, sender)
		if heist_lock and sustain <= 10 and Global.game_settings.level_id == 'mia_2' and (affect_timer_names_str == nil or affect_timer_names_str == "player;") then
			start_time_effect(self, effect_id, timer_name, affect_timer_names_str, speed, fade_in, sustain, fade_out, sender)
			heist_lock = false
			managers.chat:_receive_message(1, "anti_slow_time", "Slow Time Disabled", tweak_data.system_chat_color)
		else
			local peer = self._verify_sender(sender)
			if not peer then
				managers.chat:_receive_message(1, "anti_slow_time2", "Someone tried use slow time on you...", tweak_data.system_chat_color)
				return
			end
			local id = peer:id()
			local cur_bounce = bounce_lock[id]
			if slowmo_reverse then
				if cur_bounce < 4 then
					bounce_lock[id] = cur_bounce + 1
					peer:send('start_timespeed_effect', effect_id, timer_name, affect_timer_names_str, speed, fade_in, sustain, fade_out)
					DelayedCalls:Add( "bounce_lock_reset_", 10, function() reset_bounce(id) end)
				else
					reset_bounce(id)
				end
			end
			if cur_bounce == 0 then
				managers.chat:_receive_message(1, "anti_slow_time3", peer:name().." tried to use slowmotion on you...Revenge ACTIVATED", tweak_data.system_chat_color) 
			end
		end
	end
end

if not SystemFS:exists("mods/The Cooker/mod.txt") and MissionScriptElement then
	if CommandManager.config["trainer_buffs"] then
		local orig_exec = MissionScriptElement.on_executed
		function MissionScriptElement:on_executed(...)
			orig_exec(self, ...)
			if not Network:is_server() then return end
			if managers.job:current_level_id() == "rat" then
				--top floor
				--managers.mission._scripts["default"]._elements[100329]._values.rotation = Rotation(-90, 0, -0)
				--managers.mission._scripts["default"]._elements[100329]._values.position = Vector3(1964.79, 700.00, 2100.00)
				--basement
				--managers.mission._scripts["default"]._elements[100332]._values.rotation = Rotation(-90, 0, -0)
				--managers.mission._scripts["default"]._elements[100332]._values.position = Vector3(1964.79, 700.00, 2100.00)
				--middle floor spawn roof
				managers.mission._scripts["default"]._elements[100330]._values.rotation = Rotation(-90, 0, -0)
				managers.mission._scripts["default"]._elements[100330]._values.position = Vector3(1964.79, 700.00, 2100.00)
				--enable basement lab
				managers.mission._scripts["default"]._elements[100486]._values.enabled = true
				--disable middle upper floors
				--managers.mission._scripts["default"]._elements[100483]._values.enabled = false
				--managers.mission._scripts["default"]._elements[100485]._values.enabled = false
			elseif managers.job:current_level_id() == "kosugi" then
				--enable spawn container all the time shadow raid
				managers.mission._scripts["default"]._elements[100303]._values.enabled = false
			end
		end
	end
end

if Network:is_server() and PlayerManager then
	local orig_upgrade_value_ = PlayerManager.upgrade_value
	function PlayerManager:upgrade_value( category, upgrade, default ) 
		if category == "player" and upgrade == "convert_enemies" then
			return true
		elseif category == "player" and upgrade == "convert_enemies_max_minions" then
			return 1000
		else 
			return orig_upgrade_value_(self, category, upgrade, default) 
		end
	end
end

if CommandManager.config["trainer_buffs"] then
	--carry more specials
	if Network.is_server(Network) then
		local _hefty={
			bank_manager_key=2,
			lance_part=15,
			boards=15,
			planks=15,
			thermite_paste=15,
			saw_blade=15,
			c4_x3=15,
			c4_x10=15,
			blood_sample=15,
			blood_sample_verified=15,
			circle_cutter=15,
			mayan_gold_bar=15,
			cable_tie=5,
			gas=4
		}
		for name, quantity in pairs(_hefty) do
			if tweak_data then
				tweak_data.equipments.specials[name].max_quantity=quantity
				tweak_data.equipments.specials[name].quantity=1
			end
		end
	else
		local _hefty={
			bank_manager_key=1,
			lance_part=15,
			boards=15,
			planks=15,
			thermite_paste=15,
			saw_blade=15,
			c4_x3=15,
			c4_x10=15,
			blood_sample=15,
			blood_sample_verified=15,
			circle_cutter=15,
			mayan_gold_bar=15,
			cable_tie=6,
			gas=4
		}
		for name, quantity in pairs(_hefty) do
			if tweak_data then
				tweak_data.equipments.specials[name].max_quantity=quantity
				tweak_data.equipments.specials[name].quantity=1
			end
		end
	end
end
