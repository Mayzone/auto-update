local hud_panel = Overlay:newgui():create_screen_workspace():panel()
local hit_confirm = hud_panel:bitmap({ 
	visible = 20,
	w = 15,
	h = 15,
	color = Color(0, 140, 0):with_alpha(200),
	layer = 0,
	name = hit_confirm,
	blend_mode="add"
})
hit_confirm:set_center(hud_panel:center())