if not rawget(_G, "xray_share_manager") then
	rawset(_G, "xray_share_manager", {})

	function xray_share_manager:is_playing()
		if not BaseNetworkHandler then 
			return false 
		end
		return BaseNetworkHandler._gamestate_filter.any_ingame_playing[ game_state_machine:last_queued_state_name() ]
	end
	
	function xray_share_manager:_toggle()
		if not self:is_playing() then
			return
		end
		
		if not xray_manager.toggle then
			return
		end
		
		self.toggle = self.toggle or false
		if not self.toggle then
			xray_manager:markToggle_on(true)
			xray_share_on = true
			managers.mission._fading_debug_output:script().log('Xray Team - ACTIVATED', Color.green)
		else
			xray_manager:markToggle_off(false)
			xray_share_on = false
			managers.mission._fading_debug_output:script().log('Xray Team - DEACTIVATED', Color.red)
		end
		self.toggle = not self.toggle
	end
	xray_share_manager:_toggle()
else
	xray_share_manager:_toggle()
end