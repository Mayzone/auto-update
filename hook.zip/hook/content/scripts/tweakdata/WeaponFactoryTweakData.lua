--add lmg scope mods
local _initorig = WeaponFactoryTweakData._init_rpk
function WeaponFactoryTweakData:_init_rpk()
	_initorig(self)
	for _,part in ipairs(self.parts.wpn_fps_shot_r870_s_folding.forbids) do
		if ( part ~= "wpn_fps_upg_o_acog" and part ~= "wpn_fps_shot_r870_ris_special" ) then
			table.insert(self.wpn_fps_lmg_rpk.uses_parts, part)
		end
	end
end

local _initorig2 = WeaponFactoryTweakData._init_m249
function WeaponFactoryTweakData:_init_m249()
	_initorig2(self)
	for _,part in ipairs(self.parts.wpn_fps_shot_r870_s_folding.forbids) do
		if ( part ~= "wpn_fps_upg_o_acog" and part ~= "wpn_fps_shot_r870_ris_special" ) then
			table.insert(self.wpn_fps_lmg_m249.uses_parts, part)
		end
	end
end

local _initorig3 = WeaponFactoryTweakData._init_hk21
function WeaponFactoryTweakData:_init_hk21()
	_initorig3(self)
	for _,part in ipairs(self.parts.wpn_fps_shot_r870_s_folding.forbids) do
		if ( part ~= "wpn_fps_upg_o_acog" and part ~= "wpn_fps_shot_r870_ris_special" ) then
			table.insert(self.wpn_fps_lmg_hk21.uses_parts, part)
		end
	end
end

local _initorig4 = WeaponFactoryTweakData._init_mg42
function WeaponFactoryTweakData:_init_mg42()
	_initorig4(self)
	for _,part in ipairs(self.parts.wpn_fps_shot_r870_s_folding.forbids) do
		if ( part ~= "wpn_fps_upg_o_acog" and part ~= "wpn_fps_shot_r870_ris_special" ) then
			table.insert(self.wpn_fps_lmg_mg42.uses_parts, part)
		end
	end
end

local _initorig5 = WeaponFactoryTweakData._init_par
function WeaponFactoryTweakData:_init_par()
	_initorig5(self)
	for _,part in ipairs(self.parts.wpn_fps_shot_r870_s_folding.forbids) do
		if ( part ~= "wpn_fps_upg_o_acog" and part ~= "wpn_fps_shot_r870_ris_special" ) then
			table.insert(self.wpn_fps_lmg_par.uses_parts, part)
		end
	end
end


local _initorig6 = WeaponFactoryTweakData.create_ammunition
function WeaponFactoryTweakData:create_ammunition()
	_initorig6(self)
	local weapons = {
		"wpn_fps_ass_m4",
		"wpn_fps_ass_amcar",
		"wpn_fps_ass_m16",
		"wpn_fps_ass_akm",
		"wpn_fps_ass_akm_gold",
		"wpn_fps_ass_ak5",
		"wpn_fps_ass_aug",
		"wpn_fps_ass_g36",
		"wpn_fps_ass_m14",
		"wpn_fps_ass_s552",
		"wpn_fps_ass_scar",
		"wpn_fps_ass_fal",
		"wpn_fps_ass_g3",
		"wpn_fps_ass_galil",
		"wpn_fps_ass_famas",
		"wpn_fps_ass_l85a2",
		"wpn_fps_ass_vhs",
		"wpn_fps_ass_asval",
		"wpn_fps_ass_sub2000",
		"wpn_fps_ass_tecci",
		"wpn_fps_ass_contraband",
		"wpn_fps_ass_flint",
		"wpn_fps_ass_ching",
		"wpn_fps_ass_corgi",
		"wpn_fps_ass_komodo",
		"wpn_fps_pis_g18c",
		"wpn_fps_pis_deagle",
		"wpn_fps_pis_g17",
		"wpn_fps_pis_usp",
		"wpn_fps_pis_g22c",
		"wpn_fps_pis_judge",
		"wpn_fps_pis_ppk",
		"wpn_fps_pis_p226",
		"wpn_fps_pis_g26",
		"wpn_fps_pis_c96",
		"wpn_fps_pis_hs2000",
		"wpn_fps_pis_x_g22c",
		"wpn_fps_pis_x_g17",
		"wpn_fps_pis_x_usp",
		"wpn_fps_pis_peacemaker",
		"wpn_fps_pis_sparrow",
		"wpn_fps_pis_pl14",
		"wpn_fps_pis_packrat",
		"wpn_fps_pis_lemming",
		"wpn_fps_pis_chinchilla",
		"wpn_fps_pis_x_chinchilla",
		"wpn_fps_pis_breech",
		"wpn_fps_pis_shrew",
		"wpn_fps_pis_x_shrew",
		"wpn_fps_pis_x_2006m",
		"wpn_fps_pis_x_breech",
		"wpn_fps_pis_x_c96",
		"wpn_fps_pis_x_g18c",
		"wpn_fps_pis_x_hs2000",
		"wpn_fps_pis_x_p226",
		"wpn_fps_pis_x_pl14",
		"wpn_fps_pis_x_ppk",
		"wpn_fps_pis_x_rage",
		"wpn_fps_pis_x_sparrow",
		"wpn_fps_pis_x_judge",
		"wpn_fps_pis_legacy",
		"wpn_fps_pis_x_legacy",
		"wpn_fps_pis_beer",
		"wpn_fps_pis_x_beer",
		"wpn_fps_pis_czech",
		"wpn_fps_pis_x_czech",
		"wpn_fps_pis_stech",
		"wpn_fps_pis_x_stech",
		"wpn_fps_shot_saiga",
		"wpn_fps_shot_r870",
		"wpn_fps_shot_huntsman",
		"wpn_fps_shot_serbu",
		"wpn_fps_shot_b682",
		"wpn_fps_shot_m37",
		"wpn_fps_snp_m95",
		"wpn_fps_snp_msr",
		"wpn_fps_snp_r93",
		"wpn_fps_snp_mosin",
		"wpn_fps_snp_wa2000",
		"wpn_fps_snp_model70",
		"wpn_fps_snp_desertfox",
		"wpn_fps_snp_tti",
		"wpn_fps_snp_siltstone",
		"wpn_fps_smg_olympic",
		"wpn_fps_smg_akmsu",
		"wpn_fps_smg_p90",
		"wpn_fps_smg_mp9",
		"wpn_fps_smg_mp5",
		"wpn_fps_smg_mac10",
		"wpn_fps_smg_m45",
		"wpn_fps_smg_mp7",
		"wpn_fps_smg_scorpion",
		"wpn_fps_smg_tec9",
		"wpn_fps_smg_uzi",
		"wpn_fps_smg_sterling",
		"wpn_fps_smg_cobray",
		"wpn_fps_smg_polymer",
		"wpn_fps_smg_baka",
		"wpn_fps_smg_sr2",
		"wpn_fps_smg_x_sr2",
		"wpn_fps_smg_x_mp5",
		"wpn_fps_smg_x_akmsu",
		"wpn_fps_smg_hajk",
		"wpn_fps_smg_schakal",
		"wpn_fps_smg_coal",
		"wpn_fps_smg_shepheard",
		"wpn_fps_smg_x_shepheard",
		"wpn_fps_smg_erma",
		"wpn_fps_smg_x_coal",
		"wpn_fps_smg_x_baka",
		"wpn_fps_smg_x_cobray",
		"wpn_fps_smg_x_erma",
		"wpn_fps_smg_x_hajk",
		"wpn_fps_smg_x_m45",
		"wpn_fps_smg_x_m1928",
		"wpn_fps_smg_x_mac10",
		"wpn_fps_smg_x_mp7",
		"wpn_fps_smg_x_mp9",
		"wpn_fps_smg_x_olympic",
		"wpn_fps_smg_x_p90",
		"wpn_fps_smg_x_polymer",
		"wpn_fps_smg_x_schakal",
		"wpn_fps_smg_x_scorpion",
		"wpn_fps_smg_x_sterling",
		"wpn_fps_smg_x_tec9",
		"wpn_fps_smg_x_uzi",
		"wpn_fps_lmg_hk21",
		"wpn_fps_lmg_m249",
		"wpn_fps_lmg_rpk",
		"wpn_fps_lmg_mg42",
		"wpn_fps_lmg_m134",
		"wpn_fps_lmg_par",
		"wpn_fps_lmg_shuno",
		"wpn_fps_sho_ben",
		"wpn_fps_sho_striker",
		"wpn_fps_sho_ksg",
		"wpn_fps_sho_spas12",
		"wpn_fps_sho_aa12",
		"wpn_fps_sho_boot",
		"wpn_fps_sho_rota",
		"wpn_fps_sho_basset",
		"wpn_fps_sho_x_basset",
		"wpn_fps_sho_x_rota",
		"wpn_fps_sho_coach",
		"wpn_fps_gre_m32",
		"wpn_fps_gre_china",
		"wpn_fps_gre_arbiter",
		"wpn_fps_gre_ray",
		"wpn_fps_gre_slap"
		--[["wpn_fps_bow_plainsrider",
		"wpn_fps_bow_hunter",
		"wpn_fps_bow_arblast",
		"wpn_fps_bow_frankish",
		"wpn_fps_bow_long",
		"wpn_fps_bow_ecp",
		"wpn_fps_bow_elastic"--]]
	}

	for _, factory_id in ipairs(weapons) do
		if self[factory_id] and self[factory_id].uses_parts then
			table.insert(self[factory_id].uses_parts, "wpn_fps_upg_a_slug")
			table.insert(self[factory_id .. "_npc"].uses_parts, "wpn_fps_upg_a_slug")
			table.insert(self[factory_id].uses_parts, "wpn_fps_upg_a_custom")
			table.insert(self[factory_id .. "_npc"].uses_parts, "wpn_fps_upg_a_custom")
			table.insert(self[factory_id].uses_parts, "wpn_fps_upg_a_explosive")
			table.insert(self[factory_id .. "_npc"].uses_parts, "wpn_fps_upg_a_explosive")
			table.insert(self[factory_id].uses_parts, "wpn_fps_upg_a_piercing")
			table.insert(self[factory_id .. "_npc"].uses_parts, "wpn_fps_upg_a_piercing")
			table.insert(self[factory_id].uses_parts, "wpn_fps_upg_a_dragons_breath")
			table.insert(self[factory_id .. "_npc"].uses_parts, "wpn_fps_upg_a_dragons_breath")
		end
	end
end




