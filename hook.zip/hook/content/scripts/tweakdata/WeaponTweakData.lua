--https://github.com/mwSora/payday-2-luajit/blob/master/pd2-lua/lib/tweak_data/weapontweakdata.lua

local old_init = WeaponTweakData.init
function WeaponTweakData:init(tweak_data)
    old_init(self, tweak_data)
	-- grimm
	self.basset.stats.damage = 220
	self.basset.can_shoot_through_enemy = true
	self.basset.can_shoot_through_shield = true
	self.basset.can_shoot_through_wall = true
	self.basset.CLIP_AMMO_MAX = 37
	self.basset.NR_CLIPS_MAX = 37
	self.basset.stats_modifiers = {damage = 2}
	self.basset.stats.recoil = 18 --stability higher=better
	self.basset.AMMO_PICKUP = {200,300}
	self.basset.stats.zoom = 5
	self.basset.panic_suppression_chance = 0
	self.basset.stats.alert_size = 50
	self.basset.FIRE_MODE = "auto"
	self.basset.auto = {fire_rate = 0.2}
	self.basset.single = {fire_rate = 0.1}
	self.basset.fire_mode_data = {fire_rate = 0.15}
	self.basset.CAN_TOGGLE_FIREMODE = true
	
	-- mini vulcan gun
	self.shuno.stats.damage = 80
	self.shuno.can_shoot_through_enemy = true
	self.shuno.can_shoot_through_shield = true
	self.shuno.can_shoot_through_wall = false
	self.shuno.stats_modifiers = {damage = 1}
	--self.shuno.AMMO_PICKUP = self:_pickup_chance(self.shuno.AMMO_MAX, 1000)
	self.shuno.AMMO_PICKUP = {250,500}
	self.shuno.stats.spread = 18 --accuracy higher=better
	self.shuno.stats.recoil = 18 --stability higher=better
	--self.shuno.stats.spread_moving = 50 --delay on bullets?
	self.shuno.stats.suppression = 0
	self.shuno.stats.alert_size = 50
	self.shuno.stats.reload = 0.7
	self.shuno.timers.reload_not_empty = 0.7
	self.shuno.timers.reload_empty = 0.7
	
	-- baby deagle
	self.sparrow.stats.damage = 380
	self.sparrow.can_shoot_through_enemy = false
	self.sparrow.can_shoot_through_shield = true
	self.sparrow.can_shoot_through_wall = false
	self.sparrow.stats.spread = 30 --accuracy higher=better
	self.sparrow.stats.recoil = 30 --stability higher=better
	self.sparrow.stats.zoom = 6
	self.sparrow.stats.alert_size = 100
	self.sparrow.AMMO_PICKUP = {200,300}
	self.sparrow.panic_suppression_chance = 0
	self.sparrow.suppression = 0
	
	-- grom sniper
	self.siltstone.stats.damage = 320
	self.siltstone.can_shoot_through_enemy = true
	self.siltstone.can_shoot_through_shield = true
	self.siltstone.can_shoot_through_wall = true
	self.siltstone.stats.spread = 30 --accuracy higher=better
	self.siltstone.stats.recoil = 30 --stability higher=better
	self.siltstone.stats.zoom = 20
	self.siltstone.panic_suppression_chance = 0
	self.siltstone.stats.alert_size = 100
	self.siltstone.stats_modifiers = {damage = 2}
	self.siltstone.FIRE_MODE = "single"
	self.siltstone.fire_mode_data = {fire_rate = 0.2}
	self.siltstone.shake = {fire_multiplier = 0.0, fire_steelsight_multiplier = -0.0}
	self.siltstone.kick.standing = {0,0.0,-0.0,0.0}
	self.siltstone.kick.crouching = self.siltstone.kick.standing
	self.siltstone.kick.steelsight = self.siltstone.kick.standing
	self.siltstone.crosshair.steelsight.offset = 0
	self.siltstone.crosshair.steelsight.moving_offset = 0
	self.siltstone.crosshair.steelsight.kick_offset = 0.14
	self.siltstone.BURST_FIRE = 4
	
	-- contractor tti
	self.tti.stats.damage = 160
	self.tti.can_shoot_through_enemy = true
	self.tti.can_shoot_through_shield = true
	self.tti.can_shoot_through_wall = true
	self.tti.stats.spread = 30 --accuracy higher=better
	self.tti.stats.recoil = 30 --stability higher=better
	self.tti.stats.zoom = 20
	self.tti.panic_suppression_chance = 0
	self.tti.stats.alert_size = 100
	self.tti.AMMO_PICKUP = {25,35}
	self.tti.stats_modifiers = {damage = 2}
	self.tti.shake = {fire_multiplier = 0.0, fire_steelsight_multiplier = -0.0}
	self.tti.kick.standing = {0,0.0,-0.0,0.0}
	self.tti.kick.crouching = self.tti.kick.standing
	self.tti.kick.steelsight = self.tti.kick.standing
	self.tti.crosshair.steelsight.offset = 0
	self.tti.crosshair.steelsight.moving_offset = 0
	self.tti.crosshair.steelsight.kick_offset = 0.14
	self.tti.single = {fire_rate = 0.3}
	self.tti.fire_mode_data = {fire_rate = 0.1}
	self.tti.BURST_FIRE = 4
	
	-- Joceline O/U 12G b682
	self.b682.CLIP_AMMO_MAX = 28
	self.b682.NR_CLIPS_MAX = 4
	self.b682.AMMO_MAX = self.b682.CLIP_AMMO_MAX * self.b682.NR_CLIPS_MAX
	self.b682.stats.total_ammo_mod = 42
	self.b682.stats.damage = 288
	self.b682.can_shoot_through_enemy = true
	self.b682.can_shoot_through_shield = true
	self.b682.stats.recoil = 16
	self.b682.FIRE_MODE = "single"
	self.b682.auto = {fire_rate = 0.4}
	self.b682.single = {fire_rate = 0.1}
	self.b682.fire_mode_data = {fire_rate = 0.1}
	self.b682.CAN_TOGGLE_FIREMODE = true
	self.b682.AMMO_PICKUP = {100,200}
	self.b682.stats.zoom = 6
	self.b682.stats.alert_size = 100
	
	-- Mosconi 12G
	self.huntsman.CLIP_AMMO_MAX = 10
	self.huntsman.NR_CLIPS_MAX = 3
	self.huntsman.AMMO_MAX = self.huntsman.CLIP_AMMO_MAX * self.huntsman.NR_CLIPS_MAX
	self.huntsman.stats.total_ammo_mod = 42
	self.huntsman.stats.damage = 288
	self.huntsman.can_shoot_through_enemy = true
	self.huntsman.can_shoot_through_shield = true
	self.huntsman.FIRE_MODE = "single"
	self.huntsman.auto = {fire_rate = 0.4}
	self.huntsman.single = {fire_rate = 0.1}
	self.huntsman.fire_mode_data = {fire_rate = 0.1}
	self.huntsman.CAN_TOGGLE_FIREMODE = true
	self.huntsman.AMMO_PICKUP = {30,40}
	self.huntsman.stats.zoom = 6
	
	-- Thanatos .50 cal
	self.m95.stats.damage = 5200
	self.m95.can_shoot_through_enemy = true
	self.m95.can_shoot_through_shield = true
	self.m95.can_shoot_through_wall = true
	self.m95.stats.spread = 30 --accuracy higher=better
	self.m95.stats.recoil = 30 --stability higher=better
	self.m95.stats.zoom = 6
	self.m95.stats.suppression = 0
	self.m95.stats.alert_size = 100
	self.m95.AMMO_PICKUP = {20,30}
	self.m95.CLIP_AMMO_MAX = 10
	self.m95.NR_CLIPS_MAX = 23
	self.m95.FIRE_MODE = "single"
	self.m95.fire_mode_data = {fire_rate = 0.2} -- single fire
	self.m95.AMMO_MAX = self.m95.CLIP_AMMO_MAX * self.m95.NR_CLIPS_MAX
	self.m95.auto = {fire_rate = 0.7}
	self.m95.shake = {fire_multiplier = 0.0, fire_steelsight_multiplier = -0.0}
	self.m95.BURST_FIRE = 6
	
	-- Flamethrower Mk. 17
	self.system.stats.damage = 55
	self.system.stats.recoil = 30
	self.system.stats.spread = 100
	self.system.stats.zoom = 6
	self.system.stats.reload = 13
	self.system.stats.suppression = 0
	self.system.stats.alert_size = 100
	self.system.AMMO_PICKUP = {1000,2000}
	self.system.FIRE_MODE = "auto"
	self.system.fire_mode_data = {fire_rate = 0.001} -- single fire
	self.system.auto = {fire_rate = 0.001}
	self.system.CAN_TOGGLE_FIREMODE = true
	self.system.flame_max_range = 8000
	self.system.fire_dot_data.dot_trigger_chance = 100 --100% turn fire on
	self.system.fire_dot_data.dot_trigger_max_distance = 8000 --distance of ft
	self.system.fire_dot_data.dot_damage = 8 --fire dmg
	self.system.fire_dot_data.dot_tick_period = 0.1 --how fast fire takes dmg
	self.system.fire_dot_data.dot_length = 30.0	--how long fire last
	self.system.timers.reload_not_empty = 5.3
	self.system.timers.reload_empty = 5.3
	
	-- Flamethrower Mk. 1
	self.flamethrower_mk2.stats.damage = 55
	self.flamethrower_mk2.stats.spread = 100
	self.flamethrower_mk2.stats.recoil = 30
	self.flamethrower_mk2.stats.zoom = 6
	self.flamethrower_mk2.stats.reload = 13
	self.flamethrower_mk2.stats.suppression = 0
	self.flamethrower_mk2.stats.alert_size = 100
	self.flamethrower_mk2.AMMO_PICKUP = {1000,2000}
	self.flamethrower_mk2.FIRE_MODE = "auto"
	self.flamethrower_mk2.fire_mode_data = {fire_rate = 0.001} -- single fire
	self.flamethrower_mk2.auto = {fire_rate = 0.001}
	self.flamethrower_mk2.CAN_TOGGLE_FIREMODE = true
	self.flamethrower_mk2.flame_max_range = 8000
	self.flamethrower_mk2.fire_dot_data.dot_trigger_chance = 100 --100% turn fire on
	self.flamethrower_mk2.fire_dot_data.dot_trigger_max_distance = 8000 --distance of ft
	self.flamethrower_mk2.fire_dot_data.dot_damage = 8 --fire dmg 1 is 10dmg
	self.flamethrower_mk2.fire_dot_data.dot_tick_period = 0.1 --how fast fire takes dmg
	self.flamethrower_mk2.fire_dot_data.dot_length = 30.0	--how long fire last
	self.flamethrower_mk2.timers.reload_not_empty = 6.3
	self.flamethrower_mk2.timers.reload_empty = 5.3
	
	--GSPS 12G m37
	self.m37.CLIP_AMMO_MAX = 10
	self.m37.NR_CLIPS_MAX = 4
	self.m37.AMMO_MAX = self.m37.CLIP_AMMO_MAX * self.m37.NR_CLIPS_MAX
	self.m37.stats.total_ammo_mod = 42
	self.m37.stats.damage = 288
	self.m37.can_shoot_through_enemy = true
	self.m37.can_shoot_through_shield = true
	self.m37.stats.recoil = 16
	--self.m37.FIRE_MODE = "single"
	self.m37.single = {fire_rate = 0.25}
	self.m37.fire_mode_data = {fire_rate = 0.25}
	--self.m37.CAN_TOGGLE_FIREMODE = true
	self.m37.AMMO_PICKUP = {30,40}
	self.m37.stats.zoom = 6
	self.m37.stats.alert_size = 1
	self.m37.BURST_FIRE = 5
	
	--claire 12g coach
	self.coach.CLIP_AMMO_MAX = 10
	self.coach.NR_CLIPS_MAX = 3
	self.coach.AMMO_MAX = self.coach.CLIP_AMMO_MAX * self.coach.NR_CLIPS_MAX
	self.coach.stats.total_ammo_mod = 42
	self.coach.stats.damage = 288
	self.coach.can_shoot_through_enemy = true
	self.coach.can_shoot_through_shield = true
	self.coach.stats.recoil = 16
	self.coach.FIRE_MODE = "single"
	self.coach.auto = {fire_rate = 0.4}
	self.coach.single = {fire_rate = 0.1}
	self.coach.fire_mode_data = {fire_rate = 0.1}
	self.coach.CAN_TOGGLE_FIREMODE = true
	self.coach.AMMO_PICKUP = {30,40}
	self.coach.stats.zoom = 6
	self.coach.stats.alert_size = 100
	self.coach.timers.reload_not_empty = 1.0
	self.coach.timers.reload_empty = 3.5
	
	--Pistol Crossbow hunter
	self.hunter.stats.damage = 200
	self.hunter.CLIP_AMMO_MAX = 20
	self.hunter.NR_CLIPS_MAX = 100
	self.hunter.AMMO_MAX = self.hunter.NR_CLIPS_MAX
	self.hunter.AMMO_PICKUP = {50,100}
	self.hunter.stats.spread = 50 --accuracy higher=better
	self.hunter.stats.recoil = 60 --stability higher=better
	self.hunter.stats.zoom = 6
	self.hunter.stats.alert_size = 50
	self.hunter.stats.reload = 0.5
	self.hunter.FIRE_MODE = "auto"
	self.hunter.auto = {fire_rate = 0.2}
	self.hunter.single = {fire_rate = 0.2}
	self.hunter.fire_mode_data = {fire_rate = 0.2}
	self.hunter.CAN_TOGGLE_FIREMODE = true
	
	--heavy crossbow
	self.arblast.stats.damage = 10000
	self.arblast.AMMO_PICKUP = {2,10}
	self.arblast.stats.zoom = 6
	self.arblast.stats.alert_size = 50
	self.arblast.stats.reload = 0.5
	self.arblast.FIRE_MODE = "auto"
	self.arblast.single = {fire_rate = 0.2}
	self.arblast.fire_mode_data = {fire_rate = 0.2}
	
	--Airbow ecp
	self.ecp.stats.damage = 200
	self.ecp.CLIP_AMMO_MAX = 30
	self.ecp.NR_CLIPS_MAX = 60
	self.ecp.stats_modifiers = {damage = 50}
	self.ecp.AMMO_PICKUP = {1000,2000}
	self.ecp.stats.spread = 50 --accuracy higher=better
	self.ecp.stats.recoil = 60 --stability higher=better
	self.ecp.stats.zoom = 6
	self.ecp.stats.alert_size = 50
	self.ecp.stats.reload = 0.5
	self.ecp.FIRE_MODE = "auto"
	self.ecp.auto = {fire_rate = 0.2}
	self.ecp.single = {fire_rate = 0.2}
	self.ecp.fire_mode_data = {fire_rate = 0.2}
	self.ecp.CAN_TOGGLE_FIREMODE = true
	self.ecp.timers.reload_not_empty = 0.2
	self.ecp.timers.reload_empty = 0.2
	
	--plainstrider
	self.plainsrider.stats.suppression = 0
	self.plainsrider.stats.spread = 100 --accuracy higher=better
	self.plainsrider.stats.recoil = 100 --stability higher=better
	self.plainsrider.CLIP_AMMO_MAX = 30
	self.plainsrider.NR_CLIPS_MAX = 60
	self.plainsrider.charge_data = {max_t = 0.01}
	self.plainsrider.bow_reload_speed_multiplier = 3
	self.plainsrider.FIRE_MODE = "single"
	self.plainsrider.auto = {fire_rate = 0.4}
	self.plainsrider.single = {fire_rate = 0.1}
	self.plainsrider.fire_mode_data = {fire_rate = 0.1}
	self.plainsrider.CAN_TOGGLE_FIREMODE = false
	self.plainsrider.timers.reload_not_empty = 0.2
	self.plainsrider.timers.reload_empty = 0.2
	self.plainsrider.stats.zoom = 7
	
	--deca
	self.elastic.stats.suppression = 0
	self.elastic.stats.spread = 100 --accuracy higher=better
	self.elastic.stats.recoil = 100 --stability higher=better
	self.elastic.CLIP_AMMO_MAX = 30
	self.elastic.NR_CLIPS_MAX = 60
	self.elastic.charge_data = {max_t = 0.01}
	self.elastic.bow_reload_speed_multiplier = 3
	self.elastic.FIRE_MODE = "single"
	self.elastic.auto = {fire_rate = 0.4}
	self.elastic.single = {fire_rate = 0.1}
	self.elastic.fire_mode_data = {fire_rate = 0.1}
	self.elastic.CAN_TOGGLE_FIREMODE = false
	self.elastic.timers.reload_not_empty = 0.2
	self.elastic.timers.reload_empty = 0.2
	self.elastic.stats.zoom = 7
	
	--interceptor
	self.usp.stats.damage = 300
	self.usp.can_shoot_through_enemy = false
	self.usp.can_shoot_through_shield = true
	self.usp.can_shoot_through_wall = false
	self.usp.stats.spread = 200
	self.usp.stats.recoil = 200
	self.usp.stats.zoom = 6
	self.usp.stats.alert_size = 100
	self.usp.CLIP_AMMO_MAX = 17
	self.usp.NR_CLIPS_MAX = 45
	self.usp.FIRE_MODE = "single" -- start with using single/auto depends if the gun is auto/single
	self.usp.auto = {fire_rate = 0.2}
	self.usp.single = {fire_rate = 0.1}
	self.usp.fire_mode_data = {fire_rate = 0.1}
	self.usp.CAN_TOGGLE_FIREMODE = true
	self.usp.AMMO_PICKUP = {100,200}
	
	--stryke pistol glock_18c
	self.glock_18c.stats.damage = 300
	self.glock_18c.can_shoot_through_enemy = false
	self.glock_18c.can_shoot_through_shield = true
	self.glock_18c.can_shoot_through_wall = false
	self.glock_18c.stats.spread = 100 --accuracy higher=better
	self.glock_18c.stats.recoil = 100 --stability higher=better
	self.glock_18c.stats.zoom = 6
	self.glock_18c.suppression = 0
	self.glock_18c.stats.alert_size = 100
	self.glock_18c.CLIP_AMMO_MAX = 65
	self.glock_18c.NR_CLIPS_MAX = 167
	self.glock_18c.FIRE_MODE = "auto"
	self.glock_18c.auto = {fire_rate = 0.4}
	self.glock_18c.single = {fire_rate = 0.1}
	self.glock_18c.fire_mode_data = {fire_rate = 0.1}
	self.glock_18c.CAN_TOGGLE_FIREMODE = true
	self.glock_18c.AMMO_PICKUP = {200,300}
	self.glock_18c.panic_suppression_chance = 0
	
	-- akimbo STRYKE x_g18c 
	self.x_g18c.CLIP_AMMO_MAX = 160
	self.x_g18c.NR_CLIPS_MAX = 4
	self.x_g18c.AMMO_MAX = self.x_g18c.CLIP_AMMO_MAX * self.x_g18c.NR_CLIPS_MAX
	self.x_g18c.stats.total_ammo_mod = 63
	self.x_g18c.stats.damage = 500
	self.x_g18c.can_shoot_through_enemy = true
	self.x_g18c.can_shoot_through_shield = true
	self.x_g18c.stats.spread = 100 --accuracy higher=better
	self.x_g18c.stats.recoil = 100 --stability higher=better
	self.x_g18c.stats.zoom = 6
	self.x_g18c.stats.suppression = 0
	self.x_g18c.stats.alert_size = 100
	self.x_g18c.FIRE_MODE = "auto"
	self.x_g18c.auto = {fire_rate = 0.4}
	self.x_g18c.single = {fire_rate = 0.1}
	self.x_g18c.fire_mode_data = {fire_rate = 0.1}
	self.x_g18c.CAN_TOGGLE_FIREMODE = true
	self.x_g18c.AMMO_PICKUP = {200,300}
	
	-- shotgun12g boot
	self.boot.CLIP_AMMO_MAX = 28
	self.boot.NR_CLIPS_MAX = 6
	self.boot.AMMO_MAX = self.boot.CLIP_AMMO_MAX * self.boot.NR_CLIPS_MAX
	self.boot.stats.total_ammo_mod = 42
	self.boot.stats.damage = 288
	self.boot.can_shoot_through_enemy = true
	self.boot.can_shoot_through_shield = true
	self.boot.stats.recoil = 16
	self.boot.FIRE_MODE = "single"
	self.boot.auto = {fire_rate = 0.4}
	self.boot.single = {fire_rate = 0.1}
	self.boot.fire_mode_data = {fire_rate = 0.1}
	self.boot.CAN_TOGGLE_FIREMODE = true
	self.boot.AMMO_PICKUP = {2000,3000}
	self.boot.stats.zoom = 6
	self.boot.stats.alert_size = 1
	
	--bronco 44 revolver new_raging_bull
	self.new_raging_bull.CLIP_AMMO_MAX = 24
	self.new_raging_bull.NR_CLIPS_MAX = 2
	self.new_raging_bull.AMMO_MAX = self.new_raging_bull.CLIP_AMMO_MAX * self.new_raging_bull.NR_CLIPS_MAX
	self.new_raging_bull.stats.damage = 350
	self.new_raging_bull.can_shoot_through_wall = true
	self.new_raging_bull.can_shoot_through_enemy = true
	self.new_raging_bull.can_shoot_through_shield = true
	self.new_raging_bull.stats.spread = 100 --accuracy higher=better
	self.new_raging_bull.stats.recoil = 15
	self.new_raging_bull.stats.suppression = 0
	self.new_raging_bull.panic_suppression_chance = 1.0
	self.new_raging_bull.stats.alert_size = 100
	self.new_raging_bull.FIRE_MODE = "single"
	self.new_raging_bull.single = {fire_rate = 0.3}
	self.new_raging_bull.fire_mode_data = {fire_rate = 0.1}
	self.new_raging_bull.stats.zoom = 6
	self.new_raging_bull.timers = {
		reload_not_empty = 1.25,
		reload_empty = 1.25,
		unequip = 0.5,
		equip = 0.45
	}
	self.new_raging_bull.BURST_FIRE = 4
	
	--akimbo bronco x_rage
	self.x_rage.CLIP_AMMO_MAX = 24
	self.x_rage.NR_CLIPS_MAX = 4
	self.x_rage.AMMO_MAX = self.x_rage.CLIP_AMMO_MAX * self.x_rage.NR_CLIPS_MAX
	self.x_rage.stats.damage = 350
	self.x_rage.can_shoot_through_wall = true
	self.x_rage.can_shoot_through_enemy = true
	self.x_rage.can_shoot_through_shield = true
	self.x_rage.stats.spread = 100 --accuracy higher=better
	self.x_rage.stats.recoil = 15
	self.x_rage.stats.suppression = 0
	self.x_rage.panic_suppression_chance = 1.0
	self.x_rage.stats.alert_size = 100
	self.x_rage.FIRE_MODE = "single"
	self.x_rage.single = {fire_rate = 0.3}
	self.x_rage.fire_mode_data = {fire_rate = 0.1}
	self.x_rage.stats.zoom = 6
	self.x_rage.timers = {
		reload_not_empty = 1.585,
		reload_empty = 2,
		unequip = 0.5,
		equip = 0.5
	}
	
	--peacemaker 45 peacemaker
	self.peacemaker.CLIP_AMMO_MAX = 18
	self.peacemaker.NR_CLIPS_MAX = 2
	self.peacemaker.AMMO_MAX = self.peacemaker.CLIP_AMMO_MAX * self.peacemaker.NR_CLIPS_MAX
	self.peacemaker.stats.damage = 350
	self.peacemaker.can_shoot_through_wall = true
	self.peacemaker.can_shoot_through_enemy = true
	self.peacemaker.can_shoot_through_shield = true
	self.peacemaker.stats.spread = 100 --accuracy higher=better
	self.peacemaker.stats.recoil = 15
	self.peacemaker.stats.suppression = 0
	self.peacemaker.panic_suppression_chance = 1.0
	self.peacemaker.stats.alert_size = 100
	self.peacemaker.single = {fire_rate = 0.3}
	self.peacemaker.fire_mode_data = {fire_rate = 0.2}
	self.peacemaker.stats.zoom = 6
	self.peacemaker.stats.reload = 21
	self.peacemaker.timers = {
		shotgun_reload_enter = 1.0333333333333333,
		shotgun_reload_exit_empty = 0.2333333333333333,
		shotgun_reload_exit_not_empty = 0.2333333333333333,
		shotgun_reload_shell = 0.7,
		shotgun_reload_first_shell_offset = 0,
		unequip = 0.65,
		equip = 0.65
	}
	self.peacemaker.stats_modifiers = {damage = 9}
	self.peacemaker.BURST_FIRE = 8
	
	--broomstick c96
	self.c96.CLIP_AMMO_MAX = 20
	self.c96.NR_CLIPS_MAX = 5
	self.c96.AMMO_MAX = self.c96.CLIP_AMMO_MAX * self.c96.NR_CLIPS_MAX
	self.c96.stats.damage = 70
	self.c96.can_shoot_through_enemy = true
	self.c96.can_shoot_through_shield = true
	self.c96.single = {fire_rate = 0.12}
	self.c96.fire_mode_data = {fire_rate = 0.12}
	self.c96.stats.spread = 100 --accuracy higher=better
	self.c96.stats.zoom = 6
	self.c96.panic_suppression_chance = 0
	self.c96.stats.alert_size = 100
	self.c96.timers = {
		reload_not_empty = 1.7,
		reload_empty = 2.17,
		unequip = 0.5,
		equip = 0.35
	}
	self.c96.BURST_FIRE = 6
	
	--broomstick x_c96
	self.x_c96.CLIP_AMMO_MAX = 20
	self.x_c96.NR_CLIPS_MAX = 10
	self.x_c96.AMMO_MAX = self.x_c96.CLIP_AMMO_MAX * self.x_c96.NR_CLIPS_MAX
	self.x_c96.stats.damage = 70
	self.x_c96.can_shoot_through_enemy = true
	self.x_c96.can_shoot_through_shield = true
	self.x_c96.single = {fire_rate = 0.12}
	self.x_c96.fire_mode_data = {fire_rate = 0.12}
	self.x_c96.stats.spread = 100 --accuracy higher=better
	self.x_c96.stats.recoil = 100
	self.x_c96.stats.zoom = 6
	self.x_c96.stats.alert_size = 100
	self.x_c96.panic_suppression_chance = 0
	self.x_c96.timers = {
		reload_not_empty = 2.23,
		reload_empty = 2.8,
		unequip = 0.5,
		equip = 0.5
	}
	
	--parabellum breech
	self.breech.CLIP_AMMO_MAX = 20
	self.breech.NR_CLIPS_MAX = 6
	self.breech.AMMO_MAX = self.breech.CLIP_AMMO_MAX * self.breech.NR_CLIPS_MAX
	self.breech.can_shoot_through_enemy = true
	self.breech.can_shoot_through_shield = true
	self.breech.stats.suppression = 0
	self.breech.panic_suppression_chance = 1.0
	self.breech.stats.alert_size = 100
	self.breech.single = {fire_rate = 0.12}
	self.breech.fire_mode_data = {fire_rate = 0.12}
	self.breech.stats.spread = 100 --accuracy higher=better
	self.breech.stats.zoom = 6
	self.breech.timers = {
		reload_not_empty = 1.33,
		reload_empty = 2.1,
		unequip = 0.5,
		equip = 0.35
	}
	self.breech.BURST_FIRE = 6
	
	--akimbo parabellum x_breech
	self.x_breech.CLIP_AMMO_MAX = 20
	self.x_breech.NR_CLIPS_MAX = 12
	self.x_breech.AMMO_MAX = self.x_breech.CLIP_AMMO_MAX * self.x_breech.NR_CLIPS_MAX
	self.x_breech.can_shoot_through_enemy = true
	self.x_breech.can_shoot_through_shield = true
	self.x_breech.stats.suppression = 0
	self.x_breech.panic_suppression_chance = 1.0
	self.x_breech.stats.alert_size = 100
	self.x_breech.single = {fire_rate = 0.12}
	self.x_breech.fire_mode_data = {fire_rate = 0.12}
	self.x_breech.stats.spread = 100 --accuracy higher=better
	self.x_breech.stats.recoil = 16
	self.x_breech.stats.zoom = 6
	self.x_breech.timers = {
		reload_not_empty = 2.13,
		reload_empty = 2.7,
		unequip = 0.5,
		equip = 0.5
	}
	
	--matever mateba
	self.mateba.CLIP_AMMO_MAX = 12
	self.mateba.NR_CLIPS_MAX = 3
	self.mateba.AMMO_MAX = self.mateba.CLIP_AMMO_MAX * self.mateba.NR_CLIPS_MAX
	self.mateba.can_shoot_through_enemy = true
	self.mateba.can_shoot_through_shield = true
	self.mateba.stats.spread = 100 --accuracy higher=better
	self.mateba.stats.recoil = 100
	self.mateba.stats.zoom = 6
	self.mateba.stats.suppression = 0
	self.mateba.panic_suppression_chance = 1.0
	self.mateba.stats.alert_size = 100
	self.mateba.BURST_FIRE = 4
	
	--matever mateba
	self.x_2006m.CLIP_AMMO_MAX = 12
	self.x_2006m.NR_CLIPS_MAX = 6
	self.x_2006m.AMMO_MAX = self.x_2006m.CLIP_AMMO_MAX * self.x_2006m.NR_CLIPS_MAX
	self.x_2006m.can_shoot_through_enemy = true
	self.x_2006m.can_shoot_through_shield = true
	self.x_2006m.stats.spread = 100 --accuracy higher=better
	self.x_2006m.stats.recoil = 100
	self.x_2006m.stats.zoom = 6
	self.x_2006m.stats.suppression = 0
	self.x_2006m.panic_suppression_chance = 1.0
	self.x_2006m.stats.alert_size = 100
	
	--castigo chinchilla
	self.chinchilla.CLIP_AMMO_MAX = 24
	self.chinchilla.NR_CLIPS_MAX = 3
	self.chinchilla.AMMO_MAX = self.chinchilla.CLIP_AMMO_MAX * self.chinchilla.NR_CLIPS_MAX
	self.chinchilla.stats.damage = 360
	self.chinchilla.stats_modifiers = {damage = 1.4}
	self.chinchilla.can_shoot_through_enemy = true
	self.chinchilla.can_shoot_through_shield = true
	self.chinchilla.can_shoot_through_wall = true
	self.chinchilla.stats.spread = 30 --accuracy higher=better
	self.chinchilla.stats.recoil = 25
	self.chinchilla.single = {fire_rate = 0.3}
	self.chinchilla.fire_mode_data = {fire_rate = 0.1}
	self.chinchilla.CAN_TOGGLE_FIREMODE = true
	self.chinchilla.stats.zoom = 6
	self.chinchilla.stats.suppression = 0
	self.chinchilla.panic_suppression_chance = 1.0
	self.chinchilla.stats.alert_size = 100
	self.chinchilla.timers = {
		reload_not_empty = 1.17,
		reload_empty = 1.17,
		unequip = 0.5,
		equip = 0.45
	}
	self.chinchilla.BURST_FIRE = 4
	
	--akimbo castigo x_chinchilla
	self.x_chinchilla.CLIP_AMMO_MAX = 24
	self.x_chinchilla.NR_CLIPS_MAX = 6
	self.x_chinchilla.AMMO_MAX = self.x_chinchilla.CLIP_AMMO_MAX * self.x_chinchilla.NR_CLIPS_MAX
	self.x_chinchilla.stats.damage = 360
	self.x_chinchilla.stats_modifiers = {damage = 1.4}
	self.x_chinchilla.can_shoot_through_enemy = true
	self.x_chinchilla.can_shoot_through_shield = true
	self.x_chinchilla.can_shoot_through_wall = true
	self.x_chinchilla.stats.spread = 40 --accuracy higher=better
	self.x_chinchilla.stats.recoil = 35
	self.x_chinchilla.single = {fire_rate = 0.1}
	self.x_chinchilla.fire_mode_data = {fire_rate = 0.1}
	self.x_chinchilla.stats.zoom = 6
	self.x_chinchilla.stats.suppression = 0
	self.x_chinchilla.panic_suppression_chance = 1.0
	self.x_chinchilla.stats.alert_size = 100
	self.x_chinchilla.timers = {
		reload_not_empty = 1.87,
		reload_empty = 1.87,
		unequip = 0.5,
		equip = 0.5
	}
	
	-- akimbo deagle x_deagle
	self.x_deagle.CLIP_AMMO_MAX = 90
	self.x_deagle.NR_CLIPS_MAX = 5
	self.x_deagle.AMMO_MAX = self.x_deagle.CLIP_AMMO_MAX * self.x_deagle.NR_CLIPS_MAX
	self.x_deagle.stats.total_ammo_mod = 63
	self.x_deagle.stats.damage = 300
	self.x_deagle.can_shoot_through_enemy = true
	self.x_deagle.can_shoot_through_shield = true
	self.x_deagle.can_shoot_through_wall = true
	self.x_deagle.stats.spread = 100 --accuracy higher=better
	self.x_deagle.stats.zoom = 6
	self.x_deagle.stats.alert_size = 100
	self.x_deagle.FIRE_MODE = "single"
	self.x_deagle.auto = {fire_rate = 0.4}
	self.x_deagle.single = {fire_rate = 0.1}
	self.x_deagle.fire_mode_data = {fire_rate = 0.1}
	self.x_deagle.CAN_TOGGLE_FIREMODE = true
	self.x_deagle.AMMO_PICKUP = {200,300}
	
	--china piglet granade
	self.china.CLIP_AMMO_MAX = 40
	self.china.NR_CLIPS_MAX = 1
	self.china.AMMO_MAX = self.china.CLIP_AMMO_MAX * self.china.NR_CLIPS_MAX
	self.china.stats.damage = 192
	self.china.stats.spread = 100 --accuracy higher=better
	self.china.stats.recoil = 100 --stability higher=better
	self.china.stats.zoom = 6
	self.china.stats.alert_size = 100
	self.china.FIRE_MODE = "single"
	self.china.auto = {fire_rate = 0.4}
	self.china.single = {fire_rate = 0.1}
	self.china.fire_mode_data = {fire_rate = 0.1}
	self.china.CAN_TOGGLE_FIREMODE = true
	self.china.AMMO_PICKUP = {200,300}
	
	--gre_m79 granade
	self.gre_m79.CLIP_AMMO_MAX = 20
	self.gre_m79.NR_CLIPS_MAX = 2
	self.gre_m79.AMMO_MAX = self.gre_m79.CLIP_AMMO_MAX * self.gre_m79.NR_CLIPS_MAX
	self.gre_m79.stats.total_ammo_mod = 63
	self.gre_m79.stats.damage = 192
	self.gre_m79.stats.spread = 100 --accuracy higher=better
	self.gre_m79.stats.recoil = 100 --stability higher=better
	self.gre_m79.stats.zoom = 6
	self.gre_m79.stats.alert_size = 100
	self.gre_m79.FIRE_MODE = "single"
	self.gre_m79.auto = {fire_rate = 0.4}
	self.gre_m79.single = {fire_rate = 0.1}
	self.gre_m79.fire_mode_data = {fire_rate = 0.1}
	self.gre_m79.CAN_TOGGLE_FIREMODE = true
	self.gre_m79.AMMO_PICKUP = {200,300}

	--arbiter granade
	self.arbiter.CLIP_AMMO_MAX = 20
	self.arbiter.NR_CLIPS_MAX = 2
	self.arbiter.AMMO_MAX = self.arbiter.CLIP_AMMO_MAX * self.arbiter.NR_CLIPS_MAX
	self.arbiter.stats.total_ammo_mod = 63
	self.arbiter.stats.damage = 686
	self.arbiter.DAMAGE = 686
	self.arbiter.stats.spread = 100 --accuracy higher=better
	self.arbiter.stats.recoil = 100 --stability higher=better
	self.arbiter.stats.zoom = 6
	self.arbiter.stats.alert_size = 100
	self.arbiter.FIRE_MODE = "single"
	self.arbiter.auto = {fire_rate = 0.4}
	self.arbiter.single = {fire_rate = 0.1}
	self.arbiter.fire_mode_data = {fire_rate = 0.1}
	self.arbiter.CAN_TOGGLE_FIREMODE = true
	self.arbiter.AMMO_PICKUP = {200,300}
	
	--slap compact granade
	self.slap.CLIP_AMMO_MAX = 20
	self.slap.NR_CLIPS_MAX = 3
	self.slap.AMMO_MAX = self.slap.CLIP_AMMO_MAX * self.slap.NR_CLIPS_MAX
	self.slap.stats.total_ammo_mod = 63
	self.slap.stats.damage = 192
	self.slap.stats.spread = 100 --accuracy higher=better
	self.slap.stats.recoil = 100 --stability higher=better
	self.slap.stats.zoom = 6
	self.slap.stats.alert_size = 100
	self.slap.FIRE_MODE = "single"
	self.slap.auto = {fire_rate = 0.4}
	self.slap.single = {fire_rate = 0.1}
	self.slap.fire_mode_data = {fire_rate = 0.1}
	self.slap.CAN_TOGGLE_FIREMODE = true
	self.slap.AMMO_PICKUP = {200,300}
	
	--piglet granade lanucher m32 
	self.m32.damage = 692
	self.m32.CLIP_AMMO_MAX = 12
	self.m32.NR_CLIPS_MAX = 3
	self.m32.AMMO_MAX = self.m32.CLIP_AMMO_MAX * self.m32.NR_CLIPS_MAX
	self.m32.stats.spread = 100 --accuracy higher=better
	self.m32.stats.recoil = 100 --stability higher=better
	self.m32.stats.zoom = 6
	self.m32.stats.reload = 14
	self.m32.stats.alert_size = 100
	self.m32.AMMO_PICKUP = {200,300}
	self.m32.FIRE_MODE = "single"
	self.m32.fire_mode_data = {fire_rate = 0.001} -- single fire
	self.m32.auto = {fire_rate = 0.1}
	self.m32.CAN_TOGGLE_FIREMODE = true
	self.m32.timers.shotgun_reload_enter = 0.96
	self.m32.timers.shotgun_reload_exit_empty = 0.33
	self.m32.timers.shotgun_reload_exit_not_empty = 0.33
	self.m32.timers.shotgun_reload_shell = 1
	self.m32.timers.shotgun_reload_first_shell_offset = 0
	
	--little friend
	self.contraband.stats.damage = 180
	self.contraband.can_shoot_through_enemy = true
	self.contraband.can_shoot_through_shield = true
	self.contraband.can_shoot_through_wall = false
	self.contraband.CLIP_AMMO_MAX = 40
	self.contraband.NR_CLIPS_MAX = 3
	self.contraband.AMMO_MAX = self.contraband.CLIP_AMMO_MAX * self.contraband.NR_CLIPS_MAX
	self.contraband.stats.total_ammo_mod = 63
	self.contraband.stats_modifiers = {damage = 2}
	self.contraband.stats.spread = 100 --accuracy higher=better
	self.contraband.stats.recoil = 100 --stability higher=better
	self.contraband.AMMO_PICKUP = {200,300}
	self.contraband.stats.zoom = 5
	self.contraband.stats.alert_size = 100
	self.contraband.FIRE_MODE = "auto"
	self.contraband.single = {fire_rate = 0.1}
	self.contraband.CAN_TOGGLE_FIREMODE = true
	--granade launcher for contraband
	self.contraband_m203.stats.damage = 100000
	self.contraband_m203.CLIP_AMMO_MAX = 5
	self.contraband_m203.NR_CLIPS_MAX = 3
	self.contraband_m203.AMMO_MAX = self.contraband_m203.CLIP_AMMO_MAX * self.contraband_m203.NR_CLIPS_MAX
	self.contraband_m203.AMMO_PICKUP = {200,300}
	self.contraband_m203.stats.zoom = 5
	self.contraband_m203.single = {fire_rate = 0.1}
	self.contraband_m203.CAN_TOGGLE_FIREMODE = true
	
	--cavity
	self.sub2000.can_shoot_through_enemy = true
	self.sub2000.can_shoot_through_shield = true
	self.sub2000.can_shoot_through_wall = false
	self.sub2000.CLIP_AMMO_MAX = 66
	self.sub2000.NR_CLIPS_MAX = 4
	self.sub2000.AMMO_MAX = self.sub2000.CLIP_AMMO_MAX * self.sub2000.NR_CLIPS_MAX
	self.sub2000.stats.total_ammo_mod = 63
	self.sub2000.AMMO_PICKUP = {200,300}
	self.sub2000.stats.zoom = 5
	self.sub2000.FIRE_MODE = "auto"
	self.sub2000.single = {fire_rate = 0.1}
	self.sub2000.CAN_TOGGLE_FIREMODE = true
	
	--steakout
	self.aa12.stats.damage = 150
	self.aa12.can_shoot_through_enemy = true
	self.aa12.can_shoot_through_shield = true
	self.aa12.can_shoot_through_wall = false
	self.aa12.CLIP_AMMO_MAX = 32
	self.aa12.NR_CLIPS_MAX = 5
	self.aa12.AMMO_MAX = self.aa12.CLIP_AMMO_MAX * self.aa12.NR_CLIPS_MAX
	self.aa12.stats.total_ammo_mod = 63
	self.aa12.stats_modifiers = {damage = 2}
	self.aa12.AMMO_PICKUP = {200,300}
	self.aa12.stats.zoom = 5
	self.aa12.FIRE_MODE = "auto"
	self.aa12.single = {fire_rate = 0.1}
	self.aa12.CAN_TOGGLE_FIREMODE = true
	
	--golden ak
	self.akm_gold.stats.damage = 220
	self.akm_gold.can_shoot_through_enemy = true
	self.akm_gold.can_shoot_through_shield = true
	self.akm_gold.can_shoot_through_wall = true
	self.akm_gold.CLIP_AMMO_MAX = 32
	self.akm_gold.NR_CLIPS_MAX = 5
	self.akm_gold.AMMO_MAX = self.akm_gold.CLIP_AMMO_MAX * self.akm_gold.NR_CLIPS_MAX
	self.akm_gold.stats.total_ammo_mod = 63
	self.akm_gold.stats.spread = 100 --accuracy higher=better
	self.akm_gold.AMMO_PICKUP = {200,300}
	self.akm_gold.stats.zoom = 5
	self.akm_gold.stats.alert_size = 100
	self.akm_gold.FIRE_MODE = "auto"
	self.akm_gold.single = {fire_rate = 0.1}
	self.akm_gold.CAN_TOGGLE_FIREMODE = true
	
	--m308
	self.new_m14.stats.damage = 180
	self.new_m14.can_shoot_through_enemy = true
	self.new_m14.can_shoot_through_shield = true
	self.new_m14.can_shoot_through_wall = false
	self.new_m14.CLIP_AMMO_MAX = 40
	self.new_m14.NR_CLIPS_MAX = 8
	self.new_m14.AMMO_MAX = self.new_m14.CLIP_AMMO_MAX * self.new_m14.NR_CLIPS_MAX
	self.new_m14.stats.total_ammo_mod = 63
	self.new_m14.AMMO_PICKUP = {200,300}
	self.new_m14.stats.zoom = 5
	self.new_m14.FIRE_MODE = "auto"
	self.new_m14.single = {fire_rate = 0.1}
	self.new_m14.CAN_TOGGLE_FIREMODE = true
	
	--valkyria
	self.asval.can_shoot_through_enemy = true
	self.asval.CLIP_AMMO_MAX = 100
	self.asval.NR_CLIPS_MAX = 4
	self.asval.stats.total_ammo_mod = 63
	self.asval.AMMO_PICKUP = {400,500}
	self.asval.stats.zoom = 5
	self.asval.FIRE_MODE = "auto"
	self.asval.single = {fire_rate = 0.1}
	self.asval.CAN_TOGGLE_FIREMODE = true
	
	--ak17
	self.flint.stats.damage = 250
	self.flint.can_shoot_through_enemy = true
	self.flint.can_shoot_through_shield = true
	self.flint.can_shoot_through_wall = false
	self.flint.CLIP_AMMO_MAX = 47
	self.flint.AMMO_MAX = self.flint.CLIP_AMMO_MAX * self.flint.NR_CLIPS_MAX
	self.flint.stats.total_ammo_mod = 63
	self.flint.stats.spread = 100 --accuracy higher=better
	self.flint.stats.recoil = 17
	self.flint.AMMO_PICKUP = {200,300}
	self.flint.stats.zoom = 5
	self.flint.stats.alert_size = 100
	self.flint.FIRE_MODE = "auto"
	self.flint.single = {fire_rate = 0.1}
	self.flint.CAN_TOGGLE_FIREMODE = true
	
	--bootleg rifle
	self.tecci.can_shoot_through_enemy = true
	self.tecci.can_shoot_through_shield = true
	self.tecci.can_shoot_through_wall = false
	self.tecci.AMMO_PICKUP = {200,300}
	self.tecci.stats.zoom = 5
	self.tecci.FIRE_MODE = "auto"
	self.tecci.single = {fire_rate = 0.1}
	self.tecci.CAN_TOGGLE_FIREMODE = true
	
	--jackal
	self.schakal.can_shoot_through_enemy = true
	self.schakal.can_shoot_through_shield = true
	self.schakal.can_shoot_through_wall = false
	self.schakal.CLIP_AMMO_MAX = 30
	self.schakal.NR_CLIPS_MAX = 4
	self.schakal.AMMO_MAX = self.schakal.CLIP_AMMO_MAX * self.schakal.NR_CLIPS_MAX
	self.schakal.AMMO_PICKUP = {200,300}
	self.schakal.stats.zoom = 5
	self.schakal.FIRE_MODE = "auto"
	self.schakal.auto = {fire_rate = 0.07}
	self.schakal.single = {fire_rate = 0.1}
	self.schakal.fire_mode_data = {fire_rate = 0.1}
	self.schakal.CAN_TOGGLE_FIREMODE = true
	
	--akimbo jackal
	self.x_schakal.stats.damage = 150
	self.x_schakal.can_shoot_through_enemy = true
	self.x_schakal.can_shoot_through_shield = true
	self.x_schakal.can_shoot_through_wall = false
	self.x_schakal.CLIP_AMMO_MAX = 60
	self.x_schakal.NR_CLIPS_MAX = 9
	self.x_schakal.AMMO_MAX = self.x_schakal.CLIP_AMMO_MAX * self.x_schakal.NR_CLIPS_MAX
	self.x_schakal.stats.spread = 100 --accuracy higher=better
	self.x_schakal.stats.recoil = 22
	self.x_schakal.AMMO_PICKUP = {200,300}
	self.x_schakal.stats.zoom = 5
	self.x_schakal.stats.alert_size = 100
	self.x_schakal.FIRE_MODE = "auto"
	self.x_schakal.single = {fire_rate = 0.1}
	self.x_schakal.CAN_TOGGLE_FIREMODE = true
	self.x_schakal.shake.fire_multiplier = 0
	self.x_schakal.kick.standing = {0.3,0.3,-0.1,0}
	
	--kross vertex
	self.polymer.stats.damage = 120
	self.polymer.can_shoot_through_enemy = true
	self.polymer.can_shoot_through_shield = true
	self.polymer.can_shoot_through_wall = false
	self.polymer.CLIP_AMMO_MAX = 60
	self.polymer.NR_CLIPS_MAX = 9
	self.polymer.AMMO_MAX = self.polymer.CLIP_AMMO_MAX * self.polymer.NR_CLIPS_MAX
	self.polymer.AMMO_PICKUP = {200,300}
	self.polymer.stats.zoom = 5
	self.polymer.FIRE_MODE = "auto"
	self.polymer.single = {fire_rate = 0.1}
	self.polymer.CAN_TOGGLE_FIREMODE = true
	self.polymer.shake.fire_multiplier = 0
	
	--akimbo goliath
	self.x_rota.stats.damage = 150
	self.x_rota.can_shoot_through_enemy = true
	self.x_rota.can_shoot_through_shield = true
	self.x_rota.can_shoot_through_wall = false
	self.x_rota.CLIP_AMMO_MAX = 30
	self.x_rota.NR_CLIPS_MAX = 8
	self.x_rota.AMMO_MAX = self.x_rota.CLIP_AMMO_MAX * self.x_rota.NR_CLIPS_MAX
	self.x_rota.stats.spread = 5
	self.x_rota.stats.recoil = 20 --accuracy higher=better
	self.x_rota.AMMO_PICKUP = {200,300}
	self.x_rota.stats.zoom = 5
	self.x_rota.stats.alert_size = 100
	self.x_rota.FIRE_MODE = "single"
	self.x_rota.auto = {fire_rate = 0.8}
	self.x_rota.single = {fire_rate = 0.1}
	self.x_rota.fire_mode_data = {fire_rate = 0.15}
	self.x_rota.CAN_TOGGLE_FIREMODE = true
	
	--chicago typewriter
	self.x_m1928.stats.damage = 150
	self.x_m1928.can_shoot_through_enemy = true
	self.x_m1928.can_shoot_through_shield = true
	self.x_m1928.can_shoot_through_wall = true
	self.x_m1928.CLIP_AMMO_MAX = 180
	self.x_m1928.NR_CLIPS_MAX = 4
	self.x_m1928.AMMO_MAX = self.x_m1928.CLIP_AMMO_MAX * self.x_m1928.NR_CLIPS_MAX
	--self.x_m1928.stats.spread = 100 --accuracy higher=better
	self.x_m1928.stats.recoil = 22
	self.x_m1928.AMMO_PICKUP = {200,300}
	self.x_m1928.stats.zoom = 5
	self.x_m1928.stats.alert_size = 100
	self.x_m1928.FIRE_MODE = "auto"
	self.x_m1928.single = {fire_rate = 0.1}
	self.x_m1928.CAN_TOGGLE_FIREMODE = true
	--self.x_m1928.shake.fire_multiplier = 0
	self.x_m1928.kick.standing = {0.2,0.2,-0.1,0}
	
	--saw ove9000
	self.saw.stats.damage = 500
	self.saw.can_shoot_through_enemy = true
	self.saw.can_shoot_through_shield = true
	self.saw.can_shoot_through_wall = true
	self.saw.CLIP_AMMO_MAX = 500
	self.saw.NR_CLIPS_MAX = 4
	self.saw.AMMO_MAX = self.saw.CLIP_AMMO_MAX * self.saw.NR_CLIPS_MAX
	self.saw.stats.total_ammo_mod = 63
	self.saw.AMMO_PICKUP = {500,600}
	self.saw.stats.zoom = 5
	self.saw.stats.alert_size = 100
	self.saw.stats.suppression = 0
	
	for _, weap in pairs(self) do
		if weap.CAN_TOGGLE_FIREMODE and not weap.BURST_FIRE then
			weap.BURST_FIRE = false
		end
	end
	
	--bipod deploy time
	self.hk21.timers.deploy_bipod = 0
	self.m249.timers.deploy_bipod = 0
	self.rpk.timers.deploy_bipod = 0
	self.mg42.timers.deploy_bipod = 0
	self.par.timers.deploy_bipod = 0
	
	--sentry
	self.sentry_gun.DAMAGE = 15 --host side
	self.sentry_gun.SHIELD_DMG_MUL = 0.001 --client side
	self.sentry_gun.SUPPRESSION = 1
	self.sentry_gun.SPREAD = 0 --client side
	self.sentry_gun.FIRE_RANGE = 20000 --client side
	--self.sentry_gun.auto.fire_rate = 0.01 --host side
	self.sentry_gun.alert_size = 20000 --client side
	self.sentry_gun.MAX_VEL_SPIN = 360 --client side
end