local orig = GuiTweakData.init
function GuiTweakData:init(tweak_data, ...)
	orig(self, tweak_data, ...)
	self.crime_net.regions = {}
	self.crime_net.job_vars = {
		max_active_jobs = (CommandManager.config["remove_free_jobs"] and 0 or 12),
		active_job_time = 25,
		new_job_min_time = 0.01,
		new_job_max_time = 0.02,
		refresh_servers_time = SystemInfo:platform() == "PS4" and 10 or 5,
		total_active_jobs = 40,
		max_active_server_jobs = 100
	}
end