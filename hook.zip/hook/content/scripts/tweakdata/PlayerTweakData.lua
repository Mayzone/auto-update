--https://github.com/mwSora/payday-2-luajit/blob/master/pd2-lua/lib/tweak_data/playertweakdata.lua
local old_ptd = PlayerTweakData.init
function PlayerTweakData:init()
	old_ptd(self)
	self.put_on_mask_time = 1.1 --def 2
	self.max_nr_following_hostages = 5
	if CommandManager.config["trainer_buffs"] then
		self.damage.TASED_RECOVER_TIME = 0
		self.damage.BLEED_OUT_HEALTH_INIT = 500
		self.damage.automatic_assault_ai_trade_time = 2
		self.damage.automatic_assault_ai_trade_time_max = 2
		self.movement_state.standard.movement.speed.CROUCHING_MAX = 280
		self.movement_state.standard.movement.speed.STEELSIGHT_MAX = 350
		self.movement_state.standard.movement.speed.CLIMBING_MAX = 350
		self.movement_state.standard.movement.speed.STANDARD_MAX = 350
		self.movement_state.standard.movement.speed.RUNNING_MAX = 575
	end
	--lmg scope
		-- M249
		local pivot_shoulder_translation = Vector3( 10.775, 5.09, -1.2 )
		local pivot_shoulder_rotation = Rotation( 0, -58.75, 0 )
		local pivot_head_rotation = Rotation( 0, 0.2, 0 )
		self.stances.m249.steelsight.shoulders.translation = Vector3( 0, 5.5, .75 ) - pivot_shoulder_translation:rotate_with( pivot_shoulder_rotation:inverse() ):rotate_with( pivot_head_rotation )
		self.stances.m249.steelsight.shoulders.rotation = pivot_head_rotation
		
		-- rpk
		local pivot_shoulder_translation2 = Vector3( 10.69, 33, -1.84 )
		local pivot_shoulder_rotation2 = Rotation( 0.1067, -0.0850111, 0.629008 )
		local pivot_head_rotation2 = Rotation( 0, 0.2, 0 )
		self.stances.rpk.steelsight.shoulders.translation = Vector3( .1, 7, 0.22 ) - pivot_shoulder_translation2:rotate_with( pivot_shoulder_rotation2:inverse() ):rotate_with( pivot_head_rotation2 )
		self.stances.rpk.steelsight.shoulders.rotation = pivot_head_rotation2
		
		-- MG42
		local pivot_shoulder_translation3 = Vector3( 10.713, 47.8277, 0.873785 )
		local pivot_shoulder_rotation3 = Rotation( 0.10662, -0.0844545, 0.629209 )
		local pivot_head_rotation3 = Rotation( 0, 0, 0 )
		self.stances.mg42.steelsight.shoulders.translation = Vector3( 0, 40.5, -2.7 ) - pivot_shoulder_translation3:rotate_with( pivot_shoulder_rotation3:inverse() ):rotate_with( pivot_head_rotation3 )
		self.stances.mg42.steelsight.shoulders.rotation = pivot_head_rotation3
		
		-- brenner
		local pivot_shoulder_translation4 = Vector3( 10.83, 26, 1.37 )
		local pivot_shoulder_rotation4 = Rotation( 3.03061, 1.08595, 1.87441 )
		local pivot_head_rotation4 = Rotation( -3, -1, -2 )
		self.stances.hk21.steelsight.shoulders.translation = Vector3( .98, 10, 0.1 ) - pivot_shoulder_translation4:rotate_with( pivot_shoulder_rotation4:inverse() ):rotate_with( pivot_head_rotation4 )
		self.stances.hk21.steelsight.shoulders.rotation = pivot_head_rotation4
	--
end



