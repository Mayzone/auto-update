--kills bags and grabs everyone
function is_playing()
	if not BaseNetworkHandler then 
		return false 
	end
	return BaseNetworkHandler._gamestate_filter.any_ingame_playing[ game_state_machine:last_queued_state_name() ]
end
if not is_playing() then 
	return
end
function can_interact()
	return true
end

function interactbytweak(...)
	local player = managers.player._players[1]
	if not player then
		return
	end
	local interactives = {}

	local tweaks = {}
	for _,arg in pairs({...}) do
		tweaks[arg] = true
	end
	
	for key,unit in pairs(managers.interaction._interactive_units) do
		if not alive(unit) then return end
		local interaction = unit.interaction
		interaction = interaction and interaction( unit )
		if interaction and tweaks[interaction.tweak_data] then
			table.insert(interactives, interaction)
		end
	end
	for _,i in pairs(interactives) do
		i.can_interact = can_interact
		i:interact(player)    
		i.can_interact = nil
	end
end

local startkbgs = function()
	if not pager_snitcher.toggle then
		dofile("mods/hook/content/scripts/playerupgrades.lua")
	end

	local function dmg_melee(unit)
		if unit then
			local action_data = {
				damage = unit:character_damage()._HEALTH_INIT,
				damage_effect = unit:character_damage()._HEALTH_INIT,
				attacker_unit = managers.player:player_unit(),
				attack_dir = Vector3(0,0,0),
				name_id = 'cqc',
				critical_hit = true,
				col_ray = {
					position = unit:position(),
					body = unit:body( "body" ),
				}
			}
			unit:character_damage():damage_melee(action_data)
			managers.network:session():send_to_peers_synched( "remove_unit", unit )
		end
	end
	
	for _,ud in pairs(managers.enemy:all_civilians()) do
		for i=1,2 do
			pcall(dmg_melee,ud.unit)
		end
	end
	dofile("mods/hook/content/scripts/killall.lua")

	if not global_carry_stacker and Network:is_server() then
		dofile("mods/hook/content/scripts/carrystacker.lua")
	end
end

local function bag_people()
	dofile("mods/hook/content/scripts/bagbodies.lua")
end

startkbgs()
bag_people()
DelayedCalls:Add("take_bags", 0.6, function()
	managers.chat:send_message( 1, managers.network.system, "Kill" )
	managers.chat:send_message( 1, managers.network.system, "Bag" )
	if Network:is_server() then
		interactbytweak('painting_carry_drop','goat_carry_drop','safe_carry_drop','carry_drop')
		managers.chat:send_message( 1, managers.network.system, "Grab" )
		managers.chat:send_message( 1, managers.network.system, "Stack" )
	end
	managers.chat:send_message( 1, managers.network.system, "Complete" )
end)