function is_playing()
	if not BaseNetworkHandler then 
		return false 
	end
	return BaseNetworkHandler._gamestate_filter.any_ingame_playing[ game_state_machine:last_queued_state_name() ]
end
if not is_playing() then 
	return
end
function is_hostage(unit)
	if alive(unit) then
		local brain = unit.brain
		brain = brain and brain( unit )
		if brain then
			local is_hostage = brain.is_hostage
			is_hostage = is_hostage and is_hostage( brain )
			if is_hostage then
				return true
			end
		end
		local anim_data = unit.anim_data
		anim_data = anim_data and anim_data(unit)
		if anim_data then
			local tied = anim_data.tied or anim_data.hands_tied
			if tied then
				return true
			end
		end
	end
	return false
end
function interactbytweak(...)
	local player = managers.player._players[1] or managers.player:player_unit()
	if not player then
		return
	end
	
	local can_interact = function()
		return true
	end
	
	local tweaks = {}
	for _,arg in pairs({...}) do
		if type(arg) == 'string' then
			tweaks[arg] = true
		end
	end
	
	local interacts = {}
	local interaction
	for _,unit in pairs(managers.interaction._interactive_units) do
		if not alive(unit) then return end
		interaction = unit:interaction()
		if interaction and tweaks[interaction.tweak_data] then
			table.insert(interacts, interaction)
		end
	end
	
	for _,int in pairs(interacts) do
		int.can_interact = can_interact
		int:interact(player)
	end
end


--kills everyone
local killall = function()
	if not pager_snitcher.toggle then
		dofile("mods/hook/content/scripts/playerupgrades.lua")
	end

	local function dmg_melee(unit)
		if unit then
			--if (unit:base()._tweak_table == "spooc" or unit:base()._tweak_table == "heavy_swat")  then
				local action_data = {
					damage = unit:character_damage()._HEALTH_INIT,
					damage_effect = unit:character_damage()._HEALTH_INIT,
					attacker_unit = managers.player:player_unit(), --attacker_unit:base()._grenade_entry = "molotov", attacker_unit:base():get_owner(), character_damage():base().sentry_gun,
					attack_dir = Vector3(0,0,0),
					variant = "counter_tased", --"counter_tased","taser_tased",    "expl_hurt" "fire","explosion","melee","bullet""stun""dot""healed","graze","poison_hurt","dmg_rcv","light_hurt",	"hurt",	"heavy_hurt","death","shield_knock","knock_down","stagger"
					name_id = 'cqc', --'cqc'
					critical_hit = true,
					col_ray = {
						position = unit:position(),
						body = unit:body( "body" ),
					}
				}
				unit:character_damage():damage_melee(action_data)
				managers.network:session():send_to_peers_synched( "remove_unit", unit )
				--unit:character_damage():heal_unit(action_data)
			--end
			--unit:character_damage():damage_explosion(action_data)
			--unit:character_damage():damage_bullet(action_data)
		end
	end

	local function dmg_cam(unit)
		local position = unit:position()
		local body
		do
			local i = -1
			repeat
				i = i+1
				body = unit:body(i)
			until (body and body:extension()) or i >= 5
			if not body then
				return
			end
		end
		body:extension().damage:damage_melee( unit, nil, position, nil, 10000 )
		managers.network:session():send_to_peers_synched( "sync_body_damage_melee", body, unit, nil, position, nil, 10000 )
	end

	-- Ties civs
	local id_level = managers.job:current_level_id()
	if not (id_level == 'cane') then
		if Network:is_server() then
			local panic_alarm = function(typ, act)
				for _, group in pairs({managers.enemy:all_civilians()}) do
					for _, unit in pairs(group or {}) do
						if not (id_level == 'tag') then
							managers.groupai:state():propagate_alert({typ, unit.m_pos, 10000, act == 3 and unit.so_access or data_access[act], act == 2 and managers.player._players[1] or act == 3 and unit.unit or nil, act == 2 and unit.m_pos or nil})
						end
					end
				end
				for _, group in pairs(managers.enemy:all_civilians()) do
					group.unit:brain():on_intimidated(100, managers.player:player_unit())
				end
				DelayedCalls:Add( "killall_tie_civ2", 1.5, function()
					for u_key, u_data in pairs( managers.enemy:all_civilians() ) do	
						if not u_data.unit:brain():is_tied() then
							local action_data = { type = "act", body_part = 1, clamp_to_graph = true, variant = "halt" }
							u_data.unit:brain():action_request( action_data )
							u_data.unit:brain()._current_logic.on_intimidated( u_data.unit:brain()._logic_data, math.huge, managers.player:player_unit(), true )
							u_data.unit:brain():on_tied(managers.player:player_unit())
						end
					end
				end)
				DelayedCalls:Add( "killall_tie_civ3", 1.7, function()
					for _,ud in pairs(managers.enemy:all_civilians()) do
						if not (is_hostage(ud.unit)) or (ud.unit:base()._tweak_table == "bank_manager") then
							for i=1,2 do
								pcall(dmg_melee,ud.unit)
							end
						end
					end
				end)
				interactbytweak('intimidate')
			end
			panic_alarm("vo_intimidate", 3)--]]
		else
			for _,ud in pairs(managers.enemy:all_civilians()) do
				local unit = ud.unit
				if not is_hostage(unit) then
					for i=1,2 do
						pcall(dmg_melee,unit)
					end
				end
			end
		end
	end

	--Kills enemies
	for _,u_data in pairs(managers.enemy:all_enemies()) do
		if not (is_hostage(u_data.unit)) and not (u_data.is_converted) then
			if u_data.unit:base()._tweak_table == "mute_security_undominatable" then
			else
				pcall(dmg_melee,u_data.unit)
			end
		end
	end
	DelayedCalls:Add( "killalldelay", 0.2, function() 
		for _,u_data in pairs(managers.enemy:all_enemies()) do
			if not (is_hostage(u_data.unit)) and not (u_data.is_converted) then
				if u_data.unit:base()._tweak_table == "mute_security_undominatable" then
				else
					pcall(dmg_melee,u_data.unit)
				end
			end
		end
	end)
	--kills cams
	if not (id_level == 'tag') then
		for _,unit in pairs(SecurityCamera.cameras) do
			pcall(dmg_cam,unit)
		end
	end

	managers.mission._fading_debug_output:script().log('Kill all ACTIVATED',  Color.green)
end
killall()