function is_playing()
	if not BaseNetworkHandler then 
		return false 
	end
	return BaseNetworkHandler._gamestate_filter.any_ingame_playing[ game_state_machine:last_queued_state_name() ]
end

function in_chat()
	if managers.hud._chat_focus == true then
		return true
	end
	if ( managers.network.account and managers.network.account._overlay_opened ) then
		return true
	end
	return false
end

if not is_playing() and not in_chat() then
	return
end

if alive(managers.player:player_unit()) then
	--health, ammo
	managers.player:player_unit():base():replenish()
	--player state
	managers.player:set_player_state('standard')
	--body bags
	managers.player:add_body_bags_amount(3)
	--cable tie
	managers.player:add_special({name = "cable_tie", silent = true, amount = 1})
	if managers.hud and Network:is_server() then
		--granade amount
		managers.player:add_grenade_amount(3)
		--deployable
		managers.player:clear_equipment()
        managers.player._equipment.selections = {}
        managers.player:add_equipment({silent = true, equipment = managers.blackmarket:equipped_deployable()})
	end
else
	IngameWaitingForRespawnState.request_player_spawn()
end