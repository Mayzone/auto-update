Drill = Drill or class(UnitBase)
Drill.on_hit_autorepair_chance = 1