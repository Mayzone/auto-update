local class_name = "hook_mod_identifier_antenna"
local loaded = rawget(_G, class_name)
local c = loaded or rawset(_G, class_name, {
	recived_peers = {}
}) and _G[class_name]

if not loaded then
	-- check players recently played with (if reconnecting after entering menu and such)
	function c:is_recent(user_id)
        local recent = Steam and Steam:coplay_friends()

        for _, user in ipairs(recent or {}) do
            if user:id() == user_id then
                return true
            end
        end
	end
end

if RequiredScript == "lib/network/base/networkpeer" then
	local orig_send = NetworkPeer.send
	function NetworkPeer:send(func_name, ...)
        orig_send(self, func_name, ...)

		local local_id = self._ip_verified and managers.network:session():local_peer()

		if local_id and self:id() ~= local_id:id() and func_name == "lobby_info" then
			LuaNetworking:SendToPeer(self:id(), class_name, local_id:id())
		end
	end

	--receive as client/host
	Hooks:Add("NetworkReceivedData", class_name, function(peer_id, id, data)
		if id == class_name and #data == 1 then
			local sender = managers.network:session():peer((tonumber(data) or 0))
			local user_id = sender and sender:user_id()

			if user_id and not c.recived_peers[user_id] then
				c.recived_peers[user_id] = true

                if not c:is_recent(user_id) then
				    managers.chat:_receive_message(1, "HOOK", string.format("Detection from %s.", sender:name()), Color.green)
                end
			end
		end
	end)
end