local mod_name = "improved_knock"
local orig_func_force_hurt = CopDamage.force_hurt
function CopDamage:force_hurt(attack_data, ...)
    orig_func_force_hurt(self, attack_data, ...)

	if not self._dead and attack_data.result.type == "shield_knock" then
        local state = managers.player:get_current_state() or {}
		local equipped_unit = state._equipped_unit
		local weap_base = equipped_unit and equipped_unit:base()

        if weap_base and not weap_base._can_shoot_through_shield then
            weap_base._can_shoot_through_shield = true
            local id = tostring(self._unit:key())
            local ray = Utils:GetCrosshairRay(false, false, "enemy_shield_check")
            local unit = ray and ray.unit
            local orig_weap_base = function()
                weap_base._can_shoot_through_shield = false
            end

            if unit then
                DelayedCalls:Add(id, 3, orig_weap_base)
            end

            self:add_listener(mod_name .. id, {"death"}, orig_weap_base)
        end
    end
end