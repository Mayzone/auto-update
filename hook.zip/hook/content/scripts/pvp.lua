if not rawget(_G, "FriendlyFireModifier") then
	rawset(_G, "FriendlyFireModifier", {})
	FriendlyFireModifier._data = {}
	FriendlyFireModifier._data.friendly_fire = false
	FriendlyFireModifier._data.friendly_fire_damage = true
	FriendlyFireModifier._data.dmg_multiplier = 2
	FriendlyFireModifier._data.dmg_max = 0
	FriendlyFireModifier._data.on_hit_state = "none"
	function FriendlyFireModifier:is_playing()
		return BaseNetworkHandler._gamestate_filter.any_ingame_playing[ game_state_machine.last_queued_state_name(game_state_machine) ]
	end

	function FriendlyFireModifier:is_friendly_fire_enabled()
		return managers.mutators:is_mutator_active(MutatorFriendlyFire) or FriendlyFireModifier._data.friendly_fire
	end

	function FriendlyFireModifier:toggle()
		if not self._data.friendly_fire then
			managers.mission._fading_debug_output:script().log(string.format("PvP is ACTIVATED"), Color.green)
		else
			managers.mission._fading_debug_output:script().log(string.format("PvP is DEACTIVATED"), Color.red)
		end
		self._data.friendly_fire = not self._data.friendly_fire
		self:init()
	end

	function FriendlyFireModifier:get_state_by_index(index)
		for i, state in pairs(self.states) do
			if i == index then
				return state
			end
		end
		return "none" 
	end

	function FriendlyFireModifier:init()
		if self:is_playing() then
			local player = managers.player:player_unit()
			if player then
				if player:movement() and player:movement():current_state() then
					local current_state = player:movement():current_state()
					if FriendlyFireModifier._data.friendly_fire then
						current_state._slotmask_bullet_impact_targets = current_state._slotmask_bullet_impact_targets + managers.slot:get_mask("players") 
					else
						current_state._slotmask_bullet_impact_targets = current_state._slotmask_bullet_impact_targets - managers.slot:get_mask("players") 
					end
				end
				
				local player_type = FriendlyFireModifier._data.friendly_fire and "converted_enemy" or "criminal1"
				local team_index = tweak_data.levels:get_team_index(player_type)
				
				local team_id = tweak_data.levels:get_team_names_indexed()[team_index]
				local team_data = managers.groupai:state():team_data(team_id)

				player:movement():set_team(team_data)
				player:network():send("sync_unit_event_id_16", "movement", team_index)
				
				local inventory = player:inventory()
				if inventory and inventory.available_selections then
					for _, weapon in pairs(inventory:available_selections()) do
						if weapon.unit and weapon.unit:base() and weapon.unit:base()._bullet_slotmask then
							local bullet_slotmask = weapon.unit:base()._bullet_slotmask
							if FriendlyFireModifier._data.friendly_fire then
								bullet_slotmask = bullet_slotmask + managers.slot:get_mask("all_criminals") + managers.slot:get_mask("criminals_no_deployables")
							else
								bullet_slotmask = bullet_slotmask - managers.slot:get_mask("all_criminals") - managers.slot:get_mask("criminals_no_deployables")
							end
							weapon.unit:base():set_bullet_hit_slotmask(bullet_slotmask)
						end
					end
				end
			end
		end
	end

	if RequiredScript == "lib/units/beings/player/huskplayerdamage" then
		function HuskPlayerDamage:damage_bullet(attack_data)
			if FriendlyFireModifier:is_friendly_fire_enabled() then
				self:_send_damage_to_owner(attack_data)
			end
		end

		function HuskPlayerDamage:damage_melee(attack_data)
			if FriendlyFireModifier:is_friendly_fire_enabled() then
				attack_data.damage = attack_data.damage * FriendlyFireModifier._data.dmg_multiplier
				self:_send_damage_to_owner(attack_data)
				if FriendlyFireModifier._data.on_hit_state and FriendlyFireModifier._data.on_hit_state ~= "none" then
					self._unit:network():send_to_unit({
						"sync_player_movement_state",
						self._unit,
						FriendlyFireModifier._data.on_hit_state,
						0,
						self._unit:id()
					})
				end
			end
		end

		function HuskPlayerDamage:damage_fire(attack_data)
			if FriendlyFireModifier:is_friendly_fire_enabled() then
				attack_data.damage = attack_data.damage * FriendlyFireModifier._data.dmg_multiplier

				self:_send_damage_to_owner(attack_data)
			end
		end

		function HuskPlayerDamage:_send_damage_to_owner(attack_data)
			local peer_id = managers.criminals:character_peer_id_by_unit(self._unit)
			local damage = managers.mutators:modify_value("HuskPlayerDamage:FriendlyFireDamage", attack_data.damage)
			
			if not managers.mutators:is_mutator_active(MutatorFriendlyFire) and not FriendlyFireModifier._data.friendly_fire_damage then
				damage = 0
			elseif FriendlyFireModifier._data.dmg_multiplier then
				damage = damage * FriendlyFireModifier._data.dmg_multiplier
			end
			
			if damage and damage > 0 then
				if FriendlyFireModifier._data.dmg_max and FriendlyFireModifier._data.dmg_max ~= 0 then
					if damage > FriendlyFireModifier._data.dmg_max then
						damage =  FriendlyFireModifier._data.dmg_max
					end
				end
			end

			managers.network:session():send_to_peers("sync_friendly_fire_damage", peer_id, attack_data.attacker_unit, damage, attack_data.variant)
			
			if attack_data.attacker_unit == managers.player:player_unit() then
				managers.hud:on_hit_confirmed()
			end

			managers.job:set_memory("trophy_flawless", true, false)
		end
	end
end
if rawget(_G, "FriendlyFireModifier") then
	FriendlyFireModifier:toggle()
end