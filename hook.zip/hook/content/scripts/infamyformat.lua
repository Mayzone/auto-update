function ExperienceManager:gui_string(level, rank, offset)
	offset = offset or 0
	local rank_string = rank > 0 and self:rank_string(rank) or ""
	local gui_string
	if rank>0 then
		gui_string =  rank_string .."-" .. tostring(level)
	else
		gui_string =  tostring(level)
	end
	local rank_color_range = {
		start = offset,
		stop = offset+utf8.len(rank_string),
		color = tweak_data.screen_colors.infamy_color
	}

	return gui_string, {
		rank_color_range
	}
end