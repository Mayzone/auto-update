tweak_data.upgrades.values.ammo_bag.ammo_increase = {128}
if not Network.is_server(Network) then
	if managers.hud and (managers.player:player_unit()) then
		managers.player:clear_equipment()
		managers.player._equipment.selections = {}
		managers.player:add_equipment({ silent = true, equipment = "ammo_bag" })
	end
	managers.mission._fading_debug_output:script().log(string.format("Ammo Bag - Equiped"), Color.green)
else
	function get_crosshair_ray(penetrate, from_pos, mvec_to)
		local camera = managers.player:player_unit():camera()
		if not penetrate then penetrate = false end
		if not mvec_to then mvec_to = Vector3() end
		if not from_pos then from_pos = camera:position() end
		mvector3.set( mvec_to, camera:forward() )
		mvector3.multiply( mvec_to, 20000 )
		mvector3.add( mvec_to, from_pos )
		local col_ray = World:raycast( "ray", from_pos, mvec_to, "slot_mask", managers.slot:get_mask( "bullet_impact_targets" ) )
		if col_ray then
		  if penetrate then
			  local offset = Vector3()
			  mvector3.set(offset, camera:forward())
			  mvector3.multiply(offset, 100)
			  mvector3.add(col_ray.hit_position, offset)
		  end
		  return col_ray
		end
		return false
	end
	function get_crosshair_pos(penetrate, from_pos, mvec_to)
		local ray = get_crosshair_ray(penetrate, from_pos, mvec_to)
		if not ray then return false end
		return ray.hit_position
	end

	local pos = get_crosshair_pos()
	local rot = managers.player:player_unit():rotation()
	local amount_upgrade_lvl = managers.player:upgrade_level( "ammo_bag", "amount_increase" )
	AmmoBagBase.spawn( pos, rot, amount_upgrade_lvl )
	
	managers.mission._fading_debug_output:script().log('Ammo Spawn ACTIVATED', Color.green)
end