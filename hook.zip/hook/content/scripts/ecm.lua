-- spawn ecm
--https://github.com/mwSora/payday-2-luajit/blob/master/pd2-lua/lib/units/equipment/ecm_jammer/ecmjammerbase.lua
if Network:is_server() then
	local from = managers.player:player_unit():movement():m_head_pos()
	local to = from + managers.player:player_unit():movement():m_head_rot():y() * 10000
	local ray = managers.player:player_unit():raycast("ray", from, to, "slot_mask", managers.slot:get_mask("trip_mine_placeables"), "ignore_unit", {})
	if ray then
		local pos = ray.position
		local rot = Rotation(ray.normal, math.UP) --dont change
		local player_unit = managers.player:player_unit()
		spawnecm = ECMJammerBase.spawn(pos, rot, 3, player_unit, managers.network:session():local_peer():id())
		spawnecm:base():set_active(true)
	end
	managers.mission._fading_debug_output:script().log('ECM spawn ACTIVATED', Color.green)
else
	if managers.hud and (managers.player:player_unit()) then
		managers.player:clear_equipment()
		managers.player._equipment.selections = {}
		managers.player:add_equipment({ silent = true, equipment = "ecm_jammer" })
	end
	managers.mission._fading_debug_output:script().log(string.format("ECM Jammer - Equiped"), Color.green)
end