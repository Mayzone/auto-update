ColorList = {
	r = nil,
	g = nil,
	b = nil,
	t = nil
}

function getColor(color_type, hb)
	local r, g, b = tonumber(color_type[1])/255, tonumber(color_type[2])/255, tonumber(color_type[3])/255
	local formated = string.format("%i, %i, %i", ColorList.r, ColorList.g, ColorList.b)
	if tonumber(color_type[4]) then
		local t = tonumber(color_type[4])/255
		return Color(r, g, b, t)
	else
		return Color(r, g, b)
	end
	--managers.mission._fading_debug_output:script().log(string.format("loaded %s: %s %s", hb, formated, Color(r, g, b)), Color.red)
end

function load_hover()
	local file = io.open("mods/hookloc/colormenu.txt", "r")
	local file2 = io.open("mods/hookloc/colormenu2.txt", "r")
	local file3 = io.open("mods/hookloc/colormenu3.txt", "r")
	local filet = io.open("mods/hookloc/colormenut.txt", "r")
	if not (file and file2 and file3 and filet) then 
		--managers.mission._fading_debug_output:script().log(string.format("load fail 123"), Color.red)
		return nil 
	end
	
	local load_number
	
	io.input(file)
	load_number = io.read("*a")
	ColorList.r = tonumber(load_number)
	file:close()
	
	io.input(file2)
	load_number = io.read("*a")
	ColorList.g = tonumber(load_number)
	file2:close()
	
	io.input(file3)
	load_number = io.read("*a")
	ColorList.b = tonumber(load_number)
	file3:close()
	
	io.input(filet)
	load_number = io.read("*a")
	ColorList.t = tonumber(load_number)
	filet:close()
	
	tweak_data.screen_colors.button_stage_2 = getColor({ColorList.r, ColorList.g, ColorList.b, ColorList.t}, "h")
end

function load_button()
	local file4 = io.open("mods/hookloc/colormenu4.txt", "r")
	local file5 = io.open("mods/hookloc/colormenu5.txt", "r")
	local file6 = io.open("mods/hookloc/colormenu6.txt", "r")
	local filet2 = io.open("mods/hookloc/colormenut.txt", "r")
	if not (file4 and file5 and file6 and filet2) then 
		--managers.mission._fading_debug_output:script().log(string.format("load fail 456"), Color.red)
		return nil 
	end
	
	local load_number
	
	io.input(file4)
	load_number = io.read("*a")
	ColorList.r = tonumber(load_number)
	file4:close()
	
	io.input(file5)
	load_number = io.read("*a")
	ColorList.g = tonumber(load_number)
	file5:close()
	
	io.input(file6)
	load_number = io.read("*a")
	ColorList.b = tonumber(load_number)
	file6:close()
	
	io.input(filet2)
	load_number = io.read("*a")
	ColorList.t = tonumber(load_number)
	filet2:close()
	
	tweak_data.screen_colors.button_stage_3 = getColor({ColorList.r, ColorList.g, ColorList.b, ColorList.t}, "b")
end
load_hover()
load_button()