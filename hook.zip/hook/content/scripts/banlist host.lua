local function ctamer_BanAssholeHost(id, name)
	if id and name and managers.ban_list and not managers.ban_list:banned(id) then
		managers.ban_list:ban(id, name)
		if managers.mission and managers.mission._fading_debug_output then
			managers.mission._fading_debug_output:script().log(string.format("Added Name: %s - Steam ID: %s - To Banlist", tostring(name), tostring(id)), Color.green)
		end
	end
end

if _G["MenuManager"] ~= nil then
	Hooks:PostHook(MenuManager, "show_peer_kicked_dialog", "ctamer_autoban_kick_dialog", function(ass)
		ctamer_BanAssholeHost(ClientNetworkSession.ctamer_host_steamid, ClientNetworkSession.ctamer_host_name)
	end)

	Hooks:PostHook(MenuManager, "show_peer_banned_dialog", "ctamer_autoban_ban_dialog", function(ass)
		ctamer_BanAssholeHost(ClientNetworkSession.ctamer_host_steamid, ClientNetworkSession.ctamer_host_name)
	end)
end

if _G["ClientNetworkSession"] ~= nil then
	Hooks:PostHook(ClientNetworkSession, "request_join_host", "ctamer_get_host", function(ass)
		self.ctamer_host_name = managers.network:session():server_peer():name()
		self.ctamer_host_steamid = managers.network:session():server_peer():user_id()
	end)
end
