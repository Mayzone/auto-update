--enable to find lobbies with these mods
local mods_to_find_on_crimenet = {
	["base superblt blt"] = CommandManager.config.filter_modded_lobbies,
	["p3d hack free"] = false,
	["Silent Assassin"] = false,
	["the cooker"] = false,
	["pirate pp"] = false,
	["hud"] = false
}

function NetworkMatchMakingSTEAM:find_match(mods_string, mod_name)
	local s_f = string.find(mods_string, mod_name)
	local s_m = string.match(mods_string, mod_name)
	if s_f or s_m then
		return true
	end
	return false
end

local orig_func_is_server_ok = NetworkMatchMakingSTEAM.is_server_ok
function NetworkMatchMakingSTEAM:is_server_ok(friends_only, room, attributes_list, is_invite, ...)
	local result = {orig_func_is_server_ok(self, friends_only, room, attributes_list, is_invite, ...)}
	if attributes_list.numbers and not CommandManager.config.filter_modded_lobbies or not attributes_list.mods then
		return unpack(result)
	end
	for filter_name, enabled in pairs(mods_to_find_on_crimenet) do 
		if enabled then
			local s_s = string.split(attributes_list.mods, "|") or {}
			for _, server_name in pairs(s_s) do 
				local server_mod_name = string.lower(server_name)
				local filter_mod_name = string.lower(filter_name)
				if (filter_mod_name == server_mod_name) or self:find_match(filter_mod_name, server_mod_name) then
					return unpack(result)
				end
			end
		end
	end
	return false
end
